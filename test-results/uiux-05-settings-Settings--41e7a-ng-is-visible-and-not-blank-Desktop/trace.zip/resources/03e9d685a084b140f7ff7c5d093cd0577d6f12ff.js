(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0-3fupm._.css","static/chunks/node_modules_0w5zt83._.js","static/chunks/app_components_MotionProvider_tsx_0jpz75f._.js"],
    source: "dynamic"
});
