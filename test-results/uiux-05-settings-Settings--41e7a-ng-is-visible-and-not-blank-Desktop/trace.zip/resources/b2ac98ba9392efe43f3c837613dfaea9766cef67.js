(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/OnboardingScreen.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OnboardingScreen
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$TripLoaders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/app/components/ui/TripLoaders.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/deriveTheme.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const spring = {
    type: 'spring',
    stiffness: 380,
    damping: 32
};
const SLIDES = [
    {
        id: 'together',
        headline: 'Plan your trip.\nTogether.',
        sub: 'Build a shared itinerary in real time with everyone on the trip.',
        accent: 'var(--forest)',
        preview: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                display: 'flex',
                flexDirection: 'column',
                gap: 10,
                width: '100%',
                maxWidth: 320,
                margin: '0 auto'
            },
            children: [
                {
                    time: '09:00',
                    name: 'Coffee & Croissant',
                    emoji: '☕',
                    color: '#C8944A'
                },
                {
                    time: '11:00',
                    name: 'Louvre Museum',
                    emoji: '🏛️',
                    color: '#3B6E52'
                },
                {
                    time: '14:00',
                    name: 'Lunch at Le Marais',
                    emoji: '🍽️',
                    color: '#C4714A'
                }
            ].map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                    initial: {
                        opacity: 0,
                        x: -20,
                        scale: 0.95
                    },
                    animate: {
                        opacity: 1,
                        x: 0,
                        scale: 1
                    },
                    transition: {
                        ...spring,
                        delay: 0.28 + i * 0.13
                    },
                    style: {
                        display: 'flex',
                        alignItems: 'center',
                        gap: 12,
                        background: 'oklch(97% 0.01 80 / 0.82)',
                        backdropFilter: 'blur(40px) saturate(1.8)',
                        WebkitBackdropFilter: 'blur(40px) saturate(1.8)',
                        borderWidth: 1,
                        borderStyle: 'solid',
                        borderColor: 'oklch(100% 0 0 / 0.10)',
                        borderTopColor: 'oklch(100% 0 0 / 0.38)',
                        borderLeftColor: 'oklch(100% 0 0 / 0.24)',
                        borderBottomColor: 'rgba(26,20,16,0.06)',
                        borderRightColor: 'rgba(26,20,16,0.04)',
                        borderRadius: 20,
                        padding: '12px 14px',
                        boxShadow: '0 4px 16px rgba(26,20,16,0.08)'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                width: 42,
                                height: 42,
                                borderRadius: 14,
                                flexShrink: 0,
                                background: item.color + '22',
                                border: `1.5px solid ${item.color}44`,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: 20
                            },
                            children: item.emoji
                        }, void 0, false, {
                            fileName: "[project]/app/components/OnboardingScreen.tsx",
                            lineNumber: 48,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    style: {
                                        fontSize: 14,
                                        fontWeight: 700,
                                        color: 'var(--text)',
                                        margin: 0,
                                        letterSpacing: '-0.01em'
                                    },
                                    children: item.name
                                }, void 0, false, {
                                    fileName: "[project]/app/components/OnboardingScreen.tsx",
                                    lineNumber: 58,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    style: {
                                        fontSize: 11,
                                        color: 'var(--text-3)',
                                        margin: '2px 0 0',
                                        fontFamily: 'var(--font-mono)',
                                        letterSpacing: '0.06em'
                                    },
                                    children: item.time
                                }, void 0, false, {
                                    fileName: "[project]/app/components/OnboardingScreen.tsx",
                                    lineNumber: 59,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/OnboardingScreen.tsx",
                            lineNumber: 57,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                marginInlineStart: 'auto',
                                flexShrink: 0
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: 8,
                                    height: 8,
                                    borderRadius: 4,
                                    background: item.color,
                                    opacity: 0.7
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                lineNumber: 62,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/app/components/OnboardingScreen.tsx",
                            lineNumber: 61,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, i, true, {
                    fileName: "[project]/app/components/OnboardingScreen.tsx",
                    lineNumber: 27,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)))
        }, void 0, false, {
            fileName: "[project]/app/components/OnboardingScreen.tsx",
            lineNumber: 21,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    },
    {
        id: 'detail',
        headline: 'Every detail.\nEvery day.',
        sub: 'Events, hotels, expenses, and packing — all in one place, always in sync.',
        accent: 'var(--terra)',
        preview: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                display: 'flex',
                gap: 10,
                width: '100%',
                maxWidth: 320,
                margin: '0 auto',
                flexWrap: 'wrap',
                justifyContent: 'center'
            },
            children: [
                {
                    icon: '🗓️',
                    label: 'Itinerary',
                    color: 'rgba(59,110,82,0.16)',
                    border: 'rgba(59,110,82,0.30)'
                },
                {
                    icon: '🏨',
                    label: 'Hotels',
                    color: 'rgba(144,66,202,0.14)',
                    border: 'rgba(144,66,202,0.28)'
                },
                {
                    icon: '💰',
                    label: 'Expenses',
                    color: 'rgba(34,168,90,0.14)',
                    border: 'rgba(34,168,90,0.28)'
                },
                {
                    icon: '🎒',
                    label: 'Packing',
                    color: 'rgba(26,142,218,0.14)',
                    border: 'rgba(26,142,218,0.28)'
                },
                {
                    icon: '📝',
                    label: 'Notes',
                    color: 'rgba(196,113,74,0.14)',
                    border: 'rgba(196,113,74,0.28)'
                },
                {
                    icon: '✈️',
                    label: 'Flights',
                    color: 'rgba(18,82,194,0.14)',
                    border: 'rgba(18,82,194,0.28)'
                }
            ].map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                    initial: {
                        opacity: 0,
                        scale: 0.75
                    },
                    animate: {
                        opacity: 1,
                        scale: 1
                    },
                    transition: {
                        ...spring,
                        delay: 0.2 + i * 0.08
                    },
                    style: {
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: 6,
                        background: item.color,
                        border: `1.5px solid ${item.border}`,
                        borderRadius: 24,
                        padding: '14px 18px',
                        minWidth: 86,
                        backdropFilter: 'blur(20px)',
                        WebkitBackdropFilter: 'blur(20px)'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                fontSize: 26
                            },
                            children: item.icon
                        }, void 0, false, {
                            fileName: "[project]/app/components/OnboardingScreen.tsx",
                            lineNumber: 99,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                fontSize: 11,
                                fontWeight: 700,
                                color: 'var(--text-2)',
                                fontFamily: 'var(--font-sans)'
                            },
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/app/components/OnboardingScreen.tsx",
                            lineNumber: 100,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, i, true, {
                    fileName: "[project]/app/components/OnboardingScreen.tsx",
                    lineNumber: 84,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)))
        }, void 0, false, {
            fileName: "[project]/app/components/OnboardingScreen.tsx",
            lineNumber: 75,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    },
    {
        id: 'start',
        headline: 'Start in\nseconds.',
        sub: 'Create a trip, share the link, and everyone is in instantly.',
        accent: 'var(--sand)',
        preview: null
    }
];
function OnboardingScreen({ onDone }) {
    _s();
    const [slide, setSlide] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [dir, setDir] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const isLast = slide === SLIDES.length - 1;
    const finish = ()=>{
        localStorage.setItem('trippy-onboarded', '1');
        onDone();
    };
    const advance = ()=>{
        if (isLast) {
            finish();
            return;
        }
        setDir(1);
        setSlide((s)=>s + 1);
    };
    const swipeHandlers = {
        onTouchStart: (e)=>{
            swipeHandlers._sx = e.touches[0].clientX;
        },
        onTouchEnd: (e)=>{
            const dx = e.changedTouches[0].clientX - (swipeHandlers._sx ?? 0);
            if (dx < -55 && !isLast) {
                setDir(1);
                setSlide((s)=>s + 1);
            }
            if (dx > 55 && slide > 0) {
                setDir(-1);
                setSlide((s)=>s - 1);
            }
        }
    };
    const { headline, sub, preview, accent } = SLIDES[slide];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            position: 'fixed',
            inset: 0,
            zIndex: 200,
            background: 'var(--bg)',
            display: 'flex',
            flexDirection: 'column',
            paddingTop: 'env(safe-area-inset-top, 0px)',
            paddingBottom: 'env(safe-area-inset-bottom, 0px)',
            overflow: 'hidden'
        },
        ...swipeHandlers,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    inset: 0,
                    pointerEvents: 'none',
                    overflow: 'hidden'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                        animate: {
                            x: [
                                0,
                                20,
                                0
                            ],
                            y: [
                                0,
                                -15,
                                0
                            ]
                        },
                        transition: {
                            duration: 8,
                            repeat: Infinity,
                            ease: 'easeInOut'
                        },
                        style: {
                            position: 'absolute',
                            top: -120,
                            right: -80,
                            width: 'clamp(200px, 50vw, 340px)',
                            height: 'clamp(200px, 50vw, 340px)',
                            borderRadius: '50%',
                            background: 'radial-gradient(circle, rgba(59,110,82,0.16) 0%, transparent 70%)',
                            filter: 'blur(40px)'
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                        lineNumber: 156,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                        animate: {
                            x: [
                                0,
                                -18,
                                0
                            ],
                            y: [
                                0,
                                20,
                                0
                            ]
                        },
                        transition: {
                            duration: 10,
                            repeat: Infinity,
                            ease: 'easeInOut',
                            delay: 2
                        },
                        style: {
                            position: 'absolute',
                            bottom: -100,
                            left: -80,
                            width: 'clamp(180px, 45vw, 300px)',
                            height: 'clamp(180px, 45vw, 300px)',
                            borderRadius: '50%',
                            background: 'radial-gradient(circle, rgba(196,113,74,0.14) 0%, transparent 70%)',
                            filter: 'blur(40px)'
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                        animate: {
                            scale: [
                                1,
                                1.15,
                                1
                            ]
                        },
                        transition: {
                            duration: 6,
                            repeat: Infinity,
                            ease: 'easeInOut',
                            delay: 1
                        },
                        style: {
                            position: 'absolute',
                            top: '40%',
                            left: '50%',
                            transform: 'translate(-50%,-50%)',
                            width: 'clamp(160px, 40vw, 260px)',
                            height: 'clamp(160px, 40vw, 260px)',
                            borderRadius: '50%',
                            background: 'radial-gradient(circle, rgba(200,148,74,0.08) 0%, transparent 70%)',
                            filter: 'blur(40px)'
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/OnboardingScreen.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'flex',
                    justifyContent: 'flex-end',
                    padding: '16px 20px',
                    flexShrink: 0,
                    position: 'relative',
                    zIndex: 1
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].button, {
                    whileTap: {
                        scale: 0.92
                    },
                    transition: spring,
                    onClick: finish,
                    style: {
                        background: 'oklch(97% 0.01 80 / 0.75)',
                        backdropFilter: 'blur(20px)',
                        WebkitBackdropFilter: 'blur(20px)',
                        border: '1px solid oklch(100% 0 0 / 0.20)',
                        borderRadius: 9999,
                        padding: '7px 18px',
                        fontSize: 13,
                        fontWeight: 600,
                        color: 'var(--text-2)',
                        cursor: 'pointer',
                        fontFamily: 'var(--font-sans)'
                    },
                    children: "Skip"
                }, void 0, false, {
                    fileName: "[project]/app/components/OnboardingScreen.tsx",
                    lineNumber: 190,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/OnboardingScreen.tsx",
                lineNumber: 189,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    flex: 1,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '0 28px',
                    overflow: 'hidden',
                    position: 'relative',
                    zIndex: 1
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                    mode: "wait",
                    custom: dir,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                        custom: dir,
                        initial: {
                            opacity: 0,
                            x: dir * 48
                        },
                        animate: {
                            opacity: 1,
                            x: 0
                        },
                        exit: {
                            opacity: 0,
                            x: dir * -48
                        },
                        transition: spring,
                        style: {
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            gap: 28,
                            width: '100%'
                        },
                        children: [
                            slide === 2 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                initial: {
                                    opacity: 0,
                                    scale: 0.8
                                },
                                animate: {
                                    opacity: 1,
                                    scale: 1
                                },
                                transition: {
                                    ...spring,
                                    delay: 0.1
                                },
                                style: {
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    gap: 16,
                                    background: 'oklch(97% 0.01 80 / 0.80)',
                                    backdropFilter: 'blur(40px) saturate(1.8)',
                                    WebkitBackdropFilter: 'blur(40px) saturate(1.8)',
                                    borderWidth: 1,
                                    borderStyle: 'solid',
                                    borderColor: 'oklch(100% 0 0 / 0.10)',
                                    borderTopColor: 'oklch(100% 0 0 / 0.40)',
                                    borderRadius: 32,
                                    padding: '32px 40px',
                                    boxShadow: '0 12px 40px rgba(26,20,16,0.10)'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$TripLoaders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CompassLoader"], {
                                        theme: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_THEME"],
                                        size: 100
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                                        lineNumber: 240,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            fontFamily: 'var(--font-sans)',
                                            fontSize: 22,
                                            fontWeight: 700,
                                            letterSpacing: '-0.04em',
                                            color: 'var(--text)',
                                            direction: 'ltr',
                                            lineHeight: 1
                                        },
                                        children: [
                                            "Trippy",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    color: 'var(--terra)'
                                                },
                                                children: "."
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                                lineNumber: 246,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                                        lineNumber: 241,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                lineNumber: 224,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: '100%'
                                },
                                children: preview
                            }, void 0, false, {
                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                lineNumber: 250,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                style: {
                                    fontSize: 'clamp(2rem, 8vw, 2.8rem)',
                                    fontWeight: 800,
                                    letterSpacing: '-0.04em',
                                    color: 'var(--text)',
                                    textAlign: 'center',
                                    lineHeight: 1.05,
                                    whiteSpace: 'pre-line',
                                    fontFamily: 'var(--font-sans)'
                                },
                                children: headline
                            }, void 0, false, {
                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                lineNumber: 254,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                style: {
                                    fontSize: 16,
                                    color: 'var(--text-2)',
                                    textAlign: 'center',
                                    lineHeight: 1.6,
                                    maxWidth: 300,
                                    margin: 0,
                                    fontFamily: 'var(--font-sans)'
                                },
                                children: sub
                            }, void 0, false, {
                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                lineNumber: 267,
                                columnNumber: 13
                            }, this)
                        ]
                    }, slide, true, {
                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                        lineNumber: 213,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/OnboardingScreen.tsx",
                    lineNumber: 212,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/OnboardingScreen.tsx",
                lineNumber: 211,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    flexShrink: 0,
                    padding: '20px 28px 36px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: 22,
                    position: 'relative',
                    zIndex: 1
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            gap: 7,
                            alignItems: 'center'
                        },
                        children: SLIDES.map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].button, {
                                onClick: ()=>{
                                    setDir(i > slide ? 1 : -1);
                                    setSlide(i);
                                },
                                animate: {
                                    width: i === slide ? 28 : 8,
                                    background: i === slide ? accent : 'var(--border-strong)',
                                    opacity: i === slide ? 1 : 0.5
                                },
                                transition: spring,
                                style: {
                                    height: 8,
                                    borderRadius: 4,
                                    border: 'none',
                                    cursor: 'pointer',
                                    padding: 0
                                }
                            }, i, false, {
                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                lineNumber: 287,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                        lineNumber: 285,
                        columnNumber: 9
                    }, this),
                    isLast ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            flexDirection: 'column',
                            gap: 12,
                            width: '100%',
                            maxWidth: 360
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].button, {
                                whileTap: {
                                    scale: 0.96,
                                    transition: {
                                        type: 'spring',
                                        stiffness: 500,
                                        damping: 20
                                    }
                                },
                                initial: {
                                    opacity: 0,
                                    y: 16
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: spring,
                                onClick: finish,
                                style: {
                                    background: 'var(--brand)',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: 24,
                                    padding: '17px 28px',
                                    fontSize: 16,
                                    fontWeight: 800,
                                    cursor: 'pointer',
                                    width: '100%',
                                    fontFamily: 'var(--font-sans)',
                                    letterSpacing: '-0.02em',
                                    boxShadow: '0 8px 28px rgba(59,110,82,0.32), 0 2px 8px rgba(59,110,82,0.18)'
                                },
                                children: "Create trip"
                            }, void 0, false, {
                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                lineNumber: 304,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].button, {
                                whileTap: {
                                    scale: 0.96,
                                    transition: {
                                        type: 'spring',
                                        stiffness: 500,
                                        damping: 20
                                    }
                                },
                                initial: {
                                    opacity: 0,
                                    y: 16
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    ...spring,
                                    delay: 0.06
                                },
                                onClick: finish,
                                style: {
                                    background: 'oklch(97% 0.01 80 / 0.80)',
                                    backdropFilter: 'blur(20px)',
                                    WebkitBackdropFilter: 'blur(20px)',
                                    color: 'var(--text)',
                                    border: '1.5px solid var(--border)',
                                    borderTopColor: 'oklch(100% 0 0 / 0.32)',
                                    borderRadius: 24,
                                    padding: '15px 28px',
                                    fontSize: 15,
                                    fontWeight: 700,
                                    cursor: 'pointer',
                                    width: '100%',
                                    fontFamily: 'var(--font-sans)',
                                    letterSpacing: '-0.01em'
                                },
                                children: "Join with invite"
                            }, void 0, false, {
                                fileName: "[project]/app/components/OnboardingScreen.tsx",
                                lineNumber: 322,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                        lineNumber: 303,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].button, {
                        whileTap: {
                            scale: 0.95,
                            transition: {
                                type: 'spring',
                                stiffness: 500,
                                damping: 20
                            }
                        },
                        onClick: advance,
                        style: {
                            background: 'var(--brand)',
                            color: 'white',
                            border: 'none',
                            borderRadius: 24,
                            padding: '17px 44px',
                            fontSize: 16,
                            fontWeight: 800,
                            cursor: 'pointer',
                            width: '100%',
                            maxWidth: 360,
                            fontFamily: 'var(--font-sans)',
                            letterSpacing: '-0.02em',
                            boxShadow: '0 8px 28px rgba(59,110,82,0.30), 0 2px 8px rgba(59,110,82,0.16)'
                        },
                        children: "Next →"
                    }, void 0, false, {
                        fileName: "[project]/app/components/OnboardingScreen.tsx",
                        lineNumber: 346,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/OnboardingScreen.tsx",
                lineNumber: 283,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/OnboardingScreen.tsx",
        lineNumber: 143,
        columnNumber: 5
    }, this);
}
_s(OnboardingScreen, "jIqI+DnIntDexF1W5bTvrKWs1Cg=");
_c = OnboardingScreen;
var _c;
__turbopack_context__.k.register(_c, "OnboardingScreen");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/OnboardingScreen.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/components/OnboardingScreen.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=app_components_OnboardingScreen_tsx_0fyd-8d._.js.map