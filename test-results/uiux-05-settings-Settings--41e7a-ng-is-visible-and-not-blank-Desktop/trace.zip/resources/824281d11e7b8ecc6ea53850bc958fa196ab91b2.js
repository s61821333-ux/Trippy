(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/motion.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "blurUpVariants",
    ()=>blurUpVariants,
    "duration",
    ()=>duration,
    "fadeVariants",
    ()=>fadeVariants,
    "listItemVariants",
    ()=>listItemVariants,
    "pageVariants",
    ()=>pageVariants,
    "popInVariants",
    ()=>popInVariants,
    "scaleVariants",
    ()=>scaleVariants,
    "screenVariants",
    ()=>screenVariants,
    "sheetVariants",
    ()=>sheetVariants,
    "slideVariants",
    ()=>slideVariants,
    "spring",
    ()=>spring,
    "stagger",
    ()=>stagger,
    "staggerContainer",
    ()=>staggerContainer,
    "staggerFast",
    ()=>staggerFast
]);
const spring = {
    snap: {
        type: 'spring',
        stiffness: 500,
        damping: 35,
        mass: 0.8
    },
    default: {
        type: 'spring',
        stiffness: 320,
        damping: 28,
        mass: 1
    },
    gentle: {
        type: 'spring',
        stiffness: 220,
        damping: 26,
        mass: 1.2
    },
    float: {
        type: 'spring',
        stiffness: 120,
        damping: 22,
        mass: 1.5
    },
    instant: {
        duration: 0.01
    }
};
const duration = {
    instant: 0.01,
    fast: 0.12,
    normal: 0.22,
    slow: 0.38,
    crawl: 0.6
};
const stagger = {
    fast: 0.04,
    normal: 0.06,
    slow: 0.1
};
const slideVariants = (isRTL = false)=>({
        enter: (direction)=>({
                x: direction === 'forward' ? isRTL ? -40 : 40 : isRTL ? 40 : -40,
                opacity: 0
            }),
        center: {
            x: 0,
            opacity: 1
        },
        exit: (direction)=>({
                x: direction === 'forward' ? isRTL ? 40 : -40 : isRTL ? -40 : 40,
                opacity: 0
            })
    });
const sheetVariants = {
    hidden: {
        y: '100%',
        opacity: 0
    },
    visible: {
        y: 0,
        opacity: 1
    },
    exit: {
        y: '100%',
        opacity: 0
    }
};
const fadeVariants = {
    hidden: {
        opacity: 0
    },
    visible: {
        opacity: 1
    },
    exit: {
        opacity: 0
    }
};
const scaleVariants = {
    hidden: {
        scale: 0.92,
        opacity: 0
    },
    visible: {
        scale: 1,
        opacity: 1
    },
    exit: {
        scale: 0.96,
        opacity: 0
    }
};
const screenVariants = {
    initial: {
        opacity: 0,
        y: 8
    },
    animate: {
        opacity: 1,
        y: 0
    },
    exit: {
        opacity: 0,
        y: -4
    }
};
const listItemVariants = {
    hidden: {
        opacity: 0,
        y: 10
    },
    visible: {
        opacity: 1,
        y: 0
    }
};
const blurUpVariants = {
    hidden: {
        opacity: 0,
        y: 16,
        filter: 'blur(6px)'
    },
    visible: {
        opacity: 1,
        y: 0,
        filter: 'blur(0px)',
        transition: {
            duration: 0.45,
            ease: [
                0.25,
                0,
                0,
                1
            ]
        }
    },
    exit: {
        opacity: 0,
        y: -8,
        filter: 'blur(4px)',
        transition: {
            duration: 0.22,
            ease: [
                0.4,
                0,
                1,
                1
            ]
        }
    }
};
const staggerContainer = {
    hidden: {},
    visible: {
        transition: {
            staggerChildren: 0.07,
            delayChildren: 0.05
        }
    }
};
const staggerFast = {
    hidden: {},
    visible: {
        transition: {
            staggerChildren: 0.04,
            delayChildren: 0.02
        }
    }
};
const pageVariants = {
    initial: {
        opacity: 0,
        y: 8,
        filter: 'blur(6px)'
    },
    animate: {
        opacity: 1,
        y: 0,
        filter: 'blur(0px)',
        transition: {
            duration: 0.38,
            ease: [
                0.25,
                0,
                0,
                1
            ]
        }
    },
    exit: {
        opacity: 0,
        y: -6,
        filter: 'blur(4px)',
        transition: {
            duration: 0.22,
            ease: [
                0.4,
                0,
                1,
                1
            ]
        }
    }
};
const popInVariants = {
    hidden: {
        opacity: 0,
        scale: 0.88,
        filter: 'blur(4px)'
    },
    visible: {
        opacity: 1,
        scale: 1,
        filter: 'blur(0px)',
        transition: {
            duration: 0.4,
            ease: [
                0.34,
                1.56,
                0.64,
                1
            ]
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/mockData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEMO_TRIP_CODE",
    ()=>DEMO_TRIP_CODE,
    "DEMO_TRIP_NAME",
    ()=>DEMO_TRIP_NAME,
    "MOCK_AI_SUGGESTIONS",
    ()=>MOCK_AI_SUGGESTIONS,
    "MOCK_SUPPLIES",
    ()=>MOCK_SUPPLIES,
    "MOCK_TRIP",
    ()=>MOCK_TRIP,
    "getThemeSupplies",
    ()=>getThemeSupplies
]);
const MOCK_TRIP = {
    name: 'Negev Desert Adventure',
    days: 4,
    startDate: '2026-07-14',
    participants: [
        {
            id: 1,
            name: 'Yoav',
            initials: 'YO',
            color: 'oklch(62% 0.15 195)'
        },
        {
            id: 2,
            name: 'Dana',
            initials: 'DA',
            color: 'oklch(60% 0.17 28)'
        },
        {
            id: 3,
            name: 'Miri',
            initials: 'MI',
            color: 'oklch(60% 0.14 148)'
        }
    ],
    dayMeta: [
        {
            region: 'Mitzpe Ramon',
            emoji: '🏔️',
            lat: 30.62,
            lng: 34.82,
            desc: 'Ramon Crater'
        },
        {
            region: 'Avdat Valley',
            emoji: '🏛️',
            lat: 30.79,
            lng: 34.77,
            desc: 'Ancient Nabatean'
        },
        {
            region: 'Dead Sea',
            emoji: '🌊',
            lat: 31.20,
            lng: 35.36,
            desc: 'Lowest point on Earth'
        },
        {
            region: 'Timna & Eilat',
            emoji: '⚓',
            lat: 29.55,
            lng: 34.95,
            desc: 'Red Sea coast'
        }
    ],
    events: {
        1: [
            {
                id: 'e1',
                time: '07:00',
                duration: 60,
                name: 'Morning camp breakfast',
                category: 'food',
                location: 'Ramon Crater Base',
                addedBy: 'Yoav',
                notes: 'Bring the camping stove'
            },
            {
                id: 'e2',
                time: '09:00',
                duration: 180,
                name: 'Makhtesh Ramon Hike',
                category: 'attraction',
                location: 'Ramon Crater Rim',
                addedBy: 'Dana',
                notes: 'Sunrise colors are magical'
            },
            {
                id: 'e3',
                time: '13:30',
                duration: 90,
                name: 'Lunch at Beresheet Hotel',
                category: 'food',
                location: 'Mitzpe Ramon',
                addedBy: 'Yoav'
            },
            {
                id: 'e4',
                time: '16:00',
                duration: 120,
                name: 'Desert Jeep Tour',
                category: 'transport',
                location: 'Negev Highlands',
                addedBy: 'Miri'
            },
            {
                id: 'e5',
                time: '19:30',
                duration: 60,
                name: 'Stargazing setup',
                category: 'rest',
                location: 'Camp Site Alpha',
                addedBy: 'Dana'
            }
        ],
        2: [
            {
                id: 'e6',
                time: '06:30',
                duration: 45,
                name: 'Sunrise meditation',
                category: 'rest',
                location: 'Dune Ridge',
                addedBy: 'Dana'
            },
            {
                id: 'e7',
                time: '08:00',
                duration: 120,
                name: 'Avdat National Park',
                category: 'attraction',
                location: 'Avdat',
                addedBy: 'Yoav',
                notes: 'Nabatean ruins — arrive early'
            },
            {
                id: 'e8',
                time: '12:00',
                duration: 60,
                name: 'Lunch & shade rest',
                category: 'food',
                location: 'Ein Avdat Picnic',
                addedBy: 'Miri'
            },
            {
                id: 'e9',
                time: '15:00',
                duration: 90,
                name: 'Ein Avdat Canyon',
                category: 'attraction',
                location: 'Ein Avdat',
                addedBy: 'Dana'
            }
        ],
        3: [
            {
                id: 'e10',
                time: '08:00',
                duration: 120,
                name: 'Dead Sea Morning Swim',
                category: 'attraction',
                location: 'Ein Bokek Beach',
                addedBy: 'Yoav'
            },
            {
                id: 'e11',
                time: '11:00',
                duration: 60,
                name: 'Masada via cable car',
                category: 'attraction',
                location: 'Masada',
                addedBy: 'Dana'
            },
            {
                id: 'e12',
                time: '14:00',
                duration: 90,
                name: 'Lunch — Masada Rest House',
                category: 'food',
                location: 'Masada',
                addedBy: 'Miri'
            }
        ],
        4: [
            {
                id: 'e13',
                time: '09:00',
                duration: 60,
                name: 'Pack & prep',
                category: 'transport',
                location: 'Camp Site Alpha',
                addedBy: 'Yoav'
            },
            {
                id: 'e14',
                time: '11:00',
                duration: 90,
                name: 'Timna Valley Park',
                category: 'attraction',
                location: 'Timna',
                addedBy: 'Dana'
            },
            {
                id: 'e15',
                time: '14:00',
                duration: 60,
                name: 'Final lunch — Eilat',
                category: 'food',
                location: 'Eilat Port',
                addedBy: 'Miri'
            }
        ]
    }
};
const MOCK_AI_SUGGESTIONS = [
    {
        id: 's1',
        name: 'Alpaca Farm Mitzpe Ramon',
        category: 'attraction',
        description: 'A charming desert farm — perfect 45-min stop for the whole group.',
        duration: 45,
        time: '15:00',
        distance: '2.1 km',
        open: true
    },
    {
        id: 's2',
        name: 'Desert Bistro & Coffee',
        category: 'cafe',
        description: 'Acclaimed café with Bedouin coffee and a crater-view terrace.',
        duration: 60,
        time: '15:00',
        distance: '0.8 km',
        open: true
    },
    {
        id: 's3',
        name: 'Camel Crossing Viewpoint',
        category: 'attraction',
        description: '15-min walk to a spectacular vantage over the crater floor.',
        duration: 30,
        time: '15:15',
        distance: '1.4 km',
        open: true
    },
    {
        id: 's4',
        name: 'Bedouin Hospitality Tent',
        category: 'food',
        description: 'Traditional tea and local bread with a Bedouin family — unforgettable.',
        duration: 60,
        time: '16:00',
        distance: '3.2 km',
        open: false
    }
];
const MOCK_SUPPLIES = [
    {
        id: 'sp1',
        name: 'Water (3L/person/day)',
        category: 'Water',
        checked: true
    },
    {
        id: 'sp2',
        name: 'Sunscreen SPF50+',
        category: 'Gear',
        checked: true
    },
    {
        id: 'sp3',
        name: 'Hat / Buff',
        category: 'Gear',
        checked: false
    },
    {
        id: 'sp4',
        name: 'Electrolytes',
        category: 'Food',
        checked: true
    },
    {
        id: 'sp5',
        name: 'Snacks (nuts, dates, bars)',
        category: 'Food',
        checked: false
    },
    {
        id: 'sp6',
        name: 'First aid kit',
        category: 'Medical',
        checked: true
    },
    {
        id: 'sp7',
        name: 'Emergency blanket',
        category: 'Gear',
        checked: false
    },
    {
        id: 'sp8',
        name: 'Headlamp + batteries',
        category: 'Gear',
        checked: false
    },
    {
        id: 'sp9',
        name: 'Offline maps downloaded',
        category: 'Gear',
        checked: true
    },
    {
        id: 'sp10',
        name: 'Multi-tool',
        category: 'Gear',
        checked: false
    },
    {
        id: 'sp11',
        name: 'Power bank',
        category: 'Gear',
        checked: true
    },
    {
        id: 'sp12',
        name: 'Trash bags',
        category: 'Other',
        checked: false
    },
    {
        id: 'sp13',
        name: 'Navigation (offline maps)',
        category: 'Documents',
        checked: true
    },
    {
        id: 'sp14',
        name: 'ID / Passport',
        category: 'Documents',
        checked: false
    }
];
const DEMO_TRIP_NAME = 'Negev Desert Adventure';
const DEMO_TRIP_CODE = 'desert123';
const CITY_SUPPLIES = [
    {
        id: 'cs1',
        name: 'Passport / ID',
        category: 'Documents',
        checked: false
    },
    {
        id: 'cs2',
        name: 'Travel insurance',
        category: 'Documents',
        checked: false
    },
    {
        id: 'cs3',
        name: 'Museum / attraction tickets',
        category: 'Documents',
        checked: false
    },
    {
        id: 'cs4',
        name: 'Rail / transit pass',
        category: 'Documents',
        checked: false
    },
    {
        id: 'cs5',
        name: 'Travel adapter',
        category: 'Gear',
        checked: false
    },
    {
        id: 'cs6',
        name: 'Power bank',
        category: 'Gear',
        checked: false
    },
    {
        id: 'cs7',
        name: 'Comfortable walking shoes',
        category: 'Gear',
        checked: false
    },
    {
        id: 'cs8',
        name: 'Rain jacket / umbrella',
        category: 'Gear',
        checked: false
    },
    {
        id: 'cs9',
        name: 'Day backpack',
        category: 'Gear',
        checked: false
    },
    {
        id: 'cs10',
        name: 'Sunscreen SPF30',
        category: 'Gear',
        checked: false
    },
    {
        id: 'cs11',
        name: 'First aid kit',
        category: 'Medical',
        checked: false
    },
    {
        id: 'cs12',
        name: 'Pain relievers',
        category: 'Medical',
        checked: false
    },
    {
        id: 'cs13',
        name: 'Reusable water bottle',
        category: 'Water',
        checked: false
    },
    {
        id: 'cs14',
        name: 'Snacks for travel days',
        category: 'Food',
        checked: false
    }
];
const BEACH_SUPPLIES = [
    {
        id: 'bs1',
        name: 'Passport / ID',
        category: 'Documents',
        checked: false
    },
    {
        id: 'bs2',
        name: 'Travel insurance',
        category: 'Documents',
        checked: false
    },
    {
        id: 'bs3',
        name: 'Sunscreen SPF50+',
        category: 'Gear',
        checked: false
    },
    {
        id: 'bs4',
        name: 'Swimwear',
        category: 'Gear',
        checked: false
    },
    {
        id: 'bs5',
        name: 'Beach towel',
        category: 'Gear',
        checked: false
    },
    {
        id: 'bs6',
        name: 'Sunglasses',
        category: 'Gear',
        checked: false
    },
    {
        id: 'bs7',
        name: 'Flip flops',
        category: 'Gear',
        checked: false
    },
    {
        id: 'bs8',
        name: 'Waterproof phone case',
        category: 'Gear',
        checked: false
    },
    {
        id: 'bs9',
        name: 'Power bank',
        category: 'Gear',
        checked: false
    },
    {
        id: 'bs10',
        name: 'After-sun lotion',
        category: 'Medical',
        checked: false
    },
    {
        id: 'bs11',
        name: 'First aid kit',
        category: 'Medical',
        checked: false
    },
    {
        id: 'bs12',
        name: 'Reusable water bottle',
        category: 'Water',
        checked: false
    },
    {
        id: 'bs13',
        name: 'Snacks',
        category: 'Food',
        checked: false
    }
];
const NATURE_SUPPLIES = [
    {
        id: 'ns1',
        name: 'Passport / ID',
        category: 'Documents',
        checked: false
    },
    {
        id: 'ns2',
        name: 'Park / trail permits',
        category: 'Documents',
        checked: false
    },
    {
        id: 'ns3',
        name: 'Water (2L/person)',
        category: 'Water',
        checked: false
    },
    {
        id: 'ns4',
        name: 'Electrolytes',
        category: 'Food',
        checked: false
    },
    {
        id: 'ns5',
        name: 'Trail snacks',
        category: 'Food',
        checked: false
    },
    {
        id: 'ns6',
        name: 'Hiking boots',
        category: 'Gear',
        checked: false
    },
    {
        id: 'ns7',
        name: 'Rain jacket',
        category: 'Gear',
        checked: false
    },
    {
        id: 'ns8',
        name: 'Headlamp + batteries',
        category: 'Gear',
        checked: false
    },
    {
        id: 'ns9',
        name: 'Sunscreen SPF50+',
        category: 'Gear',
        checked: false
    },
    {
        id: 'ns10',
        name: 'Offline maps downloaded',
        category: 'Gear',
        checked: false
    },
    {
        id: 'ns11',
        name: 'Power bank',
        category: 'Gear',
        checked: false
    },
    {
        id: 'ns12',
        name: 'First aid kit',
        category: 'Medical',
        checked: false
    },
    {
        id: 'ns13',
        name: 'Emergency blanket',
        category: 'Gear',
        checked: false
    }
];
function getThemeSupplies(theme) {
    switch(theme){
        case 'city':
            return CITY_SUPPLIES;
        case 'beach':
            return BEACH_SUPPLIES;
        case 'nature':
            return NATURE_SUPPLIES;
        case 'mountain':
        case 'snow':
            return NATURE_SUPPLIES;
        default:
            return MOCK_SUPPLIES;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/utils/supabase/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
function createClient() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://teruznbrimctwmjaavet.supabase.co"), ("TURBOPACK compile-time value", "sb_publishable_rO8IbYLwglfKxHLxQ7QBmQ_oYOJobTq"), {
        cookieOptions: {
            maxAge: 60 * 60 * 24 * 365,
            sameSite: 'lax',
            secure: ("TURBOPACK compile-time value", "development") === 'production',
            path: '/'
        }
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/db.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TERMS_VERSION",
    ()=>TERMS_VERSION,
    "dbAcceptInvitation",
    ()=>dbAcceptInvitation,
    "dbAddEmergencyContact",
    ()=>dbAddEmergencyContact,
    "dbAddEvent",
    ()=>dbAddEvent,
    "dbAddExpense",
    ()=>dbAddExpense,
    "dbAddSupply",
    ()=>dbAddSupply,
    "dbCancelInvitation",
    ()=>dbCancelInvitation,
    "dbCreateTrip",
    ()=>dbCreateTrip,
    "dbDeleteAccount",
    ()=>dbDeleteAccount,
    "dbDeleteEmergencyContact",
    ()=>dbDeleteEmergencyContact,
    "dbDeleteEvent",
    ()=>dbDeleteEvent,
    "dbDeleteExpense",
    ()=>dbDeleteExpense,
    "dbDeleteSupply",
    ()=>dbDeleteSupply,
    "dbDeleteTrip",
    ()=>dbDeleteTrip,
    "dbEditEvent",
    ()=>dbEditEvent,
    "dbGetInvitations",
    ()=>dbGetInvitations,
    "dbGetOrCreateInviteToken",
    ()=>dbGetOrCreateInviteToken,
    "dbGetPrivacyConsent",
    ()=>dbGetPrivacyConsent,
    "dbGetTripEmailInvitations",
    ()=>dbGetTripEmailInvitations,
    "dbGetUserTrips",
    ()=>dbGetUserTrips,
    "dbInviteToTrip",
    ()=>dbInviteToTrip,
    "dbLeaveTrip",
    ()=>dbLeaveTrip,
    "dbLoadTripById",
    ()=>dbLoadTripById,
    "dbMoveEvent",
    ()=>dbMoveEvent,
    "dbRejectInvitation",
    ()=>dbRejectInvitation,
    "dbSavePrivacyConsent",
    ()=>dbSavePrivacyConsent,
    "dbToggleSupply",
    ()=>dbToggleSupply,
    "dbUpdateDayMeta",
    ()=>dbUpdateDayMeta,
    "dbUpdateEventVotes",
    ()=>dbUpdateEventVotes,
    "dbUpdateHotels",
    ()=>dbUpdateHotels,
    "dbUpdateSupplyCritical",
    ()=>dbUpdateSupplyCritical,
    "dbUpdateTripInfo",
    ()=>dbUpdateTripInfo,
    "dbUpdateTripNotes",
    ()=>dbUpdateTripNotes,
    "dbUpdateTripTheme",
    ()=>dbUpdateTripTheme,
    "getCurrentUser",
    ()=>getCurrentUser,
    "getSessionUserId",
    ()=>getSessionUserId,
    "rowToTrip",
    ()=>rowToTrip,
    "signInWithGoogle",
    ()=>signInWithGoogle,
    "signOut",
    ()=>signOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/supabase/client.ts [app-client] (ecmascript)");
;
const TERMS_VERSION = '2026-05-v1';
function sb() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
}
// ─── Auth ────────────────────────────────────────────────────────────────────
function isWebView() {
    const ua = navigator.userAgent;
    if (/FBAN|FBAV|FB_IAB|Instagram|Twitter\/|Line\/|WhatsApp|Snapchat/i.test(ua)) return true;
    if (/Android/.test(ua) && /wv/.test(ua)) return true;
    if (/iPhone|iPad/.test(ua) && !/Safari\//.test(ua) && /AppleWebKit/.test(ua)) return true;
    return false;
}
async function signInWithGoogle() {
    const supabase = sb();
    const redirectTo = `${window.location.origin}/auth/callback`;
    // In embedded WebViews (Instagram, Facebook, etc.) Google blocks OAuth.
    // Get the URL first and open it in the system browser.
    if (isWebView()) {
        const { data } = await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: {
                redirectTo,
                skipBrowserRedirect: true
            }
        });
        if (data?.url) {
            // Try Chrome intent on Android, fall back to window.open
            const ua = navigator.userAgent;
            if (/Android/.test(ua)) {
                const intent = `intent://${data.url.replace(/^https?:\/\//, '')}#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=${encodeURIComponent(data.url)};end`;
                window.location.href = intent;
            } else {
                window.open(data.url, '_blank', 'noopener,noreferrer');
            }
        }
        return;
    }
    await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
            redirectTo
        }
    });
}
async function getCurrentUser() {
    const { data: { session } } = await sb().auth.getSession();
    if (!session?.user) return null;
    const email = session.user.email ?? '';
    const username = session.user.user_metadata?.full_name ?? email.split('@')[0];
    return {
        id: session.user.id,
        username
    };
}
async function signOut() {
    await sb().auth.signOut();
}
async function getSessionUserId() {
    const { data: { session } } = await sb().auth.getSession();
    return session?.user?.id ?? null;
}
async function dbCreateTrip(userId, name, days, startDate, theme, dayMetas, nickname, countries) {
    const r = await fetch('/api/trips/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name,
            days,
            startDate,
            theme,
            countries,
            nickname,
            dayMetas
        })
    });
    const body = await r.json().catch(()=>({}));
    if (!r.ok) throw new Error(body.error ?? 'Failed to create trip');
    return body.tripId;
}
async function dbGetUserTrips(userId) {
    const r = await fetch('/api/trips', {
        cache: 'no-store'
    });
    if (!r.ok) return [];
    const data = await r.json();
    // Support both legacy array shape and new paginated { trips, nextCursor } shape
    return Array.isArray(data) ? data : data?.trips ?? [];
}
async function dbGetInvitations() {
    const r = await fetch('/api/invitations');
    if (!r.ok) return [];
    const data = await r.json().catch(()=>[]);
    return Array.isArray(data) ? data : [];
}
async function dbInviteToTrip(tripId, invitedEmail) {
    const r = await fetch('/api/invitations/send', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            tripId,
            invitedEmail
        })
    });
    if (!r.ok) {
        const body = await r.json().catch(()=>({}));
        throw new Error(body.error ?? 'Failed to send invitation');
    }
}
async function dbAcceptInvitation(invitationId, userId, initials) {
    const r = await fetch('/api/invitations/accept', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            invitationId,
            initials
        })
    });
    const body = await r.json().catch(()=>({}));
    if (r.status === 404) throw new Error('Invitation not found');
    if (!r.ok) throw new Error('Failed to accept invitation');
    return body.tripId;
}
async function dbRejectInvitation(invitationId) {
    const r = await fetch(`/api/invitations?id=${encodeURIComponent(invitationId)}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbLoadTripById(tripId) {
    // Use the server route so the load works regardless of RLS configuration —
    // the route uses the service role key and verifies participation itself.
    const r = await fetch(`/api/trips/${tripId}`, {
        cache: 'no-store'
    });
    if (!r.ok) return null;
    return await r.json();
}
async function dbAddEvent(tripId, dayNumber, event, _userId) {
    const res = await fetch(`/api/trips/${tripId}/events`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: event.id,
            day_index: dayNumber - 1,
            time: event.time,
            duration: event.duration,
            name: event.name,
            category: event.category,
            location: event.location ?? null,
            lat: event.lat ?? null,
            lng: event.lng ?? null,
            notes: event.notes ?? null,
            cost: event.cost ?? null,
            tags: event.tags ?? null
        })
    });
    if (!res.ok) {
        const body = await res.json().catch(()=>({}));
        throw new Error(body.error ?? `HTTP ${res.status}`);
    }
}
async function dbEditEvent(eventId, updates) {
    const tripId = updates.tripId;
    if (!tripId) {
        // Fallback: direct Supabase update (non-recursive tables are safe)
        const patch = {};
        if (updates.time !== undefined) patch.time = updates.time;
        if (updates.duration !== undefined) patch.duration = updates.duration;
        if (updates.name !== undefined) patch.name = updates.name;
        if (updates.category !== undefined) patch.category = updates.category;
        if (updates.location !== undefined) patch.location = updates.location;
        if (updates.lat !== undefined) patch.lat = updates.lat;
        if (updates.lng !== undefined) patch.lng = updates.lng;
        if (updates.notes !== undefined) patch.notes = updates.notes;
        if (updates.cost !== undefined) patch.cost = updates.cost;
        if (updates.tags !== undefined) patch.tags = updates.tags;
        if (updates.votes !== undefined) patch.votes = updates.votes;
        const { error } = await sb().from('events').update(patch).eq('id', eventId);
        if (error) throw error;
        return;
    }
    const patch = {};
    if (updates.time !== undefined) patch.time = updates.time;
    if (updates.duration !== undefined) patch.duration = updates.duration;
    if (updates.name !== undefined) patch.name = updates.name;
    if (updates.category !== undefined) patch.category = updates.category;
    if (updates.location !== undefined) patch.location = updates.location;
    if (updates.lat !== undefined) patch.lat = updates.lat;
    if (updates.lng !== undefined) patch.lng = updates.lng;
    if (updates.notes !== undefined) patch.notes = updates.notes;
    if (updates.cost !== undefined) patch.cost = updates.cost;
    if (updates.tags !== undefined) patch.tags = updates.tags;
    if (updates.votes !== undefined) patch.votes = updates.votes;
    const res = await fetch(`/api/trips/${tripId}/events?eventId=${eventId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(patch)
    });
    if (!res.ok) {
        const body = await res.json().catch(()=>({}));
        throw new Error(body.error ?? `HTTP ${res.status}`);
    }
}
async function dbUpdateEventVotes(eventId, votes, tripId) {
    if (!tripId) {
        const { error } = await sb().from('events').update({
            votes
        }).eq('id', eventId);
        if (error) throw error;
        return;
    }
    const r = await fetch(`/api/trips/${tripId}/events?eventId=${eventId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            votes
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbDeleteEvent(eventId, tripId) {
    if (!tripId) {
        const { error } = await sb().from('events').delete().eq('id', eventId);
        if (error) throw error;
        return;
    }
    const res = await fetch(`/api/trips/${tripId}/events?eventId=${eventId}`, {
        method: 'DELETE'
    });
    if (!res.ok) {
        const body = await res.json().catch(()=>({}));
        throw new Error(body.error ?? `HTTP ${res.status}`);
    }
}
async function dbMoveEvent(eventId, newDayNumber, tripId) {
    if (!tripId) {
        const { error } = await sb().from('events').update({
            day_index: newDayNumber - 1
        }).eq('id', eventId);
        if (error) throw error;
        return;
    }
    const res = await fetch(`/api/trips/${tripId}/events?eventId=${eventId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            day_index: newDayNumber - 1
        })
    });
    if (!res.ok) {
        const body = await res.json().catch(()=>({}));
        throw new Error(body.error ?? `HTTP ${res.status}`);
    }
}
async function dbAddExpense(tripId, expense, _userId) {
    const r = await fetch(`/api/trips/${tripId}/expenses`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: expense.id,
            description: expense.description,
            amount: expense.amount,
            splitCount: expense.splitCount
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbDeleteExpense(expenseId, tripId) {
    if (!tripId) {
        const { error } = await sb().from('expenses').delete().eq('id', expenseId);
        if (error) throw error;
        return;
    }
    const r = await fetch(`/api/trips/${tripId}/expenses?id=${expenseId}`, {
        method: 'DELETE'
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbAddSupply(tripId, supply) {
    const r = await fetch(`/api/trips/${tripId}/supplies`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: supply.id,
            name: supply.name,
            category: supply.category,
            checked: supply.checked,
            critical: supply.critical ?? false,
            assignee: supply.assignee ?? null
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbToggleSupply(supplyId, checked, tripId) {
    if (!tripId) {
        const { error } = await sb().from('supplies').update({
            checked
        }).eq('id', supplyId);
        if (error) throw error;
        return;
    }
    const r = await fetch(`/api/trips/${tripId}/supplies?id=${supplyId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            checked
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbDeleteSupply(supplyId, tripId) {
    if (!tripId) {
        const { error } = await sb().from('supplies').delete().eq('id', supplyId);
        if (error) throw error;
        return;
    }
    const r = await fetch(`/api/trips/${tripId}/supplies?id=${supplyId}`, {
        method: 'DELETE'
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbAddEmergencyContact(tripId, contact) {
    const r = await fetch(`/api/trips/${tripId}/emergency-contacts`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: contact.id,
            name: contact.name,
            phone: contact.phone,
            type: contact.type
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbDeleteEmergencyContact(contactId, tripId) {
    if (!tripId) {
        const { error } = await sb().from('emergency_contacts').delete().eq('id', contactId);
        if (error) throw error;
        return;
    }
    const r = await fetch(`/api/trips/${tripId}/emergency-contacts?id=${contactId}`, {
        method: 'DELETE'
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbUpdateTripInfo(tripId, updates) {
    const r = await fetch(`/api/trips/${tripId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(updates)
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbUpdateTripTheme(tripId, theme) {
    const r = await fetch(`/api/trips/${tripId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            theme
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbUpdateSupplyCritical(supplyId, critical, tripId) {
    if (!tripId) {
        const { error } = await sb().from('supplies').update({
            critical
        }).eq('id', supplyId);
        if (error) throw error;
        return;
    }
    const r = await fetch(`/api/trips/${tripId}/supplies?id=${supplyId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            critical
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbLeaveTrip(tripId, _userId) {
    const r = await fetch(`/api/trips/${tripId}`, {
        method: 'DELETE'
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbDeleteTrip(tripId) {
    const r = await fetch(`/api/trips/${tripId}?full=true`, {
        method: 'DELETE'
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbUpdateTripNotes(tripId, notes) {
    const r = await fetch(`/api/trips/${tripId}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            trip_notes: notes
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbUpdateHotels(tripId, hotels) {
    const r = await fetch(`/api/trips/${tripId}/hotels`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            hotels
        })
    });
    if (!r.ok) {
        const body = await r.json().catch(()=>({}));
        throw new Error(body?.error ?? `hotels_save_failed (${r.status})`);
    }
}
async function dbUpdateDayMeta(tripId, dayIndex, meta) {
    const r = await fetch(`/api/trips/${tripId}/day-meta`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            dayIndex,
            ...meta
        })
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbGetOrCreateInviteToken(tripId) {
    const supabase = sb();
    const { data } = await supabase.from('trips').select('invite_token').eq('id', tripId).single();
    if (data?.invite_token) return data.invite_token;
    const token = crypto.randomUUID();
    await supabase.from('trips').update({
        invite_token: token
    }).eq('id', tripId);
    return token;
}
async function dbGetTripEmailInvitations(tripId) {
    const { data, error } = await sb().from('trip_invitations').select('id, invited_email, status, created_at').eq('trip_id', tripId).not('invited_email', 'is', null).eq('status', 'pending');
    if (error) return [];
    return (data ?? []).map((r)=>({
            id: r.id,
            email: r.invited_email,
            status: r.status,
            created_at: r.created_at
        }));
}
async function dbCancelInvitation(invitationId) {
    const r = await fetch(`/api/invitations?id=${encodeURIComponent(invitationId)}`, {
        method: 'DELETE'
    });
    if (!r.ok) {
        const b = await r.json().catch(()=>({}));
        throw new Error(b.error ?? `HTTP ${r.status}`);
    }
}
async function dbGetPrivacyConsent(userId) {
    const { data } = await sb().from('privacy_consents').select('content_hash, content').eq('user_id', userId).maybeSingle();
    return data ?? null;
}
async function dbSavePrivacyConsent(contentHash, content) {
    const { data: { user } } = await sb().auth.getUser();
    if (!user) throw new Error('Not authenticated');
    const { error } = await sb().from('privacy_consents').upsert({
        user_id: user.id,
        accepted_at: new Date().toISOString(),
        content_hash: contentHash,
        content
    }, {
        onConflict: 'user_id'
    });
    if (error) throw error;
}
async function dbDeleteAccount() {
    const r = await fetch('/api/account/delete', {
        method: 'DELETE'
    });
    if (!r.ok) {
        const body = await r.json().catch(()=>({}));
        throw new Error(body.error ?? 'Failed to delete account');
    }
}
function rowToTrip(data) {
    const days = data.days ?? 1;
    // Build user_id → initials map so addedBy / paidBy resolve to display names
    const userToInitials = new Map((data.trip_participants ?? []).map((p)=>[
            p.user_id,
            p.initials ?? '??'
        ]));
    const dayMeta = Array.from({
        length: days
    }, (_, i)=>{
        const row = (data.day_meta ?? []).find((m)=>m.day_index === i);
        return {
            region: row?.region ?? `Day ${i + 1}`,
            emoji: row?.emoji ?? '🏔️',
            lat: row?.lat ?? 31,
            lng: row?.lng ?? 35,
            desc: row?.description ?? ''
        };
    });
    const events = {};
    for(let d = 1; d <= days; d++){
        events[d] = (data.events ?? []).filter((e)=>e.day_index === d - 1).map((e)=>({
                id: e.id,
                time: e.time ?? '09:00',
                duration: e.duration ?? 60,
                name: e.name,
                category: e.category ?? 'other',
                location: e.location ?? undefined,
                lat: e.lat ?? undefined,
                lng: e.lng ?? undefined,
                notes: e.notes ?? undefined,
                addedBy: userToInitials.get(e.added_by) ?? 'Unknown',
                cost: e.cost ?? undefined,
                tags: e.tags ?? undefined,
                votes: e.votes && typeof e.votes === 'object' ? e.votes : undefined
            }));
    }
    const expenses = (data.expenses ?? []).map((e)=>({
            id: e.id,
            description: e.description,
            amount: e.amount,
            paidBy: userToInitials.get(e.paid_by) ?? 'Unknown',
            splitCount: e.split_count ?? 1
        }));
    const emergencyContacts = (data.emergency_contacts ?? []).map((c)=>({
            id: c.id,
            name: c.name,
            phone: c.phone,
            type: c.type ?? 'personal'
        }));
    const participants = (data.trip_participants ?? []).map((p, i)=>({
            id: i + 1,
            name: p.initials ?? '??',
            initials: p.initials ?? '??',
            color: p.color ?? 'oklch(62% 0.15 195)'
        }));
    const supplies = (data.supplies ?? []).map((s)=>({
            id: s.id,
            name: s.name,
            category: s.category ?? 'Other',
            checked: s.checked ?? false,
            critical: s.critical ?? false,
            assignee: s.assignee ?? undefined
        }));
    const trip = {
        name: data.name,
        days,
        startDate: data.start_date ?? new Date().toISOString().split('T')[0],
        theme: data.theme ?? 'desert',
        countries: (()=>{
            const raw = data.countries;
            // Case 1: proper text[] column — PostgREST returns JS array directly
            if (Array.isArray(raw)) return raw.filter(Boolean);
            if (typeof raw !== 'string' || !raw.trim()) return undefined;
            const s = raw.trim();
            // Case 2: text column storing JSON string: ["United States","France"]
            if (s.startsWith('[')) {
                try {
                    const parsed = JSON.parse(s);
                    if (Array.isArray(parsed)) return parsed.map((c)=>String(c).trim()).filter(Boolean);
                } catch  {}
            }
            // Case 3: PostgreSQL array literal: {Israel} or {"United States",Jordan}
            if (s.startsWith('{') && s.endsWith('}')) {
                const inner = s.slice(1, -1);
                if (!inner.trim()) return undefined;
                const parts = inner.match(/(?:"[^"]*"|[^,]+)/g) ?? [];
                const result = parts.map((p)=>p.replace(/^"|"$/g, '').trim()).filter(Boolean);
                return result.length ? result : undefined;
            }
            // Case 4: plain comma-separated: "United States,France"
            const result = s.split(',').map((c)=>c.trim()).filter(Boolean);
            return result.length ? result : undefined;
        })(),
        tripNotes: data.trip_notes ?? [],
        hotels: Array.isArray(data.hotels) ? data.hotels : [],
        participants,
        dayMeta,
        events,
        expenses,
        emergencyContacts,
        createdBy: data.created_by ?? undefined
    };
    return {
        trip,
        supplies
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAppStore",
    ()=>useAppStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/mockData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const uid = ()=>crypto.randomUUID();
// Merges locally-pending events (not yet in DB) and local votes into a DB-loaded trip.
// Also re-fires dbAddEvent for any pending events so they get synced now.
function mergeLocalIntoDbTrip(dbTrip, localTrip, tripDbId, userId, onSyncError) {
    if (!localTrip) return dbTrip;
    const mergedEvents = {
        ...dbTrip.events
    };
    for (const [dayKey, localEvs] of Object.entries(localTrip.events ?? {})){
        const day = Number(dayKey);
        const dbIds = new Set((mergedEvents[day] ?? []).map((e)=>e.id));
        // Events only in localStorage (DB write failed or pending) — re-sync them
        const pending = localEvs.filter((e)=>!dbIds.has(e.id));
        if (pending.length > 0) {
            mergedEvents[day] = [
                ...mergedEvents[day] ?? [],
                ...pending
            ];
            for (const ev of pending){
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAddEvent"])(tripDbId, day, ev, userId).catch((err)=>onSyncError(err?.message ?? 'save_failed'));
            }
        }
        // Merge votes: prefer DB votes when present, fall back to local votes
        mergedEvents[day] = (mergedEvents[day] ?? []).map((dbEv)=>{
            const localEv = localEvs.find((l)=>l.id === dbEv.id);
            const mergedVotes = {
                ...localEv?.votes ?? {},
                ...dbEv.votes ?? {}
            };
            return Object.keys(mergedVotes).length > 0 ? {
                ...dbEv,
                votes: mergedVotes
            } : dbEv;
        });
    }
    return {
        ...dbTrip,
        events: mergedEvents
    };
}
const useAppStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((set, get)=>({
        screen: 'splash',
        trip: null,
        nickname: '',
        activeDay: 1,
        supplies: [],
        showAddEvent: false,
        showSuggestions: false,
        showTour: false,
        activeGapStart: null,
        activeGapEnd: null,
        aiSuggestions: [],
        themeMode: 'system',
        highContrast: false,
        reducedMotion: false,
        hideBudget: false,
        showCarbonBudget: false,
        hideTravelVault: false,
        dayEndHour: 23,
        currencyByTrip: {},
        userId: null,
        tripDbId: null,
        authUser: null,
        tripEntryCountries: null,
        demoClickCount: 0,
        lastSyncError: null,
        pendingInvitations: [],
        termsAccepted: false,
        lastSessionAt: null,
        isOffline: false,
        pendingChanges: [],
        isGlobalLoading: false,
        pendingDeleteIds: [],
        lastBudgetAlert: null,
        acceptTerms: async (contentHash, content)=>{
            try {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbSavePrivacyConsent"])(contentHash, content);
            } catch  {}
            set({
                termsAccepted: true
            });
        },
        setScreen: (s)=>set({
                screen: s
            }),
        checkAuth: async ()=>{
            const user = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentUser"])();
            // Don't reset authUser to null here — sign-out is handled by onAuthStateChange in AppShell.
            // Only update the store when a user is actually found.
            if (!user) return;
            // Check whether this user has already accepted the current terms version.
            // Keep the persisted value as the default — only override it when the DB
            // returns a definitive answer (a record exists). Never downgrade true→false
            // just because the DB returned null (could be RLS or no record yet).
            let termsAccepted = get().termsAccepted;
            try {
                const consent = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbGetPrivacyConsent"])(user.id);
                if (consent !== null) {
                    termsAccepted = consent.content_hash === __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TERMS_VERSION"];
                }
            } catch  {}
            // Set identity so auth-dependent effects (join-link, terms) can proceed immediately.
            // Keep tripDbId as a session reminder (max 2 days) but don't auto-navigate into the trip.
            const TWO_DAYS_MS = 2 * 24 * 60 * 60 * 1000;
            const { tripDbId: persistedTripDbId, lastSessionAt } = get();
            const sessionExpired = lastSessionAt !== null && Date.now() - lastSessionAt > TWO_DAYS_MS;
            const reminderTripId = !sessionExpired && persistedTripDbId ? persistedTripDbId : null;
            set({
                authUser: user,
                userId: user.id,
                termsAccepted,
                trip: null,
                supplies: [],
                tripDbId: reminderTripId,
                lastSessionAt: Date.now()
            });
        },
        signInWithGoogle: async ()=>{
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signInWithGoogle"])();
        },
        loadDemoTrip: ()=>{
            set({
                showTour: !localStorage.getItem('trippy-tour-done'),
                trip: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MOCK_TRIP"],
                supplies: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mockData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MOCK_SUPPLIES"],
                nickname: 'Traveler',
                screen: 'dashboard',
                activeDay: 1,
                tripDbId: null
            });
        },
        loadInvitations: async ()=>{
            try {
                const invitations = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbGetInvitations"])();
                set({
                    pendingInvitations: invitations
                });
            } catch  {}
        },
        acceptInvitation: async (invitationId)=>{
            const { authUser } = get();
            if (!authUser) throw new Error('Not authenticated');
            const initials = authUser.username.slice(0, 2).toUpperCase();
            const tripId = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAcceptInvitation"])(invitationId, authUser.id, initials);
            set((s)=>({
                    pendingInvitations: s.pendingInvitations.filter((i)=>i.id !== invitationId)
                }));
            await get().loadTripById(tripId);
        },
        rejectInvitation: async (invitationId)=>{
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbRejectInvitation"])(invitationId);
            set((s)=>({
                    pendingInvitations: s.pendingInvitations.filter((i)=>i.id !== invitationId)
                }));
        },
        inviteToTrip: async (email)=>{
            const { tripDbId } = get();
            if (!tripDbId) throw new Error('No active trip');
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbInviteToTrip"])(tripDbId, email);
        },
        createInviteLink: async ()=>{
            const { tripDbId } = get();
            if (!tripDbId) throw new Error('No active trip');
            const r = await fetch(`/api/trips/${tripDbId}/invite-link`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({})
            });
            const body = await r.json().catch(()=>({}));
            if (!r.ok) throw new Error(body.error ?? 'Failed to create invite link');
            return `${window.location.origin}/join/${body.token}`;
        },
        clearTripEntry: ()=>set({
                tripEntryCountries: null
            }),
        recordDemoClick: ()=>set((s)=>({
                    demoClickCount: s.demoClickCount + 1
                })),
        setThemeMode: (mode)=>set({
                themeMode: mode
            }),
        toggleHighContrast: ()=>set((s)=>({
                    highContrast: !s.highContrast
                })),
        toggleReducedMotion: ()=>set((s)=>({
                    reducedMotion: !s.reducedMotion
                })),
        toggleHideBudget: ()=>set((s)=>({
                    hideBudget: !s.hideBudget
                })),
        toggleShowCarbonBudget: ()=>set((s)=>({
                    showCarbonBudget: !s.showCarbonBudget
                })),
        toggleHideTravelVault: ()=>set((s)=>({
                    hideTravelVault: !s.hideTravelVault
                })),
        setDayEndHour: (h)=>set({
                dayEndHour: h
            }),
        setCurrency: (code)=>set((s)=>({
                    currencyByTrip: {
                        ...s.currencyByTrip,
                        ...s.tripDbId ? {
                            [s.tripDbId]: code
                        } : {}
                    }
                })),
        loadTripById: async (tripId)=>{
            const { authUser, trip: localTrip, tripDbId: localTripDbId, nickname: storedNickname } = get();
            // Preserve any custom nickname the user already set; only fall back to authUser.username on first load
            const nickname = storedNickname || (authUser?.username ?? 'Traveler');
            let userId = authUser?.id ?? null;
            if (!userId) userId = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSessionUserId"])();
            if (!userId) throw new Error('not_authed');
            set({
                isGlobalLoading: true
            });
            try {
                const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbLoadTripById"])(tripId);
                if (!data) throw new Error('not_found');
                const { trip: dbTrip, supplies } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rowToTrip"])(data);
                // If this is the same trip we had locally, merge pending events before overwriting
                const isSameTrip = localTripDbId === data.id;
                let trip = isSameTrip ? mergeLocalIntoDbTrip(dbTrip, localTrip, data.id, userId, (msg)=>console.warn('[bgSync] pending event failed:', msg)) : dbTrip;
                // Filter out events that are currently being deleted (prevents race condition
                // where realtime subscription triggers loadTripById before DB delete commits)
                const { pendingDeleteIds } = get();
                if (pendingDeleteIds.length > 0) {
                    const deleteSet = new Set(pendingDeleteIds);
                    const filteredEvents = {};
                    for (const [day, evs] of Object.entries(trip.events)){
                        filteredEvents[Number(day)] = evs.filter((e)=>!deleteSet.has(e.id));
                    }
                    trip = {
                        ...trip,
                        events: filteredEvents
                    };
                }
                const { screen: currentScreen } = get();
                const navUpdate = isSameTrip && currentScreen !== 'login' && currentScreen !== 'home' ? {} // preserve current screen/activeDay when refreshing an already-open trip
                 : {
                    screen: 'dashboard',
                    activeDay: 1
                };
                set({
                    userId,
                    tripDbId: data.id,
                    trip,
                    supplies,
                    nickname,
                    ...navUpdate,
                    tripEntryCountries: !isSameTrip && trip.countries?.length ? trip.countries : null,
                    isGlobalLoading: false
                });
            } catch (err) {
                set({
                    isGlobalLoading: false
                });
                throw err?.message === 'not_authed' || err?.message === 'not_found' ? err : new Error('load_failed');
            }
        },
        createTrip: async (name, days, nickname, theme = 'desert', startDate, countries, currency = 'USD')=>{
            const defaultEmoji = theme === 'city' ? 'museum' : theme === 'beach' ? 'beach' : theme === 'nature' ? 'pine_tree' : theme === 'mountain' ? 'mountain' : theme === 'snow' ? 'snow' : 'compass';
            const dayMetas = Array.from({
                length: days
            }, (_, i)=>({
                    region: `Day ${i + 1}`,
                    emoji: defaultEmoji,
                    lat: 31,
                    lng: 35,
                    desc: ''
                }));
            // Save to DB first — throws on failure so LoginScreen can show a meaningful error
            const userId = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSessionUserId"])();
            if (!userId) throw new Error('Not authenticated');
            const newTrip = {
                name,
                days,
                theme,
                countries: countries?.length ? countries : undefined,
                startDate: startDate || new Date().toISOString().split('T')[0],
                participants: [
                    {
                        id: 1,
                        name: nickname || 'You',
                        initials: (nickname || 'Y').slice(0, 2).toUpperCase(),
                        color: 'oklch(62% 0.15 195)'
                    }
                ],
                dayMeta: dayMetas,
                events: Object.fromEntries(Array.from({
                    length: days
                }, (_, i)=>[
                        i + 1,
                        []
                    ])),
                createdBy: userId
            };
            set({
                isGlobalLoading: true
            });
            try {
                const tripDbId = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbCreateTrip"])(userId, name, days, newTrip.startDate, theme, dayMetas, nickname, countries);
                set((s)=>({
                        userId,
                        tripDbId,
                        trip: newTrip,
                        nickname: nickname || 'Traveler',
                        screen: 'dashboard',
                        activeDay: 1,
                        supplies: [],
                        tripEntryCountries: countries?.length ? countries : null,
                        currencyByTrip: {
                            ...s.currencyByTrip,
                            [tripDbId]: currency
                        },
                        isGlobalLoading: false
                    }));
            } catch (err) {
                set({
                    isGlobalLoading: false
                });
                throw err;
            }
        },
        deleteAccount: async ()=>{
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbDeleteAccount"])();
            if (typeof document !== 'undefined') {
                document.cookie.split(';').forEach((c)=>{
                    const name = c.split('=')[0].trim();
                    if (name.startsWith('sb-')) {
                        document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax`;
                    }
                });
            }
            set({
                screen: 'welcome',
                trip: null,
                tripDbId: null,
                supplies: [],
                activeDay: 1,
                aiSuggestions: [],
                userId: null,
                authUser: null,
                nickname: '',
                termsAccepted: false,
                lastSessionAt: null
            });
        },
        // Full sign-out — does NOT remove the user from the trip so they can rejoin later
        logout: ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])().catch(()=>{});
            // Brute-force clear all Supabase auth cookies so onAuthStateChange cannot
            // re-authenticate the user on next page load (guards against path-mismatch
            // cookie deletion failures in signOut()).
            if (typeof document !== 'undefined') {
                document.cookie.split(';').forEach((c)=>{
                    const name = c.split('=')[0].trim();
                    if (name.startsWith('sb-')) {
                        document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax`;
                    }
                });
            }
            set({
                screen: 'welcome',
                trip: null,
                tripDbId: null,
                supplies: [],
                activeDay: 1,
                aiSuggestions: [],
                userId: null,
                authUser: null,
                nickname: '',
                termsAccepted: false,
                lastSessionAt: null
            });
        },
        // Keep the Supabase session but go back to the trip picker
        switchTrip: ()=>{
            set({
                trip: null,
                tripDbId: null,
                nickname: '',
                screen: 'home',
                activeDay: 1,
                aiSuggestions: []
            });
        },
        // Permanently remove the user from this trip's participant list
        leaveTrip: async ()=>{
            const { tripDbId, userId } = get();
            if (tripDbId && userId) await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbLeaveTrip"])(tripDbId, userId);
            set({
                trip: null,
                tripDbId: null,
                nickname: '',
                screen: 'home',
                activeDay: 1,
                aiSuggestions: []
            });
        },
        // Permanently delete the entire trip (owner only)
        deleteTrip: async ()=>{
            const { tripDbId } = get();
            if (tripDbId) await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbDeleteTrip"])(tripDbId);
            set({
                trip: null,
                tripDbId: null,
                nickname: '',
                screen: 'home',
                activeDay: 1,
                aiSuggestions: []
            });
        },
        setActiveDay: (day)=>set({
                activeDay: day
            }),
        setNickname: (n)=>set({
                nickname: n
            }),
        updateTripInfo: ({ name, days, startDate, countries })=>set((s)=>{
                if (!s.trip) return {};
                const trip = {
                    ...s.trip
                };
                if (name !== undefined) trip.name = name;
                if (startDate !== undefined) trip.startDate = startDate;
                if (countries !== undefined) trip.countries = countries;
                if (days !== undefined && days >= 1 && days <= 90) {
                    const old = trip.days;
                    trip.days = days;
                    if (days > old) {
                        const defaultEmoji = trip.theme === 'city' ? '🏙️' : trip.theme === 'beach' ? '🏖️' : trip.theme === 'nature' ? '🌲' : '🏔️';
                        const extraMeta = Array.from({
                            length: days - old
                        }, (_, i)=>({
                                region: `Day ${old + i + 1}`,
                                emoji: defaultEmoji,
                                lat: 31,
                                lng: 35,
                                desc: ''
                            }));
                        trip.dayMeta = [
                            ...trip.dayMeta,
                            ...extraMeta
                        ];
                        const extraEvents = {};
                        for(let d = old + 1; d <= days; d++)extraEvents[d] = [];
                        trip.events = {
                            ...trip.events,
                            ...extraEvents
                        };
                    } else if (days < old) {
                        trip.dayMeta = trip.dayMeta.slice(0, days);
                        const trimmedEvents = {};
                        for(let d = 1; d <= days; d++)trimmedEvents[d] = trip.events[d] ?? [];
                        trip.events = trimmedEvents;
                    }
                }
                const { tripDbId } = s;
                if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateTripInfo"])(tripDbId, {
                    name,
                    days,
                    startDate,
                    countries
                }).catch((err)=>set({
                        lastSyncError: err?.message ?? 'save_failed'
                    }));
                const newState = {
                    trip
                };
                if (days !== undefined && s.activeDay > trip.days) newState.activeDay = trip.days;
                return newState;
            }),
        updateTheme: (theme)=>set((s)=>{
                const { tripDbId } = s;
                if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateTripTheme"])(tripDbId, theme).catch((err)=>set({
                        lastSyncError: err?.message ?? 'save_failed'
                    }));
                return {
                    trip: s.trip ? {
                        ...s.trip,
                        theme
                    } : null
                };
            }),
        updateDayMeta: (dayIndex, meta)=>set((s)=>{
                if (!s.trip) return {};
                const dayMeta = [
                    ...s.trip.dayMeta
                ];
                dayMeta[dayIndex] = {
                    ...dayMeta[dayIndex],
                    ...meta
                };
                const { tripDbId } = s;
                if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateDayMeta"])(tripDbId, dayIndex, meta).catch((err)=>set({
                        lastSyncError: err?.message ?? 'save_failed'
                    }));
                return {
                    trip: {
                        ...s.trip,
                        dayMeta
                    }
                };
            }),
        addEvent: (dayNumber, event)=>{
            const { trip, tripDbId } = get();
            if (!trip) return;
            const newEvent = {
                ...event,
                id: uid(),
                addedBy: get().nickname || 'You'
            };
            const dayEvents = [
                ...trip.events[dayNumber] || [],
                newEvent
            ];
            set({
                trip: {
                    ...trip,
                    events: {
                        ...trip.events,
                        [dayNumber]: dayEvents
                    }
                }
            });
            if (tripDbId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSessionUserId"])().then((sessionUserId)=>{
                    if (!sessionUserId) {
                        set({
                            lastSyncError: 'not_authed'
                        });
                        return;
                    }
                    if (sessionUserId !== get().userId) set({
                        userId: sessionUserId
                    });
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAddEvent"])(tripDbId, dayNumber, newEvent, sessionUserId);
                }).catch((err)=>{
                    console.error('[addEvent] DB sync failed:', err);
                    set({
                        lastSyncError: err?.message ?? 'save_failed'
                    });
                });
            }
        },
        editEvent: (dayNumber, eventId, updates)=>{
            const { trip, tripDbId } = get();
            if (!trip) return;
            const dayEvents = (trip.events[dayNumber] || []).map((e)=>e.id === eventId ? {
                    ...e,
                    ...updates
                } : e);
            set({
                trip: {
                    ...trip,
                    events: {
                        ...trip.events,
                        [dayNumber]: dayEvents
                    }
                }
            });
            if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbEditEvent"])(eventId, {
                ...updates,
                tripId: tripDbId
            }).catch((err)=>{
                console.error('[editEvent] DB sync failed:', err);
                set({
                    lastSyncError: err?.message ?? 'sync_failed'
                });
            });
        },
        deleteEvent: (dayNumber, eventId)=>{
            const { trip, tripDbId } = get();
            if (!trip) return;
            const originalEvents = trip.events[dayNumber] || [];
            const dayEvents = originalEvents.filter((e)=>e.id !== eventId);
            // Add to pendingDeleteIds before local state update so loadTripById cannot restore it
            set((s)=>s.trip ? {
                    trip: {
                        ...s.trip,
                        events: {
                            ...s.trip.events,
                            [dayNumber]: dayEvents
                        }
                    },
                    pendingDeleteIds: [
                        ...s.pendingDeleteIds,
                        eventId
                    ]
                } : {
                    pendingDeleteIds: [
                        ...s.pendingDeleteIds,
                        eventId
                    ]
                });
            if (tripDbId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbDeleteEvent"])(eventId, tripDbId).then(()=>{
                    set((s)=>({
                            pendingDeleteIds: s.pendingDeleteIds.filter((id)=>id !== eventId)
                        }));
                }).catch((err)=>{
                    console.error('[deleteEvent] DB sync failed:', err);
                    // Rollback: restore the event into its day
                    set((s)=>{
                        const currentDay = s.trip?.events[dayNumber] || [];
                        const victim = originalEvents.find((e)=>e.id === eventId);
                        const updatedDay = victim && !currentDay.some((e)=>e.id === eventId) ? [
                            ...currentDay,
                            victim
                        ] : currentDay;
                        return {
                            trip: s.trip ? {
                                ...s.trip,
                                events: {
                                    ...s.trip.events,
                                    [dayNumber]: updatedDay
                                }
                            } : null,
                            pendingDeleteIds: s.pendingDeleteIds.filter((id)=>id !== eventId),
                            lastSyncError: err?.message ?? 'sync_failed'
                        };
                    });
                });
            } else {
                set((s)=>({
                        pendingDeleteIds: s.pendingDeleteIds.filter((id)=>id !== eventId)
                    }));
            }
        },
        moveEvent: (fromDay, toDay, eventId)=>{
            const { trip, tripDbId } = get();
            if (!trip) return;
            const event = (trip.events[fromDay] ?? []).find((e)=>e.id === eventId);
            if (!event) return;
            const fromEvents = (trip.events[fromDay] ?? []).filter((e)=>e.id !== eventId);
            const toEvents = [
                ...trip.events[toDay] ?? [],
                event
            ];
            set({
                trip: {
                    ...trip,
                    events: {
                        ...trip.events,
                        [fromDay]: fromEvents,
                        [toDay]: toEvents
                    }
                }
            });
            if (tripDbId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbMoveEvent"])(eventId, toDay, tripDbId).catch((err)=>{
                    console.error('[moveEvent] DB sync failed:', err);
                    set({
                        lastSyncError: err?.message ?? 'sync_failed'
                    });
                });
            }
        },
        addHotel: (hotel)=>{
            const { tripDbId } = get();
            const newHotel = {
                ...hotel,
                id: uid()
            };
            set((s)=>{
                const trip = s.trip ? {
                    ...s.trip,
                    hotels: [
                        ...s.trip.hotels ?? [],
                        newHotel
                    ]
                } : null;
                if (tripDbId && trip?.hotels) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateHotels"])(tripDbId, trip.hotels).catch((err)=>{
                        console.error('[addHotel] DB sync failed:', err);
                        // Only show error if still on the same trip (avoid stale async errors on trip switch)
                        if (get().tripDbId === tripDbId) set({
                            lastSyncError: err?.message ?? 'save_failed'
                        });
                    });
                }
                return {
                    trip
                };
            });
        },
        editHotel: (id, updates)=>{
            const { tripDbId } = get();
            set((s)=>{
                const trip = s.trip ? {
                    ...s.trip,
                    hotels: (s.trip.hotels ?? []).map((h)=>h.id === id ? {
                            ...h,
                            ...updates
                        } : h)
                } : null;
                if (tripDbId && trip?.hotels) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateHotels"])(tripDbId, trip.hotels).catch((err)=>{
                        console.error('[editHotel] DB sync failed:', err);
                        if (get().tripDbId === tripDbId) set({
                            lastSyncError: err?.message ?? 'save_failed'
                        });
                    });
                }
                return {
                    trip
                };
            });
        },
        deleteHotel: (id)=>{
            const { tripDbId } = get();
            set((s)=>{
                const hotels = (s.trip?.hotels ?? []).filter((h)=>h.id !== id);
                const trip = s.trip ? {
                    ...s.trip,
                    hotels
                } : null;
                if (tripDbId) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateHotels"])(tripDbId, hotels).catch((err)=>{
                        console.error('[deleteHotel] DB sync failed:', err);
                        if (get().tripDbId === tripDbId) set({
                            lastSyncError: err?.message ?? 'save_failed'
                        });
                    });
                }
                return {
                    trip
                };
            });
        },
        voteEvent: (dayNumber, eventId, nickname, vote)=>{
            const { trip, tripDbId } = get();
            if (!trip) return;
            let updatedVotes = {};
            const dayEvents = (trip.events[dayNumber] || []).map((e)=>{
                if (e.id !== eventId) return e;
                const votes = {
                    ...e.votes ?? {}
                };
                if (votes[nickname] === vote) delete votes[nickname];
                else votes[nickname] = vote;
                updatedVotes = votes;
                return {
                    ...e,
                    votes
                };
            });
            set({
                trip: {
                    ...trip,
                    events: {
                        ...trip.events,
                        [dayNumber]: dayEvents
                    }
                }
            });
            if (tripDbId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateEventVotes"])(eventId, updatedVotes, tripDbId).catch((err)=>{
                    set({
                        lastSyncError: err?.message ?? 'vote_sync_failed'
                    });
                });
            }
        },
        toggleSupply: (id)=>{
            const { tripDbId } = get();
            set((s)=>{
                const supplies = s.supplies.map((i)=>i.id === id ? {
                        ...i,
                        checked: !i.checked
                    } : i);
                const item = supplies.find((i)=>i.id === id);
                if (tripDbId && item) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbToggleSupply"])(id, item.checked, tripDbId).catch((err)=>set({
                        lastSyncError: err?.message ?? 'save_failed'
                    }));
                return {
                    supplies
                };
            });
        },
        addSupplyItem: (name, category, assignee, critical)=>{
            const { tripDbId } = get();
            const newItem = {
                id: uid(),
                name,
                category,
                checked: false,
                assignee,
                critical: critical ?? false
            };
            set((s)=>({
                    supplies: [
                        ...s.supplies,
                        newItem
                    ]
                }));
            if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAddSupply"])(tripDbId, newItem).catch((err)=>set({
                    lastSyncError: err?.message ?? 'save_failed'
                }));
        },
        deleteSupplyItem: (id)=>{
            const { tripDbId } = get();
            set((s)=>({
                    supplies: s.supplies.filter((i)=>i.id !== id)
                }));
            if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbDeleteSupply"])(id, tripDbId).catch((err)=>set({
                    lastSyncError: err?.message ?? 'save_failed'
                }));
        },
        toggleSupplyCritical: (id)=>set((s)=>{
                const supplies = s.supplies.map((i)=>i.id === id ? {
                        ...i,
                        critical: !i.critical
                    } : i);
                const item = supplies.find((i)=>i.id === id);
                if (s.tripDbId && item) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateSupplyCritical"])(id, item.critical ?? false, s.tripDbId).catch((err)=>set({
                        lastSyncError: err?.message ?? 'save_failed'
                    }));
                return {
                    supplies
                };
            }),
        addTripNote: (note)=>{
            const { tripDbId } = get();
            set((s)=>{
                const trip = s.trip ? {
                    ...s.trip,
                    tripNotes: [
                        ...s.trip.tripNotes ?? [],
                        note
                    ]
                } : null;
                if (tripDbId && trip?.tripNotes) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateTripNotes"])(tripDbId, trip.tripNotes).catch((err)=>set({
                        lastSyncError: err?.message ?? 'save_failed'
                    }));
                return {
                    trip
                };
            });
        },
        deleteTripNote: (index)=>{
            const { tripDbId } = get();
            set((s)=>{
                const trip = s.trip ? {
                    ...s.trip,
                    tripNotes: (s.trip.tripNotes ?? []).filter((_, i)=>i !== index)
                } : null;
                if (tripDbId && trip?.tripNotes) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbUpdateTripNotes"])(tripDbId, trip.tripNotes).catch((err)=>set({
                        lastSyncError: err?.message ?? 'save_failed'
                    }));
                return {
                    trip
                };
            });
        },
        addExpense: (exp)=>{
            const { userId, tripDbId, trip } = get();
            const newExp = {
                ...exp,
                id: uid()
            };
            set((s)=>({
                    trip: s.trip ? {
                        ...s.trip,
                        expenses: [
                            ...s.trip.expenses ?? [],
                            newExp
                        ]
                    } : null
                }));
            if (tripDbId && userId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAddExpense"])(tripDbId, newExp, userId).catch((err)=>set({
                    lastSyncError: err?.message ?? 'save_failed'
                }));
            // Smart Budget Alerts — fire when crossing 80% or 100% of budget limit
            const budget = trip?.budget ?? 0;
            if (budget > 0) {
                const prevTotal = (trip?.expenses ?? []).reduce((s, e)=>s + e.amount, 0);
                const newTotal = prevTotal + newExp.amount;
                const prevPct = prevTotal / budget;
                const newPct = newTotal / budget;
                if (newPct >= 1.0 && prevPct < 1.0) {
                    set({
                        lastBudgetAlert: {
                            type: 'over',
                            amount: newTotal,
                            remaining: newTotal - budget
                        }
                    });
                } else if (newPct >= 0.8 && prevPct < 0.8) {
                    set({
                        lastBudgetAlert: {
                            type: 'eighty',
                            amount: newTotal,
                            remaining: budget - newTotal
                        }
                    });
                }
            }
        },
        setTripBudget: (budget)=>{
            set((s)=>({
                    trip: s.trip ? {
                        ...s.trip,
                        budget
                    } : null
                }));
        },
        deleteExpense: (id)=>{
            const { tripDbId } = get();
            set((s)=>({
                    trip: s.trip ? {
                        ...s.trip,
                        expenses: (s.trip.expenses ?? []).filter((e)=>e.id !== id)
                    } : null
                }));
            if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbDeleteExpense"])(id, tripDbId).catch((err)=>set({
                    lastSyncError: err?.message ?? 'save_failed'
                }));
        },
        addEmergencyContact: (contact)=>{
            const { tripDbId } = get();
            const newContact = {
                ...contact,
                id: uid()
            };
            set((s)=>({
                    trip: s.trip ? {
                        ...s.trip,
                        emergencyContacts: [
                            ...s.trip.emergencyContacts ?? [],
                            newContact
                        ]
                    } : null
                }));
            if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAddEmergencyContact"])(tripDbId, newContact).catch((err)=>set({
                    lastSyncError: err?.message ?? 'save_failed'
                }));
        },
        deleteEmergencyContact: (id)=>{
            const { tripDbId } = get();
            set((s)=>({
                    trip: s.trip ? {
                        ...s.trip,
                        emergencyContacts: (s.trip.emergencyContacts ?? []).filter((c)=>c.id !== id)
                    } : null
                }));
            if (tripDbId) (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbDeleteEmergencyContact"])(id, tripDbId).catch((err)=>set({
                    lastSyncError: err?.message ?? 'save_failed'
                }));
        },
        setShowAddEvent: (v)=>set({
                showAddEvent: v
            }),
        setShowTour: (v)=>{
            if (!v && ("TURBOPACK compile-time value", "object") !== 'undefined') localStorage.setItem('trippy-tour-done', '1');
            set({
                showTour: v
            });
        },
        setShowSuggestions: (v, gapStart, gapEnd)=>set({
                showSuggestions: v,
                activeGapStart: gapStart ?? null,
                activeGapEnd: gapEnd ?? null
            }),
        setAiSuggestions: (suggestions)=>set({
                aiSuggestions: suggestions
            }),
        addSuggestionToDay: (dayNumber, suggId)=>{
            const { trip, aiSuggestions, userId, tripDbId } = get();
            if (!trip) return;
            const sugg = aiSuggestions.find((s)=>s.id === suggId);
            if (!sugg) return;
            const newEvent = {
                id: uid(),
                time: sugg.time,
                duration: sugg.duration,
                name: sugg.name,
                category: sugg.category,
                addedBy: get().nickname || 'AI',
                cost: sugg.cost,
                location: sugg.location
            };
            const dayEvents = [
                ...trip.events[dayNumber] || [],
                newEvent
            ];
            set({
                trip: {
                    ...trip,
                    events: {
                        ...trip.events,
                        [dayNumber]: dayEvents
                    }
                },
                showSuggestions: false
            });
            if (tripDbId) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSessionUserId"])().then((sessionUserId)=>{
                    if (!sessionUserId) {
                        set({
                            lastSyncError: 'not_authed'
                        });
                        return;
                    }
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAddEvent"])(tripDbId, dayNumber, newEvent, sessionUserId);
                }).catch((err)=>set({
                        lastSyncError: err?.message ?? 'save_failed'
                    }));
            }
        },
        subscribeToTrip: (tripId)=>{
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            const channel = supabase.channel(`trip:${tripId}`).on('postgres_changes', {
                event: 'UPDATE',
                schema: 'public',
                table: 'trips',
                filter: `id=eq.${tripId}`
            }, (payload)=>{
                // Guard: only act on changes for the active trip (defence-in-depth)
                const changedId = payload.new?.id ?? payload.old?.id;
                if (changedId && changedId !== tripId) return;
                get().loadTripById(tripId).catch(()=>{});
            }).subscribe();
            return ()=>{
                supabase.removeChannel(channel);
            };
        },
        setGlobalLoading: (v)=>set({
                isGlobalLoading: v
            }),
        setIsOffline: (v)=>set({
                isOffline: v
            }),
        addPendingChange: (change)=>set((state)=>({
                    pendingChanges: [
                        ...state.pendingChanges,
                        change
                    ]
                })),
        flushPendingChanges: async ()=>{
            const { pendingChanges, tripDbId, userId } = get();
            if (!pendingChanges.length || !tripDbId || !userId) return;
            // Replay each pending change in order
            for (const change of pendingChanges){
                try {
                    const { trip: currentTrip } = get();
                    if (!currentTrip) continue;
                    const p = change.payload;
                    if (change.type === 'addEvent') {
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAddEvent"])(tripDbId, p.dayNumber, p.event, userId);
                    } else if (change.type === 'deleteEvent') {
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbDeleteEvent"])(p.eventId, tripDbId);
                    } else if (change.type === 'addExpense') {
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbAddExpense"])(tripDbId, p.expense, userId);
                    } else if (change.type === 'deleteExpense') {
                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dbDeleteExpense"])(p.expenseId, tripDbId);
                    }
                    // Remove this change on success
                    set((state)=>({
                            pendingChanges: state.pendingChanges.filter((c)=>c.timestamp !== change.timestamp)
                        }));
                } catch  {
                    break;
                }
            }
        }
    }), {
    name: 'trippy-storage',
    partialize: (s)=>({
            trip: s.trip,
            nickname: s.nickname,
            activeDay: s.activeDay,
            supplies: s.supplies,
            themeMode: s.themeMode,
            highContrast: s.highContrast,
            reducedMotion: s.reducedMotion,
            hideBudget: s.hideBudget,
            showCarbonBudget: s.showCarbonBudget,
            hideTravelVault: s.hideTravelVault,
            dayEndHour: s.dayEndHour,
            currencyByTrip: s.currencyByTrip,
            userId: s.userId,
            tripDbId: s.tripDbId,
            authUser: s.authUser,
            termsAccepted: s.termsAccepted,
            pendingChanges: s.pendingChanges,
            lastSessionAt: s.lastSessionAt
        })
}));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/i18n.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "I18nProvider",
    ()=>I18nProvider,
    "useI18n",
    ()=>useI18n
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const en = {
    appName: 'Trippy',
    appTagline: 'Plan. Explore. Experience.',
    joinTrip: 'Join a Trip',
    createNewTrip: 'Plan a New Trip',
    tripName: 'Trip Name',
    tripCode: 'Trip Code',
    yourNickname: 'Your Nickname',
    joinBtn: 'Let\'s Go',
    tryDemo: '💡 Explore the demo',
    demoTripName: 'Trip Name',
    demoTripCode: 'Trip Code',
    demoNickname: 'Nickname',
    demoAnything: 'anything',
    numDays: 'Number of Days',
    chooseCode: 'Trip Code (min 6 chars)',
    confirmCode: 'Confirm Code',
    createBtn: 'Start the Adventure',
    navCamp: 'Dashboard',
    navExplore: 'Explore',
    navPack: 'Pack',
    navSetup: 'Settings',
    activeTrip: 'Current Trip',
    days: 'days',
    hi: 'Hey',
    yourJourney: 'Itinerary',
    day: 'Day',
    suppliesLabel: 'Packing',
    packed: 'Packed',
    backToDashboard: 'Back',
    addBtn: 'Add',
    freeTime: 'free',
    suggestBtn: 'Get AI Ideas',
    addEvent: 'Add Activity',
    editEvent: 'Edit Activity',
    eventName: 'Activity Name',
    startTime: 'Start Time',
    duration: 'Duration',
    category: 'Category',
    locationOpt: 'Location (optional)',
    notesOpt: 'Notes (optional)',
    cancel: 'Cancel',
    saveChanges: 'Save',
    tapToAdd: 'Tap any slot or hit + to start building your day',
    packList: 'Pack List',
    addItem: 'Add Item',
    itemNamePlaceholder: 'Item name…',
    setupTitle: 'Settings',
    setupSub: 'Make Trippy yours',
    tripInfo: 'Trip Summary',
    nameLabel: 'Name',
    daysLabel: 'Days',
    startLabel: 'Start',
    eventsLabel: 'Activities',
    participantsLabel: 'Crew',
    myProfile: 'My Profile',
    languageLabel: 'Language',
    exportTrip: 'Export',
    exportJSON: 'Download JSON',
    exportJSONSub: 'Backup or re-import',
    exportMD: 'Download Markdown',
    exportMDSub: 'Share in chats',
    exportPDF: 'Download PDF',
    exportPDFSub: 'Printable itinerary',
    aboutLabel: 'About',
    leaveTrip: 'Leave Trip',
    saveBtn: 'Save',
    shareTrip: 'Share',
    shareSub: 'Invite your crew',
    total: 'total',
    events: 'activities',
    gaps: 'gap',
    gapsPlural: 'gaps',
    notSet: 'Not set',
    noItemsCategory: 'Nothing in this category yet',
    of: 'of',
    items: 'items',
    english: '🇺🇸 English',
    hebrew: '🇮🇱 עברית',
    aiSuggestions: 'AI Ideas',
    aiSugSub: 'Tailored to your day and location',
    scanningNearby: 'Scanning nearby spots…',
    noSuggestions: 'No ideas yet — check back soon',
    noMoreSuggestions: 'No more ideas for this gap.',
    tryAddingEvents: 'Add activities to open up new gaps for suggestions.',
    dismiss: 'Dismiss',
    addToDay: 'Add to Day',
    close: 'Close',
    open: 'Open',
    closed: 'Closed',
    copyToClipboard: 'Copy',
    tripExportedJSON: 'Trip exported as JSON ✓',
    tripExportedMD: 'Trip exported as Markdown ✓',
    tripExportedPDF: 'Trip exported as PDF ✓',
    pdfComingSoon: 'PDF export coming in v2',
    pdfNoEvents: 'No activities scheduled.',
    pdfStarts: 'starts',
    pdfPopupBlocked: 'Allow pop-ups to export PDF',
    eventAdded: 'Activity added ✓',
    eventUpdated: 'Activity updated ✓',
    eventRemoved: 'Activity removed',
    itemAdded: 'Item added ✓',
    itemRemoved: 'Item removed',
    nicknameUpdated: 'Nickname updated ✓',
    copied: 'Copied!',
    enterTripNameCode: 'Enter trip name and code',
    enterNickname: 'Pick a nickname',
    tripNotFound: 'Trip not found — double-check the name and code',
    createTripFailed: 'Something went wrong — please try again',
    emailConfirmRequired: 'Please disable "Confirm email" in Supabase → Authentication → Settings',
    signInWithGoogle: 'Continue with Google',
    webViewWarning: "You're in an in-app browser. Tap the menu (⋮ or …) and choose \"Open in Chrome\" or \"Open in browser\" to sign in with Google.",
    countriesLabel: 'Destination countries',
    countriesPlaceholder: 'e.g. Israel, France, Italy',
    registerNudgeTitle: 'Loving Trippy?',
    registerNudgeSub: 'Save your adventures with a free account.',
    usernameLabel: 'Username',
    passwordLabel: 'Password',
    confirmPasswordLabel: 'Confirm Password',
    loginBtn: 'Log In',
    registerBtn: 'Create Account',
    switchToRegister: "Don't have an account? Sign up",
    switchToLogin: 'Already have an account? Log in',
    signInPrompt: 'Sign in to create or join a trip',
    signedInAs: 'Signed in as',
    signOut: 'Sign out',
    usernamePlaceholder: 'e.g. dana123',
    passwordPlaceholder: 'Min 6 characters',
    passwordsMismatch: 'Passwords don\'t match',
    usernameTaken: 'That username is taken — try another',
    loginFailed: 'Wrong username or password',
    registrationFailed: 'Sign-up failed — try a different username',
    enterTripName: 'Give your trip a name first',
    codeTooShort: 'Code must be at least 6 characters',
    codesNoMatch: 'Codes don\'t match',
    enterEventName: 'Give this activity a name',
    enterItemName: 'Give this item a name',
    weather34: '34°C · Sunny',
    windUV: 'Wind 12 km/h · UV index 9 — High protection needed',
    appVersion: 'v1.0.0',
    appStack: 'Next.js · Zustand · Liquid Glass',
    editingLabel: 'Editing',
    nextEvent: 'Next Up',
    comingUp: 'Coming Up',
    tripInsights: 'Trip Insights',
    quickAdd: 'Quick Add',
    noUpcomingEvents: 'Nothing coming up — enjoy the moment!',
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',
    goldenHourSunset: '🌅 Golden Hour',
    goldenHourSunrise: '🌄 Sunrise',
    conflictWarning: '⚠️ Overlap',
    costLabel: 'Cost (optional)',
    costPlaceholder: 'e.g. 25',
    dayBudget: 'Day total',
    tripBudget: 'Est. Budget',
    votesUp: 'Up votes',
    votesDown: 'Down votes',
    travelNotes: 'Trip Vault',
    travelNotesSub: 'Keep confirmations, visa info & passwords safe',
    addNote: 'Add Note',
    notePlaceholder: 'e.g. Hotel confirmation: ABC123…',
    noNotes: 'Nothing saved yet. Add hotel confirmations, visa details, or anything you\'d hate to forget.',
    navNotes: 'Vault',
    navMap: 'Map',
    navCrew: 'Crew',
    crewTitle: 'Your Crew',
    crewMembers: 'Members',
    crewOwnerLabel: 'Organizer',
    crewMemberLabel: 'Member',
    crewInviteTitle: 'Invite',
    crewInviteByEmail: 'Email invite',
    crewCopyLink: 'Copy invite link',
    crewPending: 'Pending Invitations',
    crewNoMembers: 'No crew yet — invite someone to join the fun!',
    crewKickMember: 'Remove from trip',
    mapTitle: 'Trip Map',
    mapNoEvents: 'No pinned locations yet',
    mapNoEventsHint: 'Add locations to your activities in the Day planner to see them here',
    mapEventCount: '{count} pin',
    mapEventCountPlural: '{count} pins',
    mapAllDays: 'All Days',
    mapDay: 'Day {day}',
    appearanceLabel: 'Appearance',
    highContrast: 'High Contrast',
    highContrastSub: 'Solidifies glass backgrounds and darkens secondary text (WCAG AA)',
    accessibilityLabel: 'Accessibility',
    reduceMotion: 'Reduce Motion',
    reduceMotionSub: 'Disables spring animations to save battery and ease motion sensitivity',
    displayLabel: 'Display',
    hideTravelVault: 'Hide Trip Vault',
    hideTravelVaultSub: 'Removes the Trip Vault section from settings',
    hideBudget: 'Hide Budget Widget',
    hideBudgetSub: 'Removes the budget card from the dashboard',
    carbonBudget: 'Carbon Footprint Widget',
    carbonBudgetSub: 'Shows estimated CO₂ from flights and transport',
    nightOwlLabel: 'Night Owl Mode',
    nightOwlSub: 'Extends the day boundary — keeps late-night activities on the same day card',
    nightOwlStandard: 'Standard (11 PM)',
    nightOwlLate: 'Late (1 AM)',
    nightOwlExtreme: 'Night Owl (3 AM)',
    dayBoundaryUpdated: 'Day boundary updated',
    emergencyHubLabel: 'Emergency Hub',
    emergencyHubSub: 'Offline-ready emergency contacts — always accessible, even without signal',
    emergencyNamePlaceholder: 'Name or organisation',
    emergencyPhonePlaceholder: '+1 555 000 0000',
    emergencySaved: 'Emergency contact saved ✓',
    contactRemoved: 'Contact removed',
    noEmergencyContacts: 'No emergency contacts yet — add at least one before you head out',
    medical: 'Medical',
    embassy: 'Embassy',
    personal: 'Personal',
    insurance: 'Insurance',
    enterNamePhone: 'Enter name and phone number',
    aboutApp: 'App',
    aboutVersion: 'Version',
    aboutStack: 'Stack',
    enterDescAmount: 'Enter a description and amount',
    expenseAdded: 'Expense added ✓',
    expenses: 'Expenses',
    whatFor: 'What\'s this for?',
    paidByDefault: 'Paid by (default: {name})',
    noExpensesYet: 'No expenses logged yet — start tracking!',
    paid: 'paid',
    person: 'person',
    oneDayConflict: 'Day {day} has overlapping activities',
    manyDaysConflict: '{count} days have overlapping activities',
    conflictDesc: 'Overlapping activities detected — tap the day to review',
    oneDayPacked: 'Day {day} is jam-packed',
    manyDaysPacked: '{count} days are overloaded',
    packedDesc: 'No rest window detected — consider adding some breathing room',
    ecoTitle: '~{carbon} kg CO₂ estimated',
    ecoDesc: '{count} flight(s) logged — consider trains for short legs',
    relaxTitle: 'Day {day} — time to relax',
    relaxDesc: '~{hours}h free — the perfect window to unwind',
    gapTitle: 'Day {day} has open time',
    gapDesc: '~{hours}h unplanned — tap AI Ideas to fill it',
    foodTitle: 'Meals not planned',
    foodDesc: '{days} has no food stops scheduled',
    packedTitle: '{pct}% packed',
    packedDesc2: '{count} items still need packing',
    oneDayEmpty: 'Day not planned',
    manyDaysEmpty: '{count} days unplanned',
    oneDayEmptyDesc: 'Day {day} still needs some activities',
    manyDaysEmptyDesc: 'Several days are still empty',
    trackTitle: 'Trip is looking great!',
    trackDesc: '{events} activities planned across {days} days',
    onePerson: '1 person',
    people: 'people',
    everyone: 'Everyone',
    estimatingTravel: 'Estimating travel time…',
    estimatedTravelTime: '🚗 Estimated Travel Time',
    moveToTime: 'Move to',
    confirmMove: 'Confirm move',
    onlineBadge: '● Online',
    offlineBadge: '○ Offline',
    stopSingular: 'stop',
    stopPlural: 'stops',
    overlapCount: 'overlap',
    tagsLabel: 'Tags',
    tagsOptional: 'optional, comma-separated',
    tagsPlaceholder: '"Cash only, Modest dress, Vegan-friendly"',
    editDaySubtitle: 'Set a city name and emoji for this day',
    editDayCityLabel: 'City / Location',
    editDayCityPlaceholder: 'e.g. Paris, Rome, Amsterdam',
    emojiLabel: 'Emoji',
    dayUpdated: 'Day updated ✓',
    driveToAirportTitle: 'Drive to Airport ✈️',
    driveToAirportSub: "How long is the drive? We'll add it before your flight.",
    drivingTimeLabel: 'Driving time (minutes)',
    customMinutesPlaceholder: 'Custom minutes…',
    skipBtn: 'Skip',
    addDriveBtn: 'Add Drive',
    driveAddedToast: 'Airport drive added ✓',
    driveToAirportName: 'Drive to Airport',
    carbonFootprintLabel: 'Carbon Footprint',
    showCode: 'Show',
    hideCode: 'Hide',
    tripUpdated: 'Trip updated ✓',
    undoLabel: 'Undo',
    removedSuffix: 'removed',
    movedToSuffix: 'moved to',
    eventNamePlaceholder: 'e.g. Masada Hike',
    locationFullPlaceholder: 'e.g. Masada, Dead Sea',
    notesFullPlaceholder: 'Any extra info…',
    quickDriveLabel: 'Drive',
    quickMealLabel: 'Meal',
    quickCoffeeLabel: 'Coffee',
    quickRestLabel: 'Rest',
    quickGasLabel: 'Gas',
    quickDriveName: 'Drive',
    quickMealName: 'Meal',
    quickCoffeeName: 'Coffee stop',
    quickRestName: 'Rest stop',
    quickGasName: 'Gas & fuel',
    startDateLabel: 'Start date',
    codeOptional: '(optional)',
    leaveBlankCode: 'Leave blank for a personal trip',
    repeatCode: 'Repeat code',
    myTrips: 'My Trips',
    joinPlaceholderName: 'e.g. Negev Desert Adventure',
    joinPlaceholderCode: 'Shared code',
    joinPlaceholderNick: 'e.g. Dana',
    createPlaceholderName: 'e.g. Europe Adventure 2026',
    createPlaceholderNick: 'e.g. Alex',
    backgroundLabel: 'Theme',
    chooseCodeOptional: 'Trip Code (optional)',
    reduceDaysWarning: 'Reducing to {newDays} days will remove activities on days {from}–{to}. Continue?',
    invitations: 'Invitations',
    invitedToJoin: 'You\'ve been invited to join',
    acceptBtn: 'Accept',
    rejectBtn: 'Decline',
    inviteByEmail: 'Invite someone by email',
    inviteEmailPlaceholder: 'friend@example.com',
    sendInvite: 'Send',
    inviteSent: 'Invitation sent ✓',
    inviteFailed: 'Could not send invitation — try again',
    quickLinkLabel: 'Anyone with this link can join',
    copyLink: '🔗 Copy Invite Link',
    linkCopied: 'Link copied! ✓',
    noLink: 'Could not generate link — try again',
    inviteLimitReached: 'Limit reached — wait for a response before sending more',
    pendingLabel: 'Pending',
    cancelInvite: 'Cancel',
    estCost: 'Est. Cost',
    assigneePlaceholder: 'Assign to (e.g. Mom, Mark) — optional',
    criticalItemsUnpacked: 'CRITICAL ITEMS UNPACKED ⚠️',
    criticalBadge: 'CRITICAL',
    markCritical: 'Mark as critical',
    unmarkCritical: 'Critical — must pack',
    criticalBlocksBar: 'Blocks progress bar from going green',
    currencyLabel: 'Budget Currency',
    currencyChanged: 'Currency updated ✓',
    localEquiv: 'local equiv.',
    weatherLabel: 'Weather',
    tapForWeather: 'Tap for forecast',
    deleteAccount: 'Delete My Data',
    deleteAccountConfirm: 'This will permanently delete your account and personal data. Shared trip content (activities, expenses, notes) will remain for other participants. This cannot be undone. Continue?',
    deleteAccountSuccess: 'Your data has been deleted.',
    deleteAccountFailed: 'Failed to delete account — please try again or contact guy9d2g5@gmail.com.',
    // World Clock (§08_WORLD_CLOCK_TRAVEL §1)
    'worldClock.nowHere': 'now here',
    'worldClock.yourTime': 'Your time',
    'worldClock.sameZone': 'same timezone',
    'worldClock.ahead': '+{h}h ahead',
    'worldClock.behind': '{h}h behind',
    'worldClock.localTime': 'Local time',
    // Route Connector (§08_WORLD_CLOCK_TRAVEL §2.5)
    'routeConnector.expand': 'Show travel options',
    'routeConnector.recommended': 'Recommended',
    'routeConnector.departure': 'Departure at',
    'routeConnector.overlap': '⚠️ Overlap!',
    'routeConnector.tight': 'Tight connection',
    'routeConnector.warning': 'Allow travel time',
    // Timezone Badge (§08_WORLD_CLOCK_TRAVEL §3)
    'timezoneBadge.change': 'Timezone change',
    'timezoneBadge.nowIn': 'Now in',
    // Map
    'map.noCoords': 'This activity has no location',
    // Crew
    'crew.linkCopied': 'Link copied!',
    // Expense settlement
    'settlement.title': 'Who Owes Who',
    'settlement.owes': '{from} owes {to}',
    'settlement.settled': 'All square — no debts!',
    // Budget alerts
    'budget.eightyPct': '{remaining} left in budget',
    'budget.over': '{amount} over budget',
    // Vibe quiz
    'vibe.explorer': 'Explorer',
    'vibe.relaxed': 'Relaxed',
    'vibe.foodie': 'Foodie',
    'vibe.budget': 'Budget-smart',
    'vibe.balanced': 'Balanced',
    // Demo Data
    'Morning camp breakfast': 'Morning camp breakfast',
    'Makhtesh Ramon Hike': 'Makhtesh Ramon Hike',
    'Lunch at Beresheet Hotel': 'Lunch at Beresheet Hotel',
    'Desert Jeep Tour': 'Desert Jeep Tour',
    'Stargazing setup': 'Stargazing setup',
    'Sunrise meditation': 'Sunrise meditation',
    'Avdat National Park': 'Avdat National Park',
    'Lunch & shade rest': 'Lunch & shade rest',
    'Ein Avdat Canyon': 'Ein Avdat Canyon',
    'Dead Sea Morning Swim': 'Dead Sea Morning Swim',
    'Masada via cable car': 'Masada via cable car',
    'Lunch — Masada Rest House': 'Lunch — Masada Rest House',
    'Pack & prep': 'Pack & prep',
    'Timna Valley Park': 'Timna Valley Park',
    'Final lunch — Eilat': 'Final lunch — Eilat',
    'Mitzpe Ramon': 'Mitzpe Ramon',
    'Ramon Crater': 'Ramon Crater',
    'Avdat Valley': 'Avdat Valley',
    'Ancient Nabatean': 'Ancient Nabatean',
    'Dead Sea': 'Dead Sea',
    'Lowest point on Earth': 'Lowest point on Earth',
    'Timna & Eilat': 'Timna & Eilat',
    'Red Sea coast': 'Red Sea coast',
    'Alpaca Farm Mitzpe Ramon': 'Alpaca Farm Mitzpe Ramon',
    'Desert Bistro & Coffee': 'Desert Bistro & Coffee',
    'Camel Crossing Viewpoint': 'Camel Crossing Viewpoint',
    'Bedouin Hospitality Tent': 'Bedouin Hospitality Tent',
    'A charming desert farm — perfect 45-min stop for the whole group.': 'A charming desert farm — perfect 45-min stop for the whole group.',
    'Acclaimed café with Bedouin coffee and a crater-view terrace.': 'Acclaimed café with Bedouin coffee and a crater-view terrace.',
    '15-min walk to a spectacular vantage over the crater floor.': '15-min walk to a spectacular vantage over the crater floor.',
    'Traditional tea and local bread with a Bedouin family — unforgettable.': 'Traditional tea and local bread with a Bedouin family — unforgettable.',
    // V2 — Budget Alerts
    budgetOverTitle: '⚠️ Over budget!',
    budgetOverDesc: 'You\'ve exceeded your budget by {amount}',
    budgetEightyTitle: '💛 80% of budget used',
    budgetEightyDesc: '{remaining} remaining',
    budgetLabel: 'Budget Limit (optional)',
    budgetPlaceholder: 'e.g. 2000',
    setBudget: 'Set Budget',
    budgetSet: 'Budget saved ✓',
    // V2 — Expense Settlement
    settlementTitle: 'Who Owes Who',
    settlementSub: 'Fewest payments to settle all debts',
    settlementAllClear: '🎉 All settled — no debts!',
    settlementOwes: 'owes',
    settlementNoExpenses: 'Add shared expenses to see how to settle up',
    settleUp: 'Settle Up',
    // V2 — Trip DNA Card
    dnaBtnShare: '✨ Share Trip DNA',
    dnaGenerating: 'Generating your Trip DNA card…',
    dnaShareFailed: 'Could not share — try saving the image instead',
    dnaDownloaded: 'Trip DNA card saved!',
    dnaBtnDownload: 'Save Image',
    // V2 — Homepage CTA
    v2HeroTitle: 'Version 2 is here.',
    v2HeroSub: 'Map view, settlements, shareable DNA cards and more.',
    v2TryBtn: '🚀 Try V2 Features',
    v2FeatMap: 'Interactive Trip Map',
    v2FeatSettle: 'Expense Settlement',
    v2FeatDNA: 'Shareable DNA Card',
    v2FeatAlerts: 'Smart Budget Alerts',
    // Packing screen
    adventurePrep: 'Adventure prep',
    almostThere: 'Almost there!',
    allPacked: 'All packed! 🎉',
    packedShared: 'packed · shared with crew',
    // Crew screen
    gatherTheTribe: 'Gather the tribe',
    gatherSubtitle: 'Add friends to sync itineraries and share memories in real time.',
    inviteByEmailLabel: 'Invite by email',
    sendInvitesBtn: 'Send invites',
    orMagicLink: 'or magic link',
    currentCrew: 'Current crew',
    generatingLink: 'Generating link…',
    // Dashboard hardcoded strings
    budgetSheetTitle: 'Budget & Expenses',
    totalSpent: 'Total spent',
    addExpenseLabel: 'Log an expense',
    descriptionLabel: 'Description',
    amountLabel: 'Amount',
    paidByLabel: 'Paid by',
    youLabel: 'You',
    expenseHistoryLabel: 'History',
    tripCalendarLabel: 'Trip calendar',
    inviteLinkCopied: 'Invite link copied!',
    couldNotCreateInvite: 'Could not create invite link',
    expenseRemovedToast: 'Expense removed',
    budgetSavedToast: 'Budget saved ✓',
    validExpenseError: 'Enter a description and valid amount',
    ofDays: 'of',
    deleteExpenseLabel: 'Delete expense',
    aiAnalysisLabel: 'AI Analysis',
    viewSuggestions: 'View Ideas',
    seeAll: 'See all',
    todayLabel: 'Today',
    tapToSetLimit: 'Tap to set a limit',
    noActivitiesYet: 'No activities planned yet.',
    startPlanningCta: 'Start with Day 1 — add flights, restaurants, or anything you have in mind.',
    planDay1: 'Plan Day 1'
};
const he = {
    appName: 'Trippy',
    appTagline: 'תכנן. גלה. חווה.',
    joinTrip: 'הצטרף לטיול',
    createNewTrip: 'צא לדרך חדשה',
    tripName: 'שם הטיול',
    tripCode: 'קוד הטיול',
    yourNickname: 'הכינוי שלך',
    joinBtn: 'יאללה, נסע!',
    tryDemo: '💡 נסה את ההדגמה',
    demoTripName: 'שם הטיול',
    demoTripCode: 'קוד הטיול',
    demoNickname: 'כינוי',
    demoAnything: 'כל שם',
    numDays: 'כמה ימים?',
    chooseCode: 'קוד טיול (לפחות 6 תווים)',
    confirmCode: 'חזור על הקוד',
    createBtn: 'יוצאים לדרך!',
    navCamp: 'ראשי',
    navExplore: 'גלה',
    navPack: 'ציוד',
    navSetup: 'הגדרות',
    activeTrip: 'הטיול שלך',
    days: 'ימים',
    hi: 'היי',
    yourJourney: 'המסלול שלנו',
    day: 'יום',
    suppliesLabel: 'ציוד',
    packed: 'ארוז',
    backToDashboard: 'חזרה',
    addBtn: 'הוסף',
    freeTime: 'זמן פנוי',
    suggestBtn: 'רעיונות AI',
    addEvent: 'הוסף פעילות',
    editEvent: 'ערוך פעילות',
    eventName: 'שם הפעילות',
    startTime: 'שעת התחלה',
    duration: 'משך',
    category: 'קטגוריה',
    locationOpt: 'מיקום (לא חובה)',
    notesOpt: 'הערות (לא חובה)',
    cancel: 'ביטול',
    saveChanges: 'שמור',
    tapToAdd: 'לחץ על שעה כלשהי או + כדי לבנות את היום',
    packList: 'רשימת הציוד',
    addItem: 'הוסף פריט',
    itemNamePlaceholder: 'שם הפריט…',
    setupTitle: 'הגדרות',
    setupSub: 'התאם את Trippy לעצמך',
    tripInfo: 'פרטי הטיול',
    nameLabel: 'שם',
    daysLabel: 'ימים',
    startLabel: 'התחלה',
    eventsLabel: 'פעילויות',
    participantsLabel: 'חברי צוות',
    myProfile: 'הפרופיל שלי',
    languageLabel: 'שפה',
    exportTrip: 'ייצוא',
    exportJSON: 'ייצא JSON',
    exportJSONSub: 'גיבוי או ייבוא חוזר',
    exportMD: 'ייצא Markdown',
    exportMDSub: 'שתף בצ׳אט',
    exportPDF: 'ייצא PDF',
    exportPDFSub: 'מסלול להדפסה',
    aboutLabel: 'אודות',
    leaveTrip: 'עזוב את הטיול',
    saveBtn: 'שמור',
    shareTrip: 'שתף',
    shareSub: 'הזמן את כל החבר׳ה',
    total: 'סה״כ',
    events: 'פעילויות',
    gaps: 'זמן פנוי',
    gapsPlural: 'זמנים פנויים',
    notSet: 'לא הוגדר',
    noItemsCategory: 'אין פריטים בקטגוריה הזו עדיין',
    of: 'מתוך',
    items: 'פריטים',
    english: '🇺🇸 English',
    hebrew: '🇮🇱 עברית',
    aiSuggestions: 'רעיונות AI',
    aiSugSub: 'בהתאם לתוכנית ומיקומך',
    scanningNearby: 'מחפש מקומות קרובים…',
    noSuggestions: 'אין הצעות כרגע — בדוק שוב בקרוב',
    noMoreSuggestions: 'אין עוד הצעות לפרק זמן זה.',
    tryAddingEvents: 'הוסף פעילויות כדי לפתוח זמנים פנויים לרעיונות.',
    dismiss: 'דחה',
    addToDay: 'הוסף ליום',
    close: 'סגור',
    open: 'פתוח',
    closed: 'סגור',
    copyToClipboard: 'העתק',
    tripExportedJSON: 'הטיול יוצא בהצלחה ✓',
    tripExportedMD: 'הטיול יוצא בהצלחה ✓',
    tripExportedPDF: 'הטיול יוצא בהצלחה ✓',
    pdfComingSoon: 'ייצוא PDF — בקרוב',
    pdfNoEvents: 'לא תוכננו פעילויות.',
    pdfStarts: 'מתחיל',
    pdfPopupBlocked: 'אפשר חלונות קופצים כדי לייצא PDF',
    eventAdded: 'הפעילות נוספה ✓',
    eventUpdated: 'הפעילות עודכנה ✓',
    eventRemoved: 'הפעילות הוסרה',
    itemAdded: 'הפריט נוסף ✓',
    itemRemoved: 'הפריט הוסר',
    nicknameUpdated: 'הכינוי עודכן ✓',
    copied: 'הועתק!',
    enterTripNameCode: 'הכנס שם טיול וקוד',
    enterNickname: 'בחר כינוי לעצמך',
    tripNotFound: 'הטיול לא נמצא — בדוק שוב את השם והקוד',
    createTripFailed: 'משהו השתבש — נסה שוב',
    emailConfirmRequired: 'כבה ״אישור אימייל״ ב-Supabase → Authentication → Settings',
    signInWithGoogle: 'כניסה עם Google',
    webViewWarning: 'אתה בדפדפן מוטמע. פתח תפריט (⋮ או …) ובחר ״פתח ב-Chrome״ כדי להתחבר עם Google.',
    countriesLabel: 'יעדי הטיול',
    countriesPlaceholder: 'לדוגמה: ישראל, צרפת, איטליה',
    registerNudgeTitle: 'מאהב את Trippy?',
    registerNudgeSub: 'פתח חשבון חינמי וישמור את כל ההרפתקאות שלך.',
    usernameLabel: 'שם משתמש',
    passwordLabel: 'סיסמה',
    confirmPasswordLabel: 'אישור סיסמה',
    loginBtn: 'כניסה',
    registerBtn: 'יצירת חשבון',
    switchToRegister: 'אין לך חשבון? הירשם',
    switchToLogin: 'כבר יש לך חשבון? התחבר',
    signInPrompt: 'התחבר כדי ליצור או להצטרף לטיול',
    signedInAs: 'מחובר כ',
    signOut: 'התנתק',
    usernamePlaceholder: 'לדוגמה: dana123',
    passwordPlaceholder: 'לפחות 6 תווים',
    passwordsMismatch: 'הסיסמאות לא תואמות',
    usernameTaken: 'שם המשתמש תפוס — נסה אחר',
    loginFailed: 'שם משתמש או סיסמה שגויים',
    registrationFailed: 'ההרשמה נכשלה — נסה שם משתמש אחר',
    enterTripName: 'תן שם לטיול שלך תחילה',
    codeTooShort: 'הקוד חייב להכיל לפחות 6 תווים',
    codesNoMatch: 'הקודים לא תואמים',
    enterEventName: 'תן שם לפעילות',
    enterItemName: 'תן שם לפריט',
    weather34: '34°C · שמשי',
    windUV: 'רוח 12 קמ״ש · UV 9 — נדרשת הגנה גבוהה',
    appVersion: 'v1.0.0',
    appStack: 'Next.js · Zustand · Liquid Glass',
    editingLabel: 'עורך',
    nextEvent: 'הפעילות הבאה',
    comingUp: 'בקרוב',
    tripInsights: 'תובנות הטיול',
    quickAdd: 'הוספה מהירה',
    noUpcomingEvents: 'אין פעילויות — תהנה מהרגע!',
    darkMode: 'מצב כהה',
    lightMode: 'מצב בהיר',
    goldenHourSunset: '🌅 שעת הזהב',
    goldenHourSunrise: '🌄 זריחה',
    conflictWarning: '⚠️ חפיפה',
    costLabel: 'עלות (לא חובה)',
    costPlaceholder: 'לדוגמה 25',
    dayBudget: 'סה״כ היום',
    tripBudget: 'תקציב משוערך',
    votesUp: 'בעד',
    votesDown: 'נגד',
    travelNotes: 'כספת הנסיעה',
    travelNotesSub: 'אישורים, פרטי ויזה וסיסמאות — הכל במקום אחד',
    addNote: 'הוסף הערה',
    notePlaceholder: 'לדוגמה: אישור מלון ABC123…',
    noNotes: 'עדיין לא נשמר כלום. הוסף אישורים, פרטי ויזה, או כל מה שלא תרצה לשכוח.',
    navNotes: 'כספת',
    navMap: 'מפה',
    navCrew: 'צוות',
    crewTitle: 'הצוות שלנו',
    crewMembers: 'חברי הצוות',
    crewOwnerLabel: 'מארגן',
    crewMemberLabel: 'חבר',
    crewInviteTitle: 'הזמן חברים',
    crewInviteByEmail: 'שלח הזמנה באימייל',
    crewCopyLink: 'העתק קישור הזמנה',
    crewPending: 'הזמנות שטרם נענו',
    crewNoMembers: 'הצוות ריק — הזמן מישהו להצטרף!',
    crewKickMember: 'הסר מהטיול',
    mapTitle: 'מפת המסלול',
    mapNoEvents: 'אין נקודות מוצמדות עדיין',
    mapNoEventsHint: 'הוסף מיקום לפעילויות בתכנון היומי כדי לראות אותן כאן',
    mapEventCount: 'סיכה {count}',
    mapEventCountPlural: '{count} סיכות',
    mapAllDays: 'כל הימים',
    mapDay: 'יום {day}',
    appearanceLabel: 'מראה',
    highContrast: 'ניגודיות גבוהה',
    highContrastSub: 'מחשיך רקעים שקופים ומחדד טקסט (WCAG AA)',
    accessibilityLabel: 'נגישות',
    reduceMotion: 'הפחתת תנועה',
    reduceMotionSub: 'מבטל אנימציות ומפחית רגישות לתנועה',
    displayLabel: 'תצוגה',
    hideTravelVault: 'הסתרת כספת הנסיעה',
    hideTravelVaultSub: 'מסיר את קטע כספת הנסיעה מההגדרות',
    hideBudget: 'הסתרת תקציב',
    hideBudgetSub: 'מסיר את כרטיס התקציב מהמסך הראשי',
    carbonBudget: 'טביעת רגל פחמנית',
    carbonBudgetSub: 'מציג שומת CO₂ משוערת מטיסות ותחבורה',
    nightOwlLabel: 'מצב ינשוף לילה',
    nightOwlSub: 'מאריך את גבול היום — שומר פעילויות לילה מאוחרות באותו יום',
    nightOwlStandard: 'רגיל (23:00)',
    nightOwlLate: 'מאוחר (01:00)',
    nightOwlExtreme: 'ינשוף לילה (03:00)',
    dayBoundaryUpdated: 'גבול היום עודכן',
    emergencyHubLabel: 'אנשי קשר לחירום',
    emergencyHubSub: 'זמינים גם ללא אינטרנט — תמיד בהישג יד',
    emergencyNamePlaceholder: 'שם או ארגון',
    emergencyPhonePlaceholder: '+972 50 000 0000',
    emergencySaved: 'איש קשר נשמר ✓',
    contactRemoved: 'איש הקשר הוסר',
    noEmergencyContacts: 'אין אנשי קשר לחירום — מומלץ להוסיף לפחות אחד לפני היציאה',
    medical: 'רפואי',
    embassy: 'שגרירות',
    personal: 'אישי',
    insurance: 'ביטוח',
    enterNamePhone: 'הכנס שם ומספר טלפון',
    aboutApp: 'אפליקציה',
    aboutVersion: 'גרסה',
    aboutStack: 'טכנולוגיות',
    enterDescAmount: 'הכנס תיאור וסכום',
    expenseAdded: 'ההוצאה נוספה ✓',
    expenses: 'הוצאות',
    whatFor: 'על מה זה?',
    paidByDefault: 'שולם ע״י (ברירת מחדל: {name})',
    noExpensesYet: 'עדיין לא נרשמו הוצאות — התחל לעקוב!',
    paid: 'שילם',
    person: 'אדם',
    oneDayConflict: 'ביום {day} יש פעילויות חופפות',
    manyDaysConflict: '{count} ימים עם חפיפות',
    conflictDesc: 'זוהו פעילויות חופפות — לחץ על היום לפרטים',
    oneDayPacked: 'יום {day} עמוס מדי',
    manyDaysPacked: '{count} ימים עמוסים מדי',
    packedDesc: 'אין הפסקת מנוחה — שקול להוסיף קצת אוויר',
    ecoTitle: '~{carbon} ק״ג CO₂ משוערך',
    ecoDesc: '{count} טיסות נרשמו — שקול רכבת לקטעים קצרים',
    relaxTitle: 'יום {day} — זמן לנשום',
    relaxDesc: '~{hours} שעות פנויות — מושלם להירגע',
    gapTitle: 'יום {day} — יש זמן פנוי',
    gapDesc: '~{hours} שעות פתוחות — נסה רעיונות AI',
    foodTitle: 'ארוחות לא תוכננו',
    foodDesc: 'ב-{days} אין עצירות לאוכל מתוכננות',
    packedTitle: '{pct}% ארוז',
    packedDesc2: '{count} פריטים עדיין לא ארוזים',
    oneDayEmpty: 'יום ריק',
    manyDaysEmpty: '{count} ימים ריקים',
    oneDayEmptyDesc: 'יום {day} מחכה לפעילויות',
    manyDaysEmptyDesc: 'כמה ימים עדיין ריקים — בוא נמלא אותם!',
    trackTitle: 'הטיול נראה מעולה!',
    trackDesc: '{events} פעילויות על פני {days} ימים',
    onePerson: 'אחד',
    people: 'אנשים',
    everyone: 'כולם',
    estimatingTravel: 'מחשב זמן נסיעה…',
    estimatedTravelTime: '🚗 זמן נסיעה משוערך',
    moveToTime: 'העבר ל',
    confirmMove: 'אשר',
    onlineBadge: '● מחובר',
    offlineBadge: '○ לא מחובר',
    stopSingular: 'עצירה',
    stopPlural: 'עצירות',
    overlapCount: 'חפיפה',
    tagsLabel: 'תגיות',
    tagsOptional: 'לא חובה, מופרד בפסיקות',
    tagsPlaceholder: '"מזומן בלבד, לבוש צנוע, ידידותי לטבעונים"',
    editDaySubtitle: 'תן שם לעיר ואמוג׳י ליום הזה',
    editDayCityLabel: 'עיר / מיקום',
    editDayCityPlaceholder: 'לדוגמה: פריז, רומא, אמסטרדם',
    emojiLabel: 'אמוג׳י',
    dayUpdated: 'היום עודכן ✓',
    driveToAirportTitle: 'נסיעה לשדה תעופה ✈️',
    driveToAirportSub: 'כמה זמן הנסיעה? נוסיף אותה לפני הטיסה.',
    drivingTimeLabel: 'זמן נסיעה (דקות)',
    customMinutesPlaceholder: 'הכנס דקות…',
    skipBtn: 'דלג',
    addDriveBtn: 'הוסף נסיעה',
    driveAddedToast: 'נסיעה לשדה תעופה נוספה ✓',
    driveToAirportName: 'נסיעה לשדה תעופה',
    carbonFootprintLabel: 'טביעת רגל פחמנית',
    showCode: 'הצג',
    hideCode: 'הסתר',
    tripUpdated: 'הטיול עודכן ✓',
    undoLabel: 'בטל',
    removedSuffix: 'הוסר',
    movedToSuffix: 'הועבר ל',
    eventNamePlaceholder: 'לדוגמה: טיול במצדה',
    locationFullPlaceholder: 'לדוגמה: מצדה, ים המלח',
    notesFullPlaceholder: 'מידע נוסף…',
    quickDriveLabel: 'נסיעה',
    quickMealLabel: 'ארוחה',
    quickCoffeeLabel: 'קפה',
    quickRestLabel: 'מנוחה',
    quickGasLabel: 'דלק',
    quickDriveName: 'נסיעה',
    quickMealName: 'ארוחה',
    quickCoffeeName: 'עצירת קפה',
    quickRestName: 'עצירת מנוחה',
    quickGasName: 'תחנת דלק',
    startDateLabel: 'תאריך התחלה',
    codeOptional: '(לא חובה)',
    leaveBlankCode: 'השאר ריק לטיול אישי',
    repeatCode: 'חזור על הקוד',
    myTrips: 'הטיולים שלי',
    joinPlaceholderName: 'לדוגמה: הנגב — מסע במדבר',
    joinPlaceholderCode: 'קוד משותף',
    joinPlaceholderNick: 'לדוגמה: דנה',
    createPlaceholderName: 'לדוגמה: אירופה 2026',
    createPlaceholderNick: 'לדוגמה: אלכס',
    backgroundLabel: 'ערכת נושא',
    chooseCodeOptional: 'קוד טיול (לא חובה)',
    reduceDaysWarning: 'הפחתת הימים ל-{newDays} תמחק פעילויות בימים {from}–{to}. להמשיך?',
    invitations: 'הזמנות',
    invitedToJoin: 'הוזמנת להצטרף אל',
    acceptBtn: 'אני בפנים!',
    rejectBtn: 'דחה',
    inviteByEmail: 'שלח הזמנה באימייל',
    inviteEmailPlaceholder: 'חבר@example.com',
    sendInvite: 'שלח',
    inviteSent: 'ההזמנה נשלחה ✓',
    inviteFailed: 'שליחת ההזמנה נכשלה — נסה שוב',
    quickLinkLabel: 'כל מי שיש לו את הקישור יכול להצטרף',
    copyLink: '🔗 העתק קישור הזמנה',
    linkCopied: 'הקישור הועתק ✓',
    noLink: 'לא ניתן ליצור קישור — נסה שוב',
    inviteLimitReached: 'הגעת למגבלה — המתן לתגובה לפני שליחת הזמנות נוספות',
    pendingLabel: 'ממתין',
    cancelInvite: 'בטל',
    estCost: 'עלות משוערת',
    assigneePlaceholder: 'אחראי (לדוגמה: אמא, מרק) — לא חובה',
    criticalItemsUnpacked: '⚠️ פריטים קריטיים חסרים',
    criticalBadge: 'קריטי',
    markCritical: 'סמן כקריטי',
    unmarkCritical: 'קריטי — חייב לארוז',
    criticalBlocksBar: 'מונע השלמת פס ההתקדמות',
    currencyLabel: 'מטבע',
    currencyChanged: 'המטבע עודכן ✓',
    localEquiv: 'שווי מקומי',
    weatherLabel: 'מזג אוויר',
    tapForWeather: 'לחץ לתחזית',
    deleteAccount: 'מחק את הנתונים שלי',
    deleteAccountConfirm: 'פעולה זו תמחק לצמיתות את חשבונך ונתוניך האישיים. תוכן הטיול המשותף (פעילויות, הוצאות, הערות) ישאר גלוי למשתתפים האחרים. לא ניתן לבטל. להמשיך?',
    deleteAccountSuccess: 'הנתונים נמחקו בהצלחה.',
    deleteAccountFailed: 'המחיקה נכשלה — נסה שוב או צור קשר.',
    // World Clock
    'worldClock.nowHere': 'עכשיו כאן',
    'worldClock.yourTime': 'הזמן אצלך',
    'worldClock.sameZone': 'אותו אזור זמן',
    'worldClock.ahead': '{h}ש׳ קדימה',
    'worldClock.behind': '{h}ש׳ אחורה',
    'worldClock.localTime': 'שעה מקומית',
    // Route Connector
    'routeConnector.expand': 'הצג אפשרויות נסיעה',
    'routeConnector.recommended': 'מומלץ',
    'routeConnector.departure': 'יציאה ב',
    'routeConnector.overlap': '⚠️ חפיפה!',
    'routeConnector.tight': 'חיבור צמוד',
    'routeConnector.warning': 'שים לב לזמן הנסיעה',
    // Timezone Badge
    'timezoneBadge.change': 'שינוי אזור זמן',
    'timezoneBadge.nowIn': 'עכשיו ב',
    // Map
    'map.noCoords': 'לפעילות זו אין מיקום',
    // Crew
    'crew.linkCopied': 'הקישור הועתק!',
    // Expense settlement
    'settlement.title': 'מי חייב למי',
    'settlement.owes': '{from} חייב/ת ל-{to}',
    'settlement.settled': 'הכל מסולק!',
    // Budget alerts
    'budget.eightyPct': 'נותרו {remaining} מהתקציב',
    'budget.over': 'חרגתם ב-{amount}',
    // Vibe quiz
    'vibe.explorer': 'חוקרים',
    'vibe.relaxed': 'נינוחים',
    'vibe.foodie': 'גורמה',
    'vibe.budget': 'חסכנים חכמים',
    'vibe.balanced': 'מאוזנים',
    // Demo Data
    'Morning camp breakfast': 'ארוחת בוקר במחנה',
    'Makhtesh Ramon Hike': 'טיול במכתש רמון',
    'Lunch at Beresheet Hotel': 'ארוחת צהריים במלון בראשית',
    'Desert Jeep Tour': 'טיול ג׳יפים במדבר',
    'Stargazing setup': 'תצפית כוכבים',
    'Sunrise meditation': 'מדיטציית זריחה',
    'Avdat National Park': 'גן לאומי עבדת',
    'Lunch & shade rest': 'ארוחת צהריים ומנוחה בצל',
    'Ein Avdat Canyon': 'קניון עין עבדת',
    'Dead Sea Morning Swim': 'שחייה בבוקר בים המלח',
    'Masada via cable car': 'מצדה ברכבל',
    'Lunch — Masada Rest House': 'ארוחת צהריים — בית הארחה מצדה',
    'Pack & prep': 'אריזה והתארגנות',
    'Timna Valley Park': 'פארק תמנע',
    'Final lunch — Eilat': 'ארוחת צהריים אחרונה — אילת',
    'Mitzpe Ramon': 'מצפה רמון',
    'Ramon Crater': 'מכתש רמון',
    'Avdat Valley': 'בקעת עבדת',
    'Ancient Nabatean': 'עתיקות נבטיות',
    'Dead Sea': 'ים המלח',
    'Lowest point on Earth': 'המקום הנמוך ביותר בעולם',
    'Timna & Eilat': 'תמנע ואילת',
    'Red Sea coast': 'חוף ים סוף',
    'Alpaca Farm Mitzpe Ramon': 'חוות האלפקות מצפה רמון',
    'Desert Bistro & Coffee': 'ביסטרו וקפה מדברי',
    'Camel Crossing Viewpoint': 'נקודת תצפית מעבר הגמלים',
    'Bedouin Hospitality Tent': 'אוהל אירוח בדואי',
    'A charming desert farm — perfect 45-min stop for the whole group.': 'חווה מדברית קסומה — עצירה מושלמת של 45 דקות לכל הקבוצה.',
    'Acclaimed café with Bedouin coffee and a crater-view terrace.': 'קפה מפורסם עם קפה בדואי ומרפסת צופה למכתש.',
    '15-min walk to a spectacular vantage over the crater floor.': 'הליכה של 15 דקות לנקודת תצפית מרהיבה על קרקעית המכתש.',
    'Traditional tea and local bread with a Bedouin family — unforgettable.': 'תה מסורתי ולחם טרי עם משפחה בדואית — חוויה בלתי נשכחת.',
    // V2 — Budget Alerts
    budgetOverTitle: '⚠️ חרגת מהתקציב!',
    budgetOverDesc: 'חרגת ב-{amount} מהתקציב',
    budgetEightyTitle: '💛 80% מהתקציב נוצל',
    budgetEightyDesc: 'נותרו {remaining}',
    budgetLabel: 'מגבלת תקציב (לא חובה)',
    budgetPlaceholder: 'לדוגמה 2000',
    setBudget: 'הגדר תקציב',
    budgetSet: 'התקציב נשמר ✓',
    // V2 — Expense Settlement
    settlementTitle: 'מי חייב למי',
    settlementSub: 'המינימום לסגירת כל החובות',
    settlementAllClear: '🎉 הכל מסולק — אין חובות!',
    settlementOwes: 'חייב ל',
    settlementNoExpenses: 'הוסף הוצאות משותפות כדי לחשב את האיזון',
    settleUp: 'סלק חשבונות',
    // V2 — Trip DNA Card
    dnaBtnShare: '✨ שתף כרטיס DNA',
    dnaGenerating: 'מייצר כרטיס DNA לטיול…',
    dnaShareFailed: 'לא ניתן לשתף — נסה לשמור את התמונה',
    dnaDownloaded: 'כרטיס DNA נשמר!',
    dnaBtnDownload: 'שמור תמונה',
    // V2 — Homepage CTA
    v2HeroTitle: 'גרסה 2 כבר כאן!',
    v2HeroSub: 'מפת מסלול, סילוק חובות, כרטיסי DNA לשיתוף ועוד.',
    v2TryBtn: '🚀 נסה את V2',
    v2FeatMap: 'מפת טיול אינטראקטיבית',
    v2FeatSettle: 'סילוק הוצאות',
    v2FeatDNA: 'כרטיס DNA לשיתוף',
    v2FeatAlerts: 'התראות תקציב חכמות',
    // Packing screen
    adventurePrep: 'הכנה להרפתקה',
    almostThere: 'כמעט שם!',
    allPacked: 'הכל ארוז! 🎉',
    packedShared: 'ארוזים · משותף עם הצוות',
    // Crew screen
    gatherTheTribe: 'קבץ את הצוות',
    gatherSubtitle: 'הוסף חברים לסנכרון מסלולים ושיתוף זכרונות בזמן אמת.',
    inviteByEmailLabel: 'הזמן באימייל',
    sendInvitesBtn: 'שלח הזמנות',
    orMagicLink: 'או קישור קסם',
    currentCrew: 'הצוות הנוכחי',
    generatingLink: 'מייצר קישור…',
    // Dashboard hardcoded strings
    budgetSheetTitle: 'תקציב והוצאות',
    totalSpent: 'סה״כ הוצאות',
    addExpenseLabel: 'רשום הוצאה',
    descriptionLabel: 'תיאור',
    amountLabel: 'סכום',
    paidByLabel: 'שולם ע״י',
    youLabel: 'אני',
    expenseHistoryLabel: 'היסטוריה',
    tripCalendarLabel: 'לוח השנה',
    inviteLinkCopied: 'הקישור הועתק!',
    couldNotCreateInvite: 'לא ניתן ליצור קישור הזמנה',
    expenseRemovedToast: 'ההוצאה הוסרה',
    budgetSavedToast: 'התקציב נשמר ✓',
    validExpenseError: 'הכנס תיאור וסכום תקינים',
    ofDays: 'מתוך',
    deleteExpenseLabel: 'מחק הוצאה',
    aiAnalysisLabel: 'ניתוח AI',
    viewSuggestions: 'ראה רעיונות',
    seeAll: 'ראה הכל',
    todayLabel: 'היום',
    tapToSetLimit: 'לחץ לקביעת מגבלת תקציב',
    noActivitiesYet: 'עדיין לא תוכננו פעילויות.',
    startPlanningCta: 'התחל ביום 1 — הוסף טיסות, מסעדות, או כל דבר שיש לך בראש.',
    planDay1: 'תכנן יום 1'
};
const translations = {
    en,
    he
};
const I18nContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    locale: 'en',
    setLocale: ()=>{},
    t: (k)=>en[k] ?? k,
    isRTL: false
});
function detectLocale() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const saved = localStorage.getItem('trippy-locale');
    if (saved === 'he' || saved === 'en') return saved;
    const lang = navigator.language?.toLowerCase() ?? '';
    if (lang.startsWith('he') || lang.startsWith('iw')) return 'he';
    return 'en';
}
function I18nProvider({ children }) {
    _s();
    const [locale, setLocaleState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('en');
    // Detect locale once on mount (client-side only)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "I18nProvider.useEffect": ()=>{
            const detected = detectLocale();
            setLocaleState(detected);
            // Sync <html> attrs in case server-rendered lang/dir differ from client locale
            document.documentElement.lang = detected;
            document.documentElement.dir = detected === 'he' ? 'rtl' : 'ltr';
        }
    }["I18nProvider.useEffect"], []);
    const setLocale = (l)=>{
        setLocaleState(l);
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        localStorage.setItem('trippy-locale', l);
        // Persist to cookie so server-side layout.tsx picks it up on next request
        document.cookie = `trippy-locale=${l}; path=/; max-age=31536000; SameSite=Lax`;
        // Keep <html lang> and <html dir> in sync for screen readers & CSS :lang()
        document.documentElement.lang = l;
        document.documentElement.dir = l === 'he' ? 'rtl' : 'ltr';
    };
    const isRTL = locale === 'he';
    const t = (k)=>{
        const dict = translations[locale];
        const fallback = en;
        return dict[k] ?? fallback[k] ?? k;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(I18nContext.Provider, {
        value: {
            locale,
            setLocale,
            t,
            isRTL
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/lib/i18n.tsx",
        lineNumber: 1049,
        columnNumber: 5
    }, this);
}
_s(I18nProvider, "2nl8pBfyPglVLD361xEvNyiTYNU=");
_c = I18nProvider;
const useI18n = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(I18nContext);
};
_s1(useI18n, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "I18nProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ui/Icon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Icon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
// Brand icon paths — 24×24, stroke 1.5, round caps/joins, fill:none via outer svg
const PATHS = {
    home: `<path d="M3.5 11L12 4l8.5 7v8.5a1 1 0 0 1-1 1H15v-6h-6v6H4.5a1 1 0 0 1-1-1z"/>`,
    calendar: `<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/>`,
    checklist: `<path d="M4 6.5l1.6 1.6L8.8 5M13 6.5h7M4 12.5l1.6 1.6L8.8 11M13 12.5h7M4 18.5l1.6 1.6L8.8 17M13 18.5h6"/>`,
    settings: `<circle cx="12" cy="12" r="3"/><path d="M19.4 14.5a1.6 1.6 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.7-.3 1.6 1.6 0 0 0-1 1.5V20a2 2 0 0 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.7.3l-.1.1a2 2 0 0 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.7 1.6 1.6 0 0 0-1.5-1H4a2 2 0 0 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.7l-.1-.1a2 2 0 0 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.7.3h.1a1.6 1.6 0 0 0 1-1.5V4a2 2 0 0 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.7-.3l.1-.1a2 2 0 0 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.7v.1a1.6 1.6 0 0 0 1.5 1H20a2 2 0 0 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>`,
    plus: `<path d="M12 5v14M5 12h14"/>`,
    chevR: `<path d="M9 5l7 7-7 7"/>`,
    chevL: `<path d="M15 5l-7 7 7 7"/>`,
    share: `<path d="M12 15V4M8 8l4-4 4 4M5 13v6a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-6"/>`,
    map: `<path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2zM9 4v14M15 6v14"/>`,
    sparkle: `<path d="M11 3l1.4 5.6L18 10l-5.6 1.4L11 17l-1.4-5.6L4 10l5.6-1.4zM18.5 14l.7 2.3 2.3.7-2.3.7-.7 2.3-.7-2.3-2.3-.7 2.3-.7z"/>`,
    trash: `<path d="M4 7h16M10 11v6M14 11v6M6 7l.9 12.1A2 2 0 0 0 8.9 21h6.2a2 2 0 0 0 2-1.9L18 7M9 7V4.5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 4.5V7"/>`,
    edit: `<path d="M4 20.5h4l11-11-4-4-11 11zM14.5 6l4 4M4 20.5l1-4"/>`,
    x: `<path d="M6 6l12 12M18 6L6 18"/>`,
    check: `<path d="M5 12l5 5L20 7"/>`,
    sun: `<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6L7 7M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/>`,
    wind: `<path d="M3 8h11a3 3 0 1 0-3-3M3 12h16a3 3 0 1 1-3 3M3 16h8a3 3 0 1 0-3-3"/>`,
    lock: `<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>`,
    pin: `<path d="M12 22s7-7.5 7-13a7 7 0 0 0-14 0c0 5.5 7 13 7 13z"/><circle cx="12" cy="9" r="2.5"/>`,
    download: `<path d="M12 4v12M8 12l4 4 4-4M5 20h14"/>`,
    compass: `<circle cx="12" cy="12" r="9"/><path d="M15 9l-1.6 4.4L9 15l1.6-4.4z"/>`,
    tent: `<path d="M3 20L12 4l9 16M12 4v16M9 20l3-4 3 4"/>`,
    water: `<path d="M12 3s7 7 7 12a7 7 0 0 1-14 0c0-5 7-12 7-12z"/>`,
    calExport: `<rect x="3" y="5" width="13" height="15.5" rx="2"/><path d="M3 9.5h13M7 3v4M12 3v4M14 14h7M18 11l3 3-3 3"/>`,
    user: `<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>`,
    users: `<circle cx="9" cy="8" r="3.5"/><path d="M2 21a7 7 0 0 1 14 0"/><circle cx="17" cy="9" r="3"/><path d="M22 21a5 5 0 0 0-8-4"/>`,
    search: `<circle cx="11" cy="11" r="7"/><path d="M16 16l5 5"/>`,
    filter: `<path d="M3 5h18l-7 8v7l-4-2v-5z"/>`,
    ai: `<path d="M13 3L5 13h6l-2 8 10-12h-7z"/>`,
    clock: `<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>`,
    arrow: `<path d="M5 12h14M13 6l6 6-6 6"/>`,
    menu: `<path d="M4 7h16M4 12h16M4 17h16"/>`,
    grid: `<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>`,
    swap: `<path d="M7 16V8M7 8L4 11M7 8l3 3M17 8v8M17 16l3-3M17 16l-3-3"/>`,
    plane: `<path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/>`,
    music: `<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>`,
    film: `<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M7 4v16M17 4v16M2 9h5M2 15h5M17 9h5M17 15h5"/>`,
    gift: `<path d="M20 12v10H4V12M22 7H2v5h20zM12 22V7M12 7a2 2 0 0 1-2-2c0-2 2-5 2-5s2 3 2 5a2 2 0 0 1-2 2z"/>`,
    camera: `<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>`,
    ship: `<path d="M2 21c.6.5 1.2 1 2.5 1C7 22 7 20 9.5 20s2.5 2 5 2 2.5-2 5-2c1.3 0 1.9.5 2.5 1M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4a11.6 11.6 0 0 0 1.62 6M10 3.5a2.5 2.5 0 0 1 5 0"/><path d="M12 3v4"/>`,
    bike: `<circle cx="5.5" cy="17.5" r="3.5"/><circle cx="18.5" cy="17.5" r="3.5"/><path d="M15 6a1 1 0 0 0-1-1h-1M9.5 14l5-8.5M12 17.5h3l3-8.5M6 10l1.5 7.5"/>`,
    hot: `<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/><path d="M12 22V12"/>`,
    star: `<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>`
};
function Icon({ name, size = 20, style = {}, color }) {
    const svg = PATHS[name] ?? '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        style: {
            display: 'inline-flex',
            alignItems: 'center',
            color,
            ...style
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: size,
            height: size,
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                dangerouslySetInnerHTML: {
                    __html: svg
                }
            }, void 0, false, {
                fileName: "[project]/app/components/ui/Icon.tsx",
                lineNumber: 70,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ui/Icon.tsx",
            lineNumber: 69,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/ui/Icon.tsx",
        lineNumber: 68,
        columnNumber: 5
    }, this);
}
_c = Icon;
var _c;
__turbopack_context__.k.register(_c, "Icon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/NavBar_V2.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NavBar_V2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ui/Icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const TABS = [
    {
        id: 'dashboard',
        icon: 'grid',
        labelKey: 'navCamp',
        ariaLabel: 'Overview'
    },
    {
        id: 'day',
        icon: 'compass',
        labelKey: 'navExplore',
        ariaLabel: 'Day planner'
    },
    {
        id: 'supplies',
        icon: 'checklist',
        labelKey: 'navPack',
        ariaLabel: 'Packing list'
    },
    {
        id: 'crew',
        icon: 'users',
        labelKey: 'navCrew',
        ariaLabel: 'Crew'
    }
];
const BLOB_SPRING = {
    type: 'spring',
    stiffness: 380,
    damping: 32
};
const ICON_SPRING = {
    type: 'spring',
    stiffness: 380,
    damping: 28
};
const HANDLE_SPRING = {
    type: 'spring',
    stiffness: 320,
    damping: 26
};
const PANEL_SPRING = {
    type: 'spring',
    stiffness: 400,
    damping: 28
};
function NavBar_V2({ active, onChange, onSettings, onSwitch, onAdd, onLogout, onNotes }) {
    _s();
    const { t, isRTL } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])();
    const [expandOpen, setExpandOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Close the expand panel whenever the active screen changes
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "NavBar_V2.useEffect": ()=>{
            setExpandOpen(false);
        }
    }["NavBar_V2.useEffect"], [
        active
    ]);
    // -1 when on a non-tab screen (settings, notes, etc.) — blob should hide
    const activeTabIdx = TABS.findIndex((tb)=>tb.id === active);
    const blobX = (isRTL ? -1 : 1) * Math.max(0, activeTabIdx) * 58;
    const handleChange = (id)=>{
        onChange(id);
        setExpandOpen(false);
    };
    // rename for clarity in JSX
    const activeIdx = activeTabIdx;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            position: 'fixed',
            left: 0,
            right: 0,
            bottom: 0,
            paddingBottom: 'env(safe-area-inset-bottom, 14px)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 10,
            zIndex: 40,
            pointerEvents: 'none'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: expandOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                    className: "lg lg-strong",
                    initial: {
                        opacity: 0,
                        y: 10,
                        scale: 0.9
                    },
                    animate: {
                        opacity: 1,
                        y: 0,
                        scale: 1
                    },
                    exit: {
                        opacity: 0,
                        y: 10,
                        scale: 0.9
                    },
                    transition: PANEL_SPRING,
                    style: {
                        display: 'flex',
                        gap: 8,
                        padding: 8,
                        borderRadius: 9999,
                        pointerEvents: 'auto'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                setExpandOpen(false);
                                onSwitch?.();
                            },
                            className: "lg-btn",
                            style: {
                                height: 42,
                                padding: '0 16px',
                                gap: 7,
                                background: 'transparent',
                                color: 'var(--lg-ink)',
                                fontSize: 13,
                                fontWeight: 600,
                                display: 'flex',
                                alignItems: 'center'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    name: "swap",
                                    size: 17,
                                    style: {
                                        color: 'var(--lg-terra)'
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 94,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: t('switchTrip') || 'Switch trip'
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 95,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/NavBar_V2.tsx",
                            lineNumber: 89,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                width: 1,
                                background: 'oklch(50% 0.02 60 / 22%)',
                                margin: '6px 0'
                            }
                        }, void 0, false, {
                            fileName: "[project]/app/components/NavBar_V2.tsx",
                            lineNumber: 98,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                setExpandOpen(false);
                                onNotes?.();
                            },
                            className: "lg-btn",
                            style: {
                                height: 42,
                                padding: '0 16px',
                                gap: 7,
                                background: 'transparent',
                                color: 'var(--lg-ink)',
                                fontSize: 13,
                                fontWeight: 600,
                                display: 'flex',
                                alignItems: 'center'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    name: "edit",
                                    size: 17,
                                    style: {
                                        color: 'var(--lg-forest)'
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 105,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Notes"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 106,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/NavBar_V2.tsx",
                            lineNumber: 100,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                width: 1,
                                background: 'oklch(50% 0.02 60 / 22%)',
                                margin: '6px 0'
                            }
                        }, void 0, false, {
                            fileName: "[project]/app/components/NavBar_V2.tsx",
                            lineNumber: 109,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                setExpandOpen(false);
                                onSettings?.();
                            },
                            className: "lg-btn",
                            style: {
                                height: 42,
                                padding: '0 16px',
                                gap: 7,
                                background: 'transparent',
                                color: 'var(--lg-ink)',
                                fontSize: 13,
                                fontWeight: 600,
                                display: 'flex',
                                alignItems: 'center'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    name: "settings",
                                    size: 17,
                                    style: {
                                        color: 'var(--lg-forest)'
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 126,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: t('settings') || 'Settings'
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 127,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/NavBar_V2.tsx",
                            lineNumber: 111,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                width: 1,
                                background: 'oklch(50% 0.02 60 / 22%)',
                                margin: '6px 0'
                            }
                        }, void 0, false, {
                            fileName: "[project]/app/components/NavBar_V2.tsx",
                            lineNumber: 130,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                setExpandOpen(false);
                                onLogout?.();
                            },
                            className: "lg-btn",
                            style: {
                                height: 42,
                                padding: '0 16px',
                                gap: 7,
                                background: 'transparent',
                                color: 'oklch(52% 0.14 25)',
                                fontSize: 13,
                                fontWeight: 600,
                                display: 'flex',
                                alignItems: 'center'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    name: "x",
                                    size: 17,
                                    style: {
                                        color: 'oklch(52% 0.14 25)'
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 147,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Log out"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 148,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/NavBar_V2.tsx",
                            lineNumber: 132,
                            columnNumber: 13
                        }, this)
                    ]
                }, "expand-panel", true, {
                    fileName: "[project]/app/components/NavBar_V2.tsx",
                    lineNumber: 74,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/NavBar_V2.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'flex',
                    gap: 10,
                    alignItems: 'center',
                    pointerEvents: 'auto'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].nav, {
                        role: "navigation",
                        "aria-label": "Main navigation",
                        initial: {
                            y: 20,
                            opacity: 0
                        },
                        animate: {
                            y: 0,
                            opacity: 1
                        },
                        transition: {
                            duration: 0.4,
                            ease: [
                                0.25,
                                0,
                                0,
                                1
                            ],
                            delay: 0.08
                        },
                        className: "lg lg-strong",
                        style: {
                            position: 'relative',
                            display: 'flex',
                            alignItems: 'center',
                            padding: 7,
                            borderRadius: 9999,
                            height: 68
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                "aria-hidden": "true",
                                animate: {
                                    x: blobX,
                                    opacity: activeIdx >= 0 ? 1 : 0
                                },
                                transition: BLOB_SPRING,
                                style: {
                                    position: 'absolute',
                                    top: 7,
                                    [isRTL ? 'right' : 'left']: 7 + 44,
                                    width: 58,
                                    height: 54,
                                    borderRadius: 9999,
                                    background: 'linear-gradient(180deg, var(--lg-terra-bright), var(--lg-terra))',
                                    boxShadow: 'var(--lg-glow-terra)',
                                    zIndex: 0,
                                    pointerEvents: 'none'
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/components/NavBar_V2.tsx",
                                lineNumber: 175,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].button, {
                                onClick: ()=>setExpandOpen((o)=>!o),
                                whileTap: {
                                    scale: 0.92
                                },
                                transition: HANDLE_SPRING,
                                "aria-label": "Menu",
                                "aria-expanded": expandOpen,
                                style: {
                                    width: 44,
                                    height: 50,
                                    border: 0,
                                    background: 'transparent',
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    zIndex: 1,
                                    flexShrink: 0,
                                    WebkitTapHighlightColor: 'transparent'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].span, {
                                    animate: {
                                        rotate: expandOpen ? 180 : 0
                                    },
                                    transition: HANDLE_SPRING,
                                    style: {
                                        display: 'flex'
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "menu",
                                        size: 18,
                                        style: {
                                            color: 'var(--text-3)'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/NavBar_V2.tsx",
                                        lineNumber: 219,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 214,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/NavBar_V2.tsx",
                                lineNumber: 194,
                                columnNumber: 11
                            }, this),
                            TABS.map((tab, i)=>{
                                const isActive = i === activeIdx;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].button, {
                                    onClick: ()=>handleChange(tab.id),
                                    whileTap: {
                                        scale: 0.92
                                    },
                                    transition: ICON_SPRING,
                                    "aria-label": tab.ariaLabel,
                                    "aria-current": isActive ? 'page' : undefined,
                                    style: {
                                        position: 'relative',
                                        zIndex: 1,
                                        width: 58,
                                        height: 54,
                                        border: 0,
                                        background: 'transparent',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        gap: 3,
                                        color: isActive ? '#fff' : 'var(--text-3)',
                                        transition: 'color 0.3s',
                                        flexShrink: 0,
                                        WebkitTapHighlightColor: 'transparent',
                                        touchAction: 'manipulation'
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].span, {
                                            animate: {
                                                scale: isActive ? 1.05 : 1,
                                                y: isActive ? -1 : 0
                                            },
                                            transition: ICON_SPRING,
                                            style: {
                                                display: 'flex'
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                name: tab.icon,
                                                size: 19,
                                                color: isActive ? '#fff' : 'var(--text-3)'
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/NavBar_V2.tsx",
                                                lineNumber: 259,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/NavBar_V2.tsx",
                                            lineNumber: 254,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                fontFamily: 'var(--font-sans)',
                                                fontSize: 9,
                                                fontWeight: 600,
                                                letterSpacing: '0.04em',
                                                lineHeight: 1,
                                                color: isActive ? 'rgba(255,255,255,0.9)' : 'var(--text-3)',
                                                transition: 'color 0.3s',
                                                whiteSpace: 'nowrap'
                                            },
                                            children: t(tab.labelKey)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/NavBar_V2.tsx",
                                            lineNumber: 261,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, tab.id, true, {
                                    fileName: "[project]/app/components/NavBar_V2.tsx",
                                    lineNumber: 227,
                                    columnNumber: 15
                                }, this);
                            })
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/NavBar_V2.tsx",
                        lineNumber: 158,
                        columnNumber: 9
                    }, this),
                    onAdd && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].button, {
                        onClick: onAdd,
                        initial: {
                            y: 20,
                            opacity: 0
                        },
                        animate: {
                            y: 0,
                            opacity: 1
                        },
                        transition: {
                            duration: 0.4,
                            ease: [
                                0.25,
                                0,
                                0,
                                1
                            ],
                            delay: 0.12
                        },
                        whileTap: {
                            scale: 0.92
                        },
                        className: "lg-btn lg-btn-forest a-float",
                        "aria-label": "Add",
                        style: {
                            width: 64,
                            height: 64,
                            borderRadius: 9999,
                            flexShrink: 0,
                            WebkitTapHighlightColor: 'transparent',
                            touchAction: 'manipulation'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            name: "plus",
                            size: 26,
                            color: "#fff"
                        }, void 0, false, {
                            fileName: "[project]/app/components/NavBar_V2.tsx",
                            lineNumber: 297,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/NavBar_V2.tsx",
                        lineNumber: 280,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/NavBar_V2.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    height: 0,
                    pointerEvents: 'none'
                }
            }, void 0, false, {
                fileName: "[project]/app/components/NavBar_V2.tsx",
                lineNumber: 303,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/NavBar_V2.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, this);
}
_s(NavBar_V2, "iBdpNh/CKl4M+mgcnJI4CmSkEzI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c = NavBar_V2;
var _c;
__turbopack_context__.k.register(_c, "NavBar_V2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/deriveTheme.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BRAND_THEME",
    ()=>BRAND_THEME,
    "deriveTheme",
    ()=>deriveTheme
]);
const BRAND_THEME = {
    c1: '#3B6E52',
    c2: '#C4714A',
    c3: '#C8944A',
    ink: '#1A1410',
    wash: [
        '#3B6E52',
        '#C4714A',
        '#C8944A'
    ]
};
function hexToRgb(h) {
    h = h.replace('#', '');
    if (h.length === 3) h = h.split('').map((c)=>c + c).join('');
    return {
        r: parseInt(h.slice(0, 2), 16),
        g: parseInt(h.slice(2, 4), 16),
        b: parseInt(h.slice(4, 6), 16)
    };
}
function rgbToHsl({ r, g, b }) {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0;
    const l = (max + min) / 2;
    if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch(max){
            case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
            case g:
                h = (b - r) / d + 2;
                break;
            default:
                h = (r - g) / d + 4;
        }
        h /= 6;
    }
    return {
        h: h * 360,
        s,
        l
    };
}
function hslToHex(h, s, l) {
    h /= 360;
    const f = (n)=>{
        const k = (n + h * 12) % 12;
        const a = s * Math.min(l, 1 - l);
        const c = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
        return Math.round(c * 255).toString(16).padStart(2, '0');
    };
    return '#' + f(0) + f(8) + f(4);
}
function colorMeta(hex) {
    const hsl = rgbToHsl(hexToRgb(hex));
    const vivid = hsl.s * (1 - Math.abs(hsl.l - 0.52) * 1.1);
    const isPaper = hsl.l > 0.86 && hsl.s < 0.25;
    const isInk = hsl.l < 0.16;
    return {
        hex,
        ...hsl,
        vivid,
        isPaper,
        isInk
    };
}
function workable(m) {
    if (m.isPaper) return hslToHex(m.h || 42, Math.max(m.s, 0.12), 0.78);
    if (m.isInk) return hslToHex(m.h || 42, Math.max(m.s, 0.10), 0.30);
    return m.hex;
}
function deriveTheme(colors) {
    if (!colors.length) return BRAND_THEME;
    const ms = colors.map(colorMeta);
    const chroma = ms.filter((m)=>!m.isPaper && !m.isInk).sort((a, b)=>b.vivid - a.vivid);
    const pool = chroma.length ? chroma : ms.slice().sort((a, b)=>b.vivid - a.vivid);
    const pick = (i)=>workable(pool[i % pool.length]);
    const c1 = pick(0);
    const c2 = pool.length > 1 ? pick(1) : hslToHex(pool[0].h, pool[0].s * 0.8, Math.min(0.72, pool[0].l + 0.18));
    const c3 = pool.length > 2 ? pick(2) : pool.length > 1 ? hslToHex(pool[1].h, pool[1].s * 0.7, Math.min(0.78, pool[1].l + 0.2)) : hslToHex(pool[0].h, pool[0].s * 0.55, Math.min(0.82, pool[0].l + 0.32));
    const inkM = ms.slice().sort((a, b)=>a.l - b.l)[0];
    const ink = inkM.l < 0.4 ? inkM.hex : '#1A1410';
    const wash = ms.map((m)=>m.isPaper ? '#FBF7F0' : m.hex);
    return {
        c1,
        c2,
        c3,
        ink,
        wash
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ui/TripLoaders.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CompassLoader",
    ()=>CompassLoader,
    "LoaderStyles",
    ()=>LoaderStyles,
    "PackLoader",
    ()=>PackLoader,
    "RouteLoader",
    ()=>RouteLoader,
    "SparkleLoader",
    ()=>SparkleLoader,
    "SyncLoader",
    ()=>SyncLoader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/deriveTheme.ts [app-client] (ecmascript)");
'use client';
;
;
;
function LoaderStyles() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
        children: `
      @keyframes tlSpinCW   { from { transform: rotate(0);       } to { transform: rotate(360deg);  } }
      @keyframes tlSpinCCW  { from { transform: rotate(360deg);  } to { transform: rotate(0);       } }
      @keyframes tlHalo     { 0%,100% { transform: scale(.84); opacity:.55; } 50% { transform: scale(1.06); opacity:1; } }
      @keyframes tlDraw     { 0% { stroke-dashoffset: var(--tl-len); } 55% { stroke-dashoffset: 0; } 100% { stroke-dashoffset: 0; } }
      @keyframes tlTravel   { 0% { offset-distance:0%;  opacity:0; } 8%  { opacity:1; } 92% { opacity:1; } 100% { offset-distance:100%; opacity:0; } }
      @keyframes tlPinPop   { 0%,18% { transform: translateY(6px) scale(.4); opacity:0; } 34% { transform: translateY(-3px) scale(1.12); opacity:1; } 46%,100% { transform: translateY(0) scale(1); opacity:1; } }
      @keyframes tlDrop     { 0% { transform: translateY(-58px) scale(.7); opacity:0; }
                              14% { opacity:1; }
                              46% { transform: translateY(0) scale(1); }
                              56% { transform: translateY(-4px) scaleY(1.08) scaleX(.94); }
                              66% { transform: translateY(0) scaleY(.94) scaleX(1.06); }
                              76% { transform: translateY(0) scale(1); }
                             100% { transform: translateY(0) scale(1); opacity:1; } }
      @keyframes tlSync     { 0%,70%,100% { transform: scale(.66); opacity:.35; }
                              18% { transform: scale(1.18); opacity:1; }
                              40% { transform: scale(1); opacity:.9; } }
      @keyframes tlSyncRing { 0% { transform: scale(.6); opacity:.7; } 60%,100% { transform: scale(1.7); opacity:0; } }
      @keyframes tlArc      { 0% { stroke-dashoffset: var(--tl-len); } 70%,100% { stroke-dashoffset: 0; } }
      @keyframes tlTwinkle  { 0%,100% { transform: scale(.5) rotate(-8deg); opacity:.25; } 50% { transform: scale(1) rotate(0); opacity:1; } }
      @keyframes tlShimmer  { 0% { transform: translateX(-130%); } 100% { transform: translateX(230%); } }
      @keyframes tlFloat    { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
    `
    }, void 0, false, {
        fileName: "[project]/app/components/ui/TripLoaders.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = LoaderStyles;
function CompassLoader({ theme = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_THEME"], speed = 1, size = 124 }) {
    const t = theme;
    const d = (s)=>`${s / speed}s`;
    const orbit = (r, dash, color, dur, dir, w, op)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 200 200",
            style: {
                position: 'absolute',
                inset: 0,
                overflow: 'visible',
                animation: `${dir} ${d(dur)} linear infinite`,
                transformOrigin: '50% 50%'
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "100",
                cy: "100",
                r: r,
                fill: "none",
                stroke: color,
                strokeWidth: w,
                strokeDasharray: dash,
                strokeLinecap: "round",
                opacity: op
            }, void 0, false, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ui/TripLoaders.tsx",
            lineNumber: 53,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            width: size,
            height: size,
            position: 'relative'
        },
        role: "status",
        "aria-label": "Loading",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    inset: 0,
                    borderRadius: '50%',
                    background: `radial-gradient(circle at 50% 50%, ${t.c2}38 0%, ${t.c2}18 30%, transparent 60%)`,
                    animation: `tlHalo ${d(2.8)} ease-in-out infinite`
                }
            }, void 0, false, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            orbit(96, '170 433', t.c1, 9, 'tlSpinCCW', 1, 0.35),
            orbit(92, '120 84 18 357', t.c2, 5.4, 'tlSpinCW', 1.5, 0.8),
            orbit(84, '58 38 22 410', t.c3, 3.6, 'tlSpinCCW', 1.5, 0.9),
            orbit(76, '44 60 18 356', t.c1, 2, 'tlSpinCW', 2.4, 0.92),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                viewBox: "0 0 200 200",
                style: {
                    position: 'absolute',
                    inset: 0,
                    overflow: 'visible',
                    animation: `tlSpinCW ${d(2)} linear infinite`,
                    transformOrigin: '50% 50%'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "176",
                    cy: "100",
                    r: "3.6",
                    fill: t.c1
                }, void 0, false, {
                    fileName: "[project]/app/components/ui/TripLoaders.tsx",
                    lineNumber: 77,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                viewBox: "0 0 240 240",
                style: {
                    position: 'absolute',
                    inset: 0,
                    overflow: 'visible',
                    animation: `tlSpinCW ${d(6)} linear infinite`,
                    transformOrigin: '50% 50%'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: "120",
                        cy: "120",
                        r: "62",
                        fill: "none",
                        stroke: t.ink,
                        strokeWidth: "3.5",
                        opacity: "0.92"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 84,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M120 64 L134 120 L120 123 L106 120 Z",
                        fill: t.c2
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M120 176 L106 120 L120 117 L134 120 Z",
                        fill: t.c1
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M176 120 L120 106 L117 120 L120 134 Z",
                        fill: t.c3
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 87,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M64 120 L120 134 L123 120 L120 106 Z",
                        fill: t.c3
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        cx: "120",
                        cy: "120",
                        r: "5.5",
                        fill: t.ink
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 89,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/ui/TripLoaders.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, this);
}
_c1 = CompassLoader;
// ─── 2 · Route — drawing a path between two pins ─────────────────────────────
const ROUTE_PATH = 'M26 86 C 60 30, 96 124, 130 70 S 178 26, 190 34';
function RouteLoader({ theme = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_THEME"], speed = 1, size = 124 }) {
    const t = theme;
    const d = (s)=>`${s / speed}s`;
    const Pin = ({ x, y, color, delay })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
            style: {
                transformOrigin: `${x}px ${y}px`,
                animation: `tlPinPop ${d(3.4)} ${d(delay)} ease-in-out infinite`
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: `M${x} ${y} C ${x - 8} ${y - 12} ${x - 8} ${y - 23} ${x} ${y - 29} C ${x + 8} ${y - 23} ${x + 8} ${y - 12} ${x} ${y} Z`,
                    fill: color
                }, void 0, false, {
                    fileName: "[project]/app/components/ui/TripLoaders.tsx",
                    lineNumber: 103,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: x,
                    cy: y - 19,
                    r: "4.5",
                    fill: "#FBF7F0"
                }, void 0, false, {
                    fileName: "[project]/app/components/ui/TripLoaders.tsx",
                    lineNumber: 104,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ui/TripLoaders.tsx",
            lineNumber: 102,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            width: size,
            height: size * 0.72,
            position: 'relative'
        },
        role: "status",
        "aria-label": "Loading",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                viewBox: "0 0 216 116",
                style: {
                    width: '100%',
                    height: '100%',
                    overflow: 'visible'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: ROUTE_PATH,
                        fill: "none",
                        stroke: t.ink,
                        strokeWidth: "2",
                        strokeDasharray: "2 7",
                        strokeLinecap: "round",
                        opacity: "0.18"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: ROUTE_PATH,
                        fill: "none",
                        stroke: t.c1,
                        strokeWidth: "3",
                        strokeLinecap: "round",
                        style: {
                            '--tl-len': 320,
                            strokeDasharray: 320,
                            animation: `tlDraw ${d(3.4)} cubic-bezier(.45,0,.2,1) infinite`
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 112,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Pin, {
                        x: 26,
                        y: 86,
                        color: t.c1,
                        delay: 0
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 114,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Pin, {
                        x: 190,
                        y: 34,
                        color: t.c2,
                        delay: 1.7
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 109,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    inset: 0
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        position: 'absolute',
                        left: 0,
                        top: 0,
                        width: 11,
                        height: 11,
                        marginLeft: -5.5,
                        marginTop: -5.5,
                        borderRadius: '50%',
                        background: t.c2,
                        boxShadow: `0 0 0 4px ${t.c2}33`,
                        offsetPath: `path('${ROUTE_PATH}')`,
                        animation: `tlTravel ${d(3.4)} cubic-bezier(.5,0,.3,1) infinite`
                    }
                }, void 0, false, {
                    fileName: "[project]/app/components/ui/TripLoaders.tsx",
                    lineNumber: 118,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/ui/TripLoaders.tsx",
        lineNumber: 108,
        columnNumber: 5
    }, this);
}
_c2 = RouteLoader;
function PackLoader({ theme = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_THEME"], speed = 1, size = 124 }) {
    const t = theme;
    const d = (s)=>`${s / speed}s`;
    const cs = [
        t.c1,
        t.c2,
        t.c3
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            width: size,
            height: size,
            position: 'relative',
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'center',
            paddingBottom: 6
        },
        role: "status",
        "aria-label": "Loading",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    top: 4,
                    left: 0,
                    right: 0,
                    display: 'flex',
                    justifyContent: 'center',
                    gap: 12
                },
                children: cs.map((c, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            width: 20,
                            height: 20,
                            borderRadius: '50%',
                            background: c,
                            border: `1.5px solid ${t.ink}22`,
                            boxShadow: 'inset 0 1px 0 #ffffff66',
                            display: 'block',
                            animation: `tlDrop ${d(2.4)} ${d(i * 0.42)} cubic-bezier(.4,0,.2,1) infinite`
                        }
                    }, i, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 145,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 140,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                viewBox: "0 0 120 64",
                style: {
                    width: size * 0.82,
                    height: size * 0.45,
                    position: 'relative'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M14 14 H106 a6 6 0 0 1 6 6 l-6 34 a8 8 0 0 1 -8 7 H22 a8 8 0 0 1 -8 -7 L8 20 a6 6 0 0 1 6 -6 Z",
                        fill: "#FBF7F0",
                        stroke: t.ink,
                        strokeWidth: "2.4",
                        strokeLinejoin: "round",
                        opacity: "0.96"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 154,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M40 14 c0 -10 8 -16 20 -16 c12 0 20 6 20 16",
                        fill: "none",
                        stroke: t.ink,
                        strokeWidth: "2.4",
                        strokeLinecap: "round"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 156,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M9 24 H111",
                        stroke: t.ink,
                        strokeWidth: "2",
                        opacity: "0.25"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 158,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 153,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/ui/TripLoaders.tsx",
        lineNumber: 136,
        columnNumber: 5
    }, this);
}
_c3 = PackLoader;
function SyncLoader({ theme = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_THEME"], speed = 1, size = 124 }) {
    const t = theme;
    const d = (s)=>`${s / speed}s`;
    const cs = [
        t.c1,
        t.c2,
        t.c3,
        t.c1
    ];
    const n = 4, gap = 30, startX = 24, y = 40;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            width: size,
            height: size * 0.66,
            position: 'relative'
        },
        role: "status",
        "aria-label": "Loading",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 132 76",
            style: {
                width: '100%',
                height: '100%',
                overflow: 'visible'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: `M${startX} ${y} H${startX + gap * (n - 1)}`,
                    stroke: t.ink,
                    strokeWidth: "2",
                    strokeLinecap: "round",
                    opacity: "0.16"
                }, void 0, false, {
                    fileName: "[project]/app/components/ui/TripLoaders.tsx",
                    lineNumber: 173,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: `M${startX} ${y} H${startX + gap * (n - 1)}`,
                    stroke: t.c1,
                    strokeWidth: "2.4",
                    strokeLinecap: "round",
                    style: {
                        '--tl-len': gap * (n - 1),
                        strokeDasharray: gap * (n - 1),
                        animation: `tlArc ${d(2.6)} ease-in-out infinite`
                    }
                }, void 0, false, {
                    fileName: "[project]/app/components/ui/TripLoaders.tsx",
                    lineNumber: 175,
                    columnNumber: 9
                }, this),
                cs.map((c, i)=>{
                    const x = startX + gap * i;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                cx: x,
                                cy: y,
                                r: "9",
                                fill: c,
                                opacity: "0.25",
                                style: {
                                    transformOrigin: `${x}px ${y}px`,
                                    animation: `tlSyncRing ${d(2.6)} ${d(i * 0.42)} ease-out infinite`
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                                lineNumber: 181,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                                style: {
                                    transformOrigin: `${x}px ${y}px`,
                                    animation: `tlSync ${d(2.6)} ${d(i * 0.42)} ease-in-out infinite`
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                        cx: x,
                                        cy: y,
                                        r: "9.5",
                                        fill: c,
                                        stroke: "#FBF7F0",
                                        strokeWidth: "2"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                                        lineNumber: 184,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                        cx: x,
                                        cy: y - 3,
                                        r: "3",
                                        fill: "#FBF7F0"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                                        lineNumber: 185,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: `M${x - 4.5} ${y + 6} a4.5 4 0 0 1 9 0`,
                                        fill: "#FBF7F0"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                                        lineNumber: 186,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                                lineNumber: 183,
                                columnNumber: 15
                            }, this)
                        ]
                    }, i, true, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 180,
                        columnNumber: 13
                    }, this);
                })
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ui/TripLoaders.tsx",
            lineNumber: 172,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/ui/TripLoaders.tsx",
        lineNumber: 171,
        columnNumber: 5
    }, this);
}
_c4 = SyncLoader;
// ─── 5 · Sparkle — Trippy is thinking (AI suggestions) ───────────────────────
const SPARK_PATH = 'M11 3l1.4 5.6L18 10l-5.6 1.4L11 17l-1.4-5.6L4 10l5.6-1.4z';
function SparkleLoader({ theme = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_THEME"], speed = 1, size = 124 }) {
    const t = theme;
    const d = (s)=>`${s / speed}s`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            width: size,
            height: size,
            position: 'relative',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 12
        },
        role: "status",
        "aria-label": "Loading",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'relative',
                    width: 70,
                    height: 56,
                    animation: `tlFloat ${d(3)} ease-in-out infinite`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        viewBox: "0 0 22 20",
                        width: "46",
                        height: "42",
                        style: {
                            position: 'absolute',
                            left: 12,
                            top: 6,
                            animation: `tlTwinkle ${d(1.8)} ease-in-out infinite`,
                            transformOrigin: '11px 10px'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: SPARK_PATH,
                            fill: t.c1
                        }, void 0, false, {
                            fileName: "[project]/app/components/ui/TripLoaders.tsx",
                            lineNumber: 212,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 208,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        viewBox: "0 0 22 20",
                        width: "22",
                        height: "20",
                        style: {
                            position: 'absolute',
                            left: 0,
                            top: 0,
                            animation: `tlTwinkle ${d(1.8)} ${d(0.5)} ease-in-out infinite`,
                            transformOrigin: '11px 10px'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: SPARK_PATH,
                            fill: t.c2
                        }, void 0, false, {
                            fileName: "[project]/app/components/ui/TripLoaders.tsx",
                            lineNumber: 218,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 214,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        viewBox: "0 0 22 20",
                        width: "16",
                        height: "15",
                        style: {
                            position: 'absolute',
                            right: 0,
                            top: 18,
                            animation: `tlTwinkle ${d(1.8)} ${d(0.9)} ease-in-out infinite`,
                            transformOrigin: '11px 10px'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: SPARK_PATH,
                            fill: t.c3
                        }, void 0, false, {
                            fileName: "[project]/app/components/ui/TripLoaders.tsx",
                            lineNumber: 224,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/TripLoaders.tsx",
                        lineNumber: 220,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 207,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    width: size * 0.6,
                    height: 8,
                    borderRadius: 99,
                    background: `${t.ink}14`,
                    position: 'relative',
                    overflow: 'hidden'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        position: 'absolute',
                        top: 0,
                        bottom: 0,
                        width: '45%',
                        borderRadius: 99,
                        background: `linear-gradient(90deg, transparent, ${t.c1}, transparent)`,
                        animation: `tlShimmer ${d(1.6)} ease-in-out infinite`
                    }
                }, void 0, false, {
                    fileName: "[project]/app/components/ui/TripLoaders.tsx",
                    lineNumber: 231,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ui/TripLoaders.tsx",
                lineNumber: 227,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/ui/TripLoaders.tsx",
        lineNumber: 203,
        columnNumber: 5
    }, this);
}
_c5 = SparkleLoader;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "LoaderStyles");
__turbopack_context__.k.register(_c1, "CompassLoader");
__turbopack_context__.k.register(_c2, "RouteLoader");
__turbopack_context__.k.register(_c3, "PackLoader");
__turbopack_context__.k.register(_c4, "SyncLoader");
__turbopack_context__.k.register(_c5, "SparkleLoader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ui/Toast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ToastProvider",
    ()=>ToastProvider,
    "useToast",
    ()=>useToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
const Ctx = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    show: ()=>{}
});
function ToastProvider({ children }) {
    _s();
    const [msg, setMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [action, setAction] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const timerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const show = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ToastProvider.useCallback[show]": (m, opts)=>{
            if (timerRef.current) clearTimeout(timerRef.current);
            setMsg(m);
            setAction(opts?.action ?? null);
            timerRef.current = setTimeout({
                "ToastProvider.useCallback[show]": ()=>{
                    setMsg(null);
                    setAction(null);
                }
            }["ToastProvider.useCallback[show]"], 3200);
        }
    }["ToastProvider.useCallback[show]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Ctx.Provider, {
        value: {
            show
        },
        children: [
            children,
            msg && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "an-fade",
                style: {
                    position: 'fixed',
                    bottom: 100,
                    left: '50%',
                    transform: 'translateX(-50%)',
                    zIndex: 9999,
                    background: 'rgba(255,255,255,0.92)',
                    backdropFilter: 'blur(28px) saturate(1.8)',
                    WebkitBackdropFilter: 'blur(28px) saturate(1.8)',
                    border: '1px solid rgba(255,255,255,0.85)',
                    borderRadius: 14,
                    padding: '10px 16px',
                    fontSize: 13,
                    fontWeight: 600,
                    whiteSpace: 'nowrap',
                    boxShadow: '0 4px 24px rgba(80,60,20,0.10)',
                    color: 'rgba(28,18,8,0.88)',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: msg
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/Toast.tsx",
                        lineNumber: 43,
                        columnNumber: 11
                    }, this),
                    action && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            action.onClick();
                            if (timerRef.current) clearTimeout(timerRef.current);
                            setMsg(null);
                            setAction(null);
                        },
                        style: {
                            background: 'var(--brand)',
                            color: 'white',
                            border: 'none',
                            borderRadius: 8,
                            padding: '4px 12px',
                            fontSize: 12,
                            fontWeight: 700,
                            cursor: 'pointer',
                            flexShrink: 0
                        },
                        children: action.label
                    }, void 0, false, {
                        fileName: "[project]/app/components/ui/Toast.tsx",
                        lineNumber: 45,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ui/Toast.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/ui/Toast.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_s(ToastProvider, "epDzumopuyIMy2KpPKaSHPr7uVY=");
_c = ToastProvider;
const useToast = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Ctx);
};
_s1(useToast, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "ToastProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/AppShell.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AppShell
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/m/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$MotionConfig$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/MotionConfig/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react/shallow.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/motion.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/i18n.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$NavBar_V2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/NavBar_V2.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$TripLoaders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/app/components/ui/TripLoaders.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/deriveTheme.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ui/Toast.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
const LoginScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/LoginScreen.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/LoginScreen.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c = LoginScreen;
;
;
const Splash_V2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/Splash_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/Splash_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c1 = Splash_V2;
const Welcome_V2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/Welcome_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/Welcome_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c2 = Welcome_V2;
const Home_V2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/Home_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/Home_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c3 = Home_V2;
const DashboardScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/Dashboard_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/Dashboard_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c4 = DashboardScreen;
const DayScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/DayDetail_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/DayDetail_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c5 = DayScreen;
const SuppliesScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/Packing_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/Packing_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c6 = SuppliesScreen;
const SettingsScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/Settings_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/Settings_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c7 = SettingsScreen;
const NotesScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/NotesScreen.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/NotesScreen.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c8 = NotesScreen;
const MapScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_c9 = ()=>__turbopack_context__.A("[project]/app/components/screens/Map_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/Map_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c10 = MapScreen;
const CrewScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/screens/Crew_V2.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/screens/Crew_V2.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c11 = CrewScreen;
const TourOverlay = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/TourOverlay.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/TourOverlay.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c12 = TourOverlay;
const TripEntryAnimation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/TripEntryAnimation.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/TripEntryAnimation.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c13 = TripEntryAnimation;
const TermsModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/TermsModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/TermsModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c14 = TermsModal;
const OnboardingScreen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/components/OnboardingScreen.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/components/OnboardingScreen.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    }
});
_c15 = OnboardingScreen;
// Watches network status, wires online/offline events, flushes pending changes on reconnect
function OfflineWatcher() {
    _s();
    const { setIsOffline, flushPendingChanges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])();
    const { show } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OfflineWatcher.useEffect": ()=>{
            const goOnline = {
                "OfflineWatcher.useEffect.goOnline": ()=>{
                    setIsOffline(false);
                    const count = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"].getState().pendingChanges.length;
                    flushPendingChanges().then({
                        "OfflineWatcher.useEffect.goOnline": ()=>{
                            if (count > 0) show(`Back online — ${count} change${count > 1 ? 's' : ''} synced ✓`);
                        }
                    }["OfflineWatcher.useEffect.goOnline"]).catch({
                        "OfflineWatcher.useEffect.goOnline": ()=>{}
                    }["OfflineWatcher.useEffect.goOnline"]);
                }
            }["OfflineWatcher.useEffect.goOnline"];
            const goOffline = {
                "OfflineWatcher.useEffect.goOffline": ()=>setIsOffline(true)
            }["OfflineWatcher.useEffect.goOffline"];
            if (!navigator.onLine) setIsOffline(true);
            window.addEventListener('online', goOnline);
            window.addEventListener('offline', goOffline);
            return ({
                "OfflineWatcher.useEffect": ()=>{
                    window.removeEventListener('online', goOnline);
                    window.removeEventListener('offline', goOffline);
                }
            })["OfflineWatcher.useEffect"];
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["OfflineWatcher.useEffect"], []);
    return null;
}
_s(OfflineWatcher, "UXsgWKdvtGsvuYe5frqfeSRvWUM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c16 = OfflineWatcher;
// Watches lastBudgetAlert and fires toasts when budget thresholds are crossed
function BudgetAlertWatcher() {
    _s1();
    const lastBudgetAlert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])({
        "BudgetAlertWatcher.useAppStore[lastBudgetAlert]": (s)=>s.lastBudgetAlert
    }["BudgetAlertWatcher.useAppStore[lastBudgetAlert]"]);
    const { show } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const tripDbId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])({
        "BudgetAlertWatcher.useAppStore[tripDbId]": (s)=>s.tripDbId
    }["BudgetAlertWatcher.useAppStore[tripDbId]"]);
    const currencyByTrip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])({
        "BudgetAlertWatcher.useAppStore[currencyByTrip]": (s)=>s.currencyByTrip
    }["BudgetAlertWatcher.useAppStore[currencyByTrip]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BudgetAlertWatcher.useEffect": ()=>{
            if (!lastBudgetAlert) return;
            const currency = tripDbId && currencyByTrip[tripDbId] || '';
            const fmt = {
                "BudgetAlertWatcher.useEffect.fmt": (n)=>`${currency} ${n.toLocaleString('en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })}`
            }["BudgetAlertWatcher.useEffect.fmt"];
            if (lastBudgetAlert.type === 'over') {
                show(`⚠️ Over budget! Exceeded by ${fmt(lastBudgetAlert.remaining)}`);
            } else {
                show(`💛 80% of budget used — ${fmt(lastBudgetAlert.remaining)} remaining`);
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"].setState({
                lastBudgetAlert: null
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["BudgetAlertWatcher.useEffect"], [
        lastBudgetAlert
    ]);
    return null;
}
_s1(BudgetAlertWatcher, "3CZLd41htPnmFd4K4231s0n6UXY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"]
    ];
});
_c17 = BudgetAlertWatcher;
// Watches lastSyncError globally and shows a toast — must live inside ToastProvider
function SyncErrorWatcher() {
    _s2();
    const { lastSyncError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])();
    const { show } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const { locale } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SyncErrorWatcher.useEffect": ()=>{
            if (!lastSyncError) return;
            const isRLS = lastSyncError.includes('row-level security') || lastSyncError.includes('violates') || lastSyncError.includes('rls');
            const msg = lastSyncError === 'not_authed' ? locale === 'he' ? '⚠️ לא מחובר — שינויים נשמרו מקומית בלבד' : '⚠️ Not signed in — changes saved locally only' : lastSyncError === 'join_failed' ? locale === 'he' ? '⚠️ לא ניתן היה לטעון את הטיול — נסה שוב' : '⚠️ Could not load the trip — please try again' : isRLS ? locale === 'he' ? 'לא ניתן לשמור. נסה שוב.' : "Couldn't save. Please try again." : `DB error: ${lastSyncError}`;
            show(msg);
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"].setState({
                lastSyncError: null
            });
        }
    }["SyncErrorWatcher.useEffect"], [
        lastSyncError
    ]);
    return null;
}
_s2(SyncErrorWatcher, "u+1PK/F+kW5nr5nXo47XErLB6Xg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c18 = SyncErrorWatcher;
const screenTransition = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["spring"].default;
function Shell() {
    _s3();
    // Granular selectors — each group only re-renders Shell when its slice changes (ME-5)
    const screen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])({
        "Shell.useAppStore[screen]": (s)=>s.screen
    }["Shell.useAppStore[screen]"]);
    const isGlobalLoading = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])({
        "Shell.useAppStore[isGlobalLoading]": (s)=>s.isGlobalLoading
    }["Shell.useAppStore[isGlobalLoading]"]);
    const themeMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])({
        "Shell.useAppStore[themeMode]": (s)=>s.themeMode
    }["Shell.useAppStore[themeMode]"]);
    const { setScreen, setThemeMode, checkAuth, loadTripById, subscribeToTrip, recordDemoClick, clearTripEntry, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallow"])({
        "Shell.useAppStore.useShallow": (s)=>({
                setScreen: s.setScreen,
                setThemeMode: s.setThemeMode,
                checkAuth: s.checkAuth,
                loadTripById: s.loadTripById,
                subscribeToTrip: s.subscribeToTrip,
                recordDemoClick: s.recordDemoClick,
                clearTripEntry: s.clearTripEntry,
                logout: s.logout
            })
    }["Shell.useAppStore.useShallow"]));
    const { trip, tripDbId, tripEntryCountries, authUser, termsAccepted, showTour } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallow"])({
        "Shell.useAppStore.useShallow": (s)=>({
                trip: s.trip,
                tripDbId: s.tripDbId,
                tripEntryCountries: s.tripEntryCountries,
                authUser: s.authUser,
                termsAccepted: s.termsAccepted,
                showTour: s.showTour
            })
    }["Shell.useAppStore.useShallow"]));
    const { highContrast, reducedMotion } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallow"])({
        "Shell.useAppStore.useShallow": (s)=>({
                highContrast: s.highContrast,
                reducedMotion: s.reducedMotion
            })
    }["Shell.useAppStore.useShallow"]));
    const { isOffline, pendingChanges, setIsOffline, flushPendingChanges } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallow"])({
        "Shell.useAppStore.useShallow": (s)=>({
                isOffline: s.isOffline,
                pendingChanges: s.pendingChanges,
                setIsOffline: s.setIsOffline,
                flushPendingChanges: s.flushPendingChanges
            })
    }["Shell.useAppStore.useShallow"]));
    const { isRTL } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"])();
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [osDark, setOsDark] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showOnboarding, setShowOnboarding] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showEntryAnim, setShowEntryAnim] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [entryCountries, setEntryCountries] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const prevScreen = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(screen);
    const resolvedDark = themeMode === 'dark' || themeMode === 'system' && osDark;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Shell.useEffect": ()=>{
            setMounted(true);
            // Stash any pending join trip ID from invite link redirect
            const params = new URLSearchParams(window.location.search);
            const joinId = params.get('join');
            if (joinId) {
                window.history.replaceState({}, '', '/');
                sessionStorage.setItem('trippy-pending-join', joinId);
            }
            // onAuthStateChange fires immediately with INITIAL_SESSION on every page load.
            // If the session is valid → confirm/update authUser.
            // If no session (expired or logged out) → clear persisted authUser and go to login.
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            const { data: { subscription } } = supabase.auth.onAuthStateChange({
                "Shell.useEffect": (event, session)=>{
                    if (session?.user) {
                        const username = session.user.user_metadata?.full_name ?? session.user.email?.split('@')[0] ?? 'Traveler';
                        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"].setState({
                            authUser: {
                                id: session.user.id,
                                username
                            },
                            userId: session.user.id
                        });
                        // After sign-in: move to home if still on an unauthenticated screen
                        const cur = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"].getState().screen;
                        if (cur === 'login' || cur === 'welcome' || cur === 'splash') {
                            setScreen('home');
                        }
                    } else if (event === 'SIGNED_OUT' || event === 'INITIAL_SESSION') {
                        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"].setState({
                            authUser: null,
                            userId: null
                        });
                        // After splash auto-advance, land on welcome (not legacy login)
                        const cur = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"].getState().screen;
                        if (cur !== 'splash') setScreen('welcome');
                    }
                }
            }["Shell.useEffect"]);
            // Show onboarding on first-ever device visit
            if (!localStorage.getItem('trippy-onboarded')) {
                setShowOnboarding(true);
            }
            // Reload trip data from DB if the user has a stored tripDbId (no auto-navigation).
            checkAuth();
            return ({
                "Shell.useEffect": ()=>subscription.unsubscribe()
            })["Shell.useEffect"];
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["Shell.useEffect"], []);
    // After auth resolves, auto-load a trip joined via invite link
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Shell.useEffect": ()=>{
            if (!authUser) return;
            const pendingJoin = sessionStorage.getItem('trippy-pending-join');
            if (!pendingJoin) return;
            sessionStorage.removeItem('trippy-pending-join');
            loadTripById(pendingJoin).catch({
                "Shell.useEffect": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"].setState({
                        lastSyncError: 'join_failed'
                    });
                }
            }["Shell.useEffect"]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["Shell.useEffect"], [
        authUser
    ]);
    // Real-time: subscribe to trip changes so co-participants see each other's updates
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Shell.useEffect": ()=>{
            if (!tripDbId) return;
            const unsubscribe = subscribeToTrip(tripDbId);
            return unsubscribe;
        }
    }["Shell.useEffect"], [
        tripDbId
    ]);
    // Show entry animation when tripEntryCountries is set (trip just entered)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Shell.useEffect": ()=>{
            if (tripEntryCountries) {
                setEntryCountries(tripEntryCountries);
                setShowEntryAnim(true);
                clearTripEntry();
            }
        }
    }["Shell.useEffect"], [
        tripEntryCountries
    ]);
    // Track demo clicks (when in demo mode: tripDbId is null and trip exists)
    const isDemo = !!trip && !tripDbId;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Shell.useEffect": ()=>{
            if (!isDemo) return;
            const handler = {
                "Shell.useEffect.handler": ()=>recordDemoClick()
            }["Shell.useEffect.handler"];
            window.addEventListener('click', handler);
            return ({
                "Shell.useEffect": ()=>window.removeEventListener('click', handler)
            })["Shell.useEffect"];
        }
    }["Shell.useEffect"], [
        isDemo
    ]);
    // Detect initial OS dark preference and watch for live changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Shell.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            const mq = window.matchMedia('(prefers-color-scheme: dark)');
            setOsDark(mq.matches);
            const handler = {
                "Shell.useEffect.handler": (e)=>setOsDark(e.matches)
            }["Shell.useEffect.handler"];
            mq.addEventListener('change', handler);
            return ({
                "Shell.useEffect": ()=>mq.removeEventListener('change', handler)
            })["Shell.useEffect"];
        }
    }["Shell.useEffect"], []);
    // Keep body background in sync with the resolved theme (prevents flash on page load)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Shell.useEffect": ()=>{
            if (typeof document !== 'undefined') {
                // Propagate data-dark to <html> so var(--bg) resolves correctly on body/html
                // (data-dark on the inner div doesn't affect var(--bg) resolution on ancestors)
                document.documentElement.dataset.dark = resolvedDark ? 'true' : '';
                document.body.style.background = 'var(--bg)';
            }
        }
    }["Shell.useEffect"], [
        resolvedDark
    ]);
    // Service Worker registration
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Shell.useEffect": ()=>{
            if ('serviceWorker' in navigator) {
                navigator.serviceWorker.register('/sw.js').catch({
                    "Shell.useEffect": ()=>{}
                }["Shell.useEffect"]);
            }
        }
    }["Shell.useEffect"], []);
    if (!mounted) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                position: 'fixed',
                inset: 0,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 28,
                background: 'var(--bg)'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$TripLoaders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LoaderStyles"], {}, void 0, false, {
                    fileName: "[project]/app/components/AppShell.tsx",
                    lineNumber: 272,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$TripLoaders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CompassLoader"], {
                    theme: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_THEME"],
                    size: 160
                }, void 0, false, {
                    fileName: "[project]/app/components/AppShell.tsx",
                    lineNumber: 273,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    style: {
                        fontFamily: 'var(--font-sans)',
                        fontSize: 22,
                        fontWeight: 700,
                        letterSpacing: '-0.04em',
                        color: 'var(--text)',
                        lineHeight: 1,
                        direction: 'ltr',
                        unicodeBidi: 'isolate'
                    },
                    children: [
                        "Trippy",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                color: 'var(--terra)'
                            },
                            children: "."
                        }, void 0, false, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 281,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/AppShell.tsx",
                    lineNumber: 274,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/AppShell.tsx",
            lineNumber: 266,
            columnNumber: 7
        }, this);
    }
    const showNav = trip && screen !== 'login' && screen !== 'home' && screen !== 'splash' && screen !== 'welcome' && screen !== 'settings' && screen !== 'notes';
    // MotionConfig: 'always' when user toggled reducedMotion, 'user' to respect OS setting
    const motionReduced = reducedMotion ? 'always' : 'user';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastProvider"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SyncErrorWatcher, {}, void 0, false, {
                fileName: "[project]/app/components/AppShell.tsx",
                lineNumber: 294,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BudgetAlertWatcher, {}, void 0, false, {
                fileName: "[project]/app/components/AppShell.tsx",
                lineNumber: 295,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OfflineWatcher, {}, void 0, false, {
                fileName: "[project]/app/components/AppShell.tsx",
                lineNumber: 296,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$MotionConfig$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MotionConfig"], {
                reducedMotion: motionReduced,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    dir: isRTL ? 'rtl' : 'ltr',
                    "data-dark": resolvedDark ? 'true' : undefined,
                    "data-high-contrast": highContrast ? 'true' : undefined,
                    "data-reduced-motion": reducedMotion ? 'true' : undefined,
                    className: "fixed inset-0 flex flex-col overflow-hidden",
                    style: {
                        background: 'var(--bg)',
                        paddingTop: 'env(safe-area-inset-top, 0px)',
                        paddingLeft: 'env(safe-area-inset-left, 0px)',
                        paddingRight: 'env(safe-area-inset-right, 0px)'
                    },
                    children: [
                        isOffline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                background: 'var(--danger-bg)',
                                borderBottom: '1px solid var(--danger)',
                                padding: '6px var(--page-px)',
                                fontSize: 12,
                                fontWeight: 600,
                                color: 'var(--danger)',
                                display: 'flex',
                                alignItems: 'center',
                                gap: 6,
                                zIndex: 9999
                            },
                            children: [
                                "📡 Offline",
                                pendingChanges.length > 0 ? ` — ${pendingChanges.length} change${pendingChanges.length > 1 ? 's' : ''} pending` : ' — viewing saved data'
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 313,
                            columnNumber: 13
                        }, this),
                        showNav && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$NavBar_V2$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            active: screen,
                            onChange: (s)=>setScreen(s),
                            onSettings: ()=>setScreen('settings'),
                            onSwitch: ()=>setScreen('home'),
                            onLogout: ()=>logout(),
                            onNotes: ()=>setScreen('notes')
                        }, void 0, false, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 332,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 flex flex-col relative overflow-hidden w-full",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                                mode: "wait",
                                initial: false,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                    variants: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["screenVariants"],
                                    initial: "initial",
                                    animate: "animate",
                                    exit: "exit",
                                    transition: screenTransition,
                                    className: `screen-inset${showNav ? ' screen-inset-nav' : ''} flex flex-col overflow-hidden`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full h-full",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-full h-full",
                                            children: screen === 'splash' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Splash_V2, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 356,
                                                columnNumber: 23
                                            }, this) : screen === 'welcome' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Welcome_V2, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 358,
                                                columnNumber: 23
                                            }, this) : screen === 'login' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LoginScreen, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 360,
                                                columnNumber: 23
                                            }, this) : !trip || screen === 'home' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Home_V2, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 362,
                                                columnNumber: 23
                                            }, this) : screen === 'dashboard' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DashboardScreen, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 364,
                                                columnNumber: 23
                                            }, this) : screen === 'day' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DayScreen, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 366,
                                                columnNumber: 23
                                            }, this) : screen === 'map' ? // Map tab removed — silently redirect to dashboard
                                            (()=>{
                                                setScreen('dashboard');
                                                return null;
                                            })() : screen === 'crew' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CrewScreen, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 371,
                                                columnNumber: 23
                                            }, this) : screen === 'supplies' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SuppliesScreen, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 373,
                                                columnNumber: 23
                                            }, this) : screen === 'settings' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SettingsScreen, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 375,
                                                columnNumber: 23
                                            }, this) : screen === 'notes' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NotesScreen, {}, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 377,
                                                columnNumber: 23
                                            }, this) : null
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/AppShell.tsx",
                                            lineNumber: 354,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AppShell.tsx",
                                        lineNumber: 353,
                                        columnNumber: 17
                                    }, this)
                                }, screen, false, {
                                    fileName: "[project]/app/components/AppShell.tsx",
                                    lineNumber: 344,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/AppShell.tsx",
                                lineNumber: 343,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 342,
                            columnNumber: 11
                        }, this),
                        showTour && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TourOverlay, {}, void 0, false, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 384,
                            columnNumber: 24
                        }, this),
                        authUser && !termsAccepted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TermsModal, {}, void 0, false, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 387,
                            columnNumber: 42
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            children: showOnboarding && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OnboardingScreen, {
                                onDone: ()=>setShowOnboarding(false)
                            }, void 0, false, {
                                fileName: "[project]/app/components/AppShell.tsx",
                                lineNumber: 392,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 390,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            children: showEntryAnim && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TripEntryAnimation, {
                                countries: entryCountries,
                                onDone: ()=>setShowEntryAnim(false)
                            }, void 0, false, {
                                fileName: "[project]/app/components/AppShell.tsx",
                                lineNumber: 398,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 396,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                            children: isGlobalLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$m$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["m"].div, {
                                initial: {
                                    opacity: 0
                                },
                                animate: {
                                    opacity: 1
                                },
                                exit: {
                                    opacity: 0
                                },
                                transition: {
                                    duration: 0.22
                                },
                                style: {
                                    position: 'fixed',
                                    inset: 0,
                                    zIndex: 9990,
                                    background: 'var(--bg)',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: 28
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$TripLoaders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LoaderStyles"], {}, void 0, false, {
                                        fileName: "[project]/app/components/AppShell.tsx",
                                        lineNumber: 422,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ui$2f$TripLoaders$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CompassLoader"], {
                                        theme: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$deriveTheme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BRAND_THEME"],
                                        size: 200
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/AppShell.tsx",
                                        lineNumber: 423,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontFamily: 'var(--font-sans)',
                                            fontSize: 22,
                                            fontWeight: 700,
                                            letterSpacing: '-0.04em',
                                            color: 'var(--text)',
                                            lineHeight: 1,
                                            direction: 'ltr',
                                            unicodeBidi: 'isolate'
                                        },
                                        children: [
                                            "Trippy",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    color: 'var(--terra)'
                                                },
                                                children: "."
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/AppShell.tsx",
                                                lineNumber: 431,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/AppShell.tsx",
                                        lineNumber: 424,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, "global-loader", true, {
                                fileName: "[project]/app/components/AppShell.tsx",
                                lineNumber: 408,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/AppShell.tsx",
                            lineNumber: 406,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/AppShell.tsx",
                    lineNumber: 298,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/AppShell.tsx",
                lineNumber: 297,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/AppShell.tsx",
        lineNumber: 293,
        columnNumber: 5
    }, this);
}
_s3(Shell, "GFrqTnDkQewTXPh3x/OFDSJ52ps=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useI18n"]
    ];
});
_c19 = Shell;
function AppShell() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$i18n$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["I18nProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Shell, {}, void 0, false, {
            fileName: "[project]/app/components/AppShell.tsx",
            lineNumber: 445,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/AppShell.tsx",
        lineNumber: 444,
        columnNumber: 5
    }, this);
}
_c20 = AppShell;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20;
__turbopack_context__.k.register(_c, "LoginScreen");
__turbopack_context__.k.register(_c1, "Splash_V2");
__turbopack_context__.k.register(_c2, "Welcome_V2");
__turbopack_context__.k.register(_c3, "Home_V2");
__turbopack_context__.k.register(_c4, "DashboardScreen");
__turbopack_context__.k.register(_c5, "DayScreen");
__turbopack_context__.k.register(_c6, "SuppliesScreen");
__turbopack_context__.k.register(_c7, "SettingsScreen");
__turbopack_context__.k.register(_c8, "NotesScreen");
__turbopack_context__.k.register(_c9, "MapScreen$dynamic");
__turbopack_context__.k.register(_c10, "MapScreen");
__turbopack_context__.k.register(_c11, "CrewScreen");
__turbopack_context__.k.register(_c12, "TourOverlay");
__turbopack_context__.k.register(_c13, "TripEntryAnimation");
__turbopack_context__.k.register(_c14, "TermsModal");
__turbopack_context__.k.register(_c15, "OnboardingScreen");
__turbopack_context__.k.register(_c16, "OfflineWatcher");
__turbopack_context__.k.register(_c17, "BudgetAlertWatcher");
__turbopack_context__.k.register(_c18, "SyncErrorWatcher");
__turbopack_context__.k.register(_c19, "Shell");
__turbopack_context__.k.register(_c20, "AppShell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_0fqaztt._.js.map