(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_components_102_1dr._.js","static/chunks/_0fqaztt._.js","static/chunks/node_modules_@supabase_postgrest-js_dist_index_mjs_0eu3ylr._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_0.pzobh._.js","static/chunks/node_modules_09mxrxx._.js"],
    source: "dynamic"
});
